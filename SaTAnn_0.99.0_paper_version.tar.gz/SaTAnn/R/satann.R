# SaTAnn, Splice-Aware Translatome Annotation
#
# Authors: 
# Lorenzo Calviello (calviello.l.bio@gmail.com)
# Uwe Ohler (Uwe.Ohler@mdc-berlin.de)
#
# This software is free software: you can redistribute it and/or
# modify it under the terms of the GNU General Public License as
# published by the Free Software Foundation, either version 3 of the
# License, or (at your option) any later version.
#
# This software is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this software. If not, see
# <http://www.gnu.org/licenses/>.

setMethods(f = "unlist","GRanges",function(x){return(x)})


DEFAULT_CIRC_SEQS <- unique(c("chrM","MT","MtDNA","mit","Mito","mitochondrion",
                              "dmel_mitochondrion_genome","Pltd","ChrC","Pt","chloroplast",
                              "Chloro","2micron","2-micron","2uM",
                              "Mt", "NC_001879.2", "NC_006581.1","ChrM"))


#' Find ATG-starting ORFs in a sequence
#'
#' This function loads the annotation created by the \code{prepare_annotation_files function}
#' @keywords SaTAnn
#' @author Lorenzo Calviello, \email{calviello.l.bio@@gmail.com}
#' @param tx_name transcript_id
#' @param sequence DNAString object containing the sequence of the transcript
#' @param get_all_starts Output all possible start codons? Defaults to \code{TRUE}
#' @param Stop_Stop Find Stop-Stop pairs (no defined start codon)? Defaults to \code{FALSE}
#' @param scores Deprecated
#' @param genetic_code_table GENETIC_CODE table to use
#' @return \code{GRanges} object containing coordinates for the detected ORFs
#' @seealso \code{\link{detect_translated_orfs}}
#' @export


get_orfs<-function(tx_name,sequence,get_all_starts=T,Stop_Stop=F,scores=c(1,.5),genetic_code_table){
    list_frames<-list()
    length<-nchar(sequence)
    for(u in 0:2){
        pept<-NA
        pept<-unlist(strsplit(as.character(suppressWarnings(translate(subseq(sequence,start=u+1),genetic.code = genetic_code_table,if.fuzzy.codon = "solve"))),split=""))
        
        
        starts<-pept=="M"
        
        stops<-pept=="*"
        
        start_pos<-((1:length(pept))[starts])*3
        if(length(start_pos)>0){
            start_pos<-start_pos+u-2
        } else {start_pos<-NA}
        
        stop_pos<-((1:length(pept))[stops])*3-3
        if(length(stop_pos)>0){
            stop_pos<-stop_pos+u
        } else {stop_pos<-NA}
        
        st2vect<-c()
        for(h in 1:length(start_pos)){
            st1<-start_pos[h]
            diff<-stop_pos-st1
            diff<-diff[diff>0]
            if(length(diff)>0){st2<-st1+min(diff)}
            if(length(diff)==0){st2<-NA}
            st2vect[h]<-st2
            
        }
        st_st<-data.frame(cbind(start_pos,st2vect),stringsAsFactors=F)
        st_st<-st_st[!is.na(st_st[,1]),]
        st_st<-st_st[!is.na(st_st[,2]),]
        if(dim(st_st)[1]==0){list_frames[[paste("frame",u,sep = "_")]]<-GRanges(); next}
        if(get_all_starts==T){
            gra_orf<-GRanges(seqnames = paste(tx_name,"frame",u,sep = "_"),strand = "+",ranges = IRanges(start = st_st[,1],end = st_st[,2]))
        }
        if(get_all_starts==F){
            gra_orf<-reduce(GRanges(seqnames = paste(tx_name,"frame",u,sep = "_"),strand = "*",ranges = IRanges(start = st_st[,1],end = st_st[,2])))
        }
        if(length(gra_orf)>0){
            gra_orf$type="ORF"
            gra_orf$score<-scores[1]
        }
        
        gra_par<-GRanges()
        if(Stop_Stop==T){
            stops<-pept=="*"
            stop_pos<-((1:length(pept))[stops])*3
            if(length(stop_pos)>0){
                stop_pos<-stop_pos+u
            } else {stop_pos<-NA}
            
            
            vector_starts<-c()
            vector_stops<-c()
            
            if(sum(stops)==0){vector_starts<-u+1; vector_stops<-length}
            
            if(sum(stops)==1){
                vector_starts[1]<-u+1
                vector_starts[2]<-stop_pos+1
                vector_stops[1]<-stop_pos-3
                vector_stops[2]<-length
                
            }
            
            if(sum(stops)>0){
                for(stoppo in 0:(length(stop_pos))){
                    start<-stop_pos[stoppo]+1
                    if(stoppo==0){
                        start<-u+1
                    }
                    end<-stop_pos[stoppo+1]-3
                    if(stoppo==length(stop_pos)){
                        end<-length
                    }
                    
                    if((end-start)<5){
                        next
                    }
                    vector_starts[stoppo+1]<-start
                    vector_stops[stoppo+1]<-end
                    
                }
                
                
            }
            
            st_st<-data.frame(cbind(vector_starts,vector_stops))
            st_st<-st_st[!is.na(st_st[,"vector_starts"]),]
            st_st<-st_st[!is.na(st_st[,"vector_stops"]),]
            #st_st<-st_st[(st_st[,2]-st_st[,1]>11),]
            gra_par<-GRanges(seqnames = paste(tx_name,"frame",u,sep = "_"),strand = "+",ranges = IRanges(start = st_st[,1],end = st_st[,2]))
            if(length(gra_par)>0){
                gra_par<-setdiff(gra_par,gra_orf)
                
            }
            if(length(gra_par)>0){
                gra_par$type="frame_ok"
                gra_par$score<-scores[2]                        
            }
        }
        gra<-c(gra_orf,gra_par)
        
        list_frames[[paste("frame",u,sep = "_")]]<-gra
    }
    GRangesList(list_frames)
}

#' Extract output from multitaper analysis of a signal
#'
#' This function uses the multitaper tool to extract F-values and multitaper spectral coefficients
#' @details Values reported correspond to the closest frequency to 1/3 (same parameters as in RiboTaper). \cr
#' Padding to a minimum length of 1024 is performed to increase spectral resolution.
#' @keywords SaTAnn
#' @author Lorenzo Calviello, \email{calviello.l.bio@@gmail.com}
#' @param x numeric signal to analyze
#' @param n_tapers n of tapers to use
#' @param time_bw time_bw parameter
#' @param slepians_values set of calculated slepian functions to use in the multitaper analysis
#' @return two numeric values representing the F-value for the multitaper test and its corresponding spectral coefficient at the closest frequency to 1/3
#' @seealso \code{\link{detect_translated_orfs}}, \code{\link{spec.mtm}}, \code{\link{dpss}}
#' @export

take_Fvals_spect<-function(x,n_tapers,time_bw,slepians_values){
    if(length(x)<25){
        remain<-50-length(x)
        x<-c(rep(0,as.integer(remain/2)),x,rep(0,remain%%2+as.integer(remain/2)))
    }
    if(length(x)<1024/2){padding<-1024}
    if(length(x)>=1024/2){padding<-"default"}
    resSpec1 <- spec.mtm(as.ts(x), k=n_tapers, nw=time_bw, nFFT = padding, centreWithSlepians = TRUE, Ftest = TRUE, maxAdaptiveIterations = 100,returnZeroFreq=F,plot=F,dpssIN=slepians_values)
    
    resSpec2<-dropFreqs(resSpec1,0.29,0.39)
    
    freq_max_3nt<-resSpec1$freq[which(abs((resSpec1$freq-(1/3)))==min(abs((resSpec1$freq-(1/3)))))]
    
    Fmax_3nt<-resSpec1$mtm$Ftest[which(abs((resSpec1$freq-(1/3)))==min(abs((resSpec1$freq-(1/3)))))]
    spect_3nt<-resSpec1$spec[which(abs((resSpec1$freq-(1/3)))==min(abs((resSpec1$freq-(1/3)))))]
    return(c(Fmax_3nt,spect_3nt))
    
}

#' Select start codon 
#'
#' This function selects the start codon for ORFs in the same transcript
#' @details ORFs are divided based on stop codon and Ribo-seq signal between start codons is used to select one.\cr
#' When more than \code{cutoff_ave} fraction of codons is in-frame between two candidate start codons, the most upstream
#' is selected.
#' @keywords SaTAnn
#' @author Lorenzo Calviello, \email{calviello.l.bio@@gmail.com}
#' @param ORFs Set of detected ORFs
#' @param P_sites_rle Rle signal of P_sites along the transcript
#' @param cutoff cutoff of total in-frame signal between start codons (sensitive to outliers). Defaults to NA
#' @param cutoff_ave cutoff for frequency of in-frame codons between two start codons (less sensitive to outliers). Defaults to .5
#' @return Set of detected ORFs, including info about the possible longest ORF for that frame.
#' @seealso \code{\link{detect_translated_orfs}}, \code{\link{get_orfs}}
#' @export

select_start<-function(ORFs,P_sites_rle,cutoff=NA,cutoff_ave=.5){
    ORFs<-ORFs[order(end(ORFs),start(ORFs),decreasing = F)]
    names(ORFs)<-NULL
    longest_ORF<-split(ORFs,end(ORFs))
    maxo<-which.max(width(longest_ORF))
    longest_ORF<-unlist(longest_ORF[splitAsList(unname(maxo), names(maxo))])
    P_sites_rle<-RleList(P_sites_rle)
    names(P_sites_rle)<-seqnames(ORFs[1])
    covss<-P_sites_rle[ORFs]
    ok<-sapply(covss,function(x){sum(as.vector(x)>0)>2})
    if(length(ok)==0){return(GRanges())}
    ORFs<-ORFs[ok]
    covss<-covss[ok]
    rrr<-lapply(covss,function(x){
        fr<-suppressWarnings(matrix(as.vector(x),nrow = 3))
        fr<-fr[,colSums(fr)>0,drop=F]
        if(dim(fr)[2]==0){return(GRanges())}
        fra<-apply(fr,2,function(y){y/sum(y)})
        infr_freq<-rowMeans(fra)[1]
        infr<-((rowSums(fr))[1])/sum(fr)
        y<-DataFrame(ave_pct_fr=round(infr_freq*100,digits = 4))
        y$pct_fr<-round(infr*100,digits = 4)
        y$ave_pct_fr_st<-NA
        y$pct_fr_st<-NA
        y
    })
    mcols(ORFs)<-do.call(rrr,what = rbind)
    
    if(!is.na(cutoff)){
        covss<-covss[ORFs$pct_fr>=cutoff]
        ORFs<-ORFs[ORFs$pct_fr>=cutoff]
    }
    if(!is.na(cutoff_ave)){
        covss<-covss[ORFs$ave_pct_fr>=cutoff_ave]
        ORFs<-ORFs[ORFs$ave_pct_fr>=cutoff_ave]
    }
    if(length(ORFs)==0){return(GRanges())}
    ORFs$endorf<-end(ORFs)
    orfs_spl<-split(ORFs,end(ORFs))
    names(covss)<-end(ORFs)
    ORFs<-endoapply(orfs_spl,function(x){
        if(length(x)==1){x$endorf<-NULL;return(x)}
        covo<-covss[names(covss)%in%as.character(x$endorf[1])]
        okorfa<-c()
        for(cnt in 1:length(x)){
            psit<-as.vector(covo[[cnt]])
            
            if(cnt<length(x)){
                psit<-psit[1:(start(x)[cnt+1]-start(x)[cnt])]
            }
            if(cnt==length(x)){okorfa<-cnt}
            
            frames<-suppressWarnings(matrix(as.vector(psit),nrow = 3))
            frames<-frames[,colSums(frames)>0,drop=F]
            if(dim(frames)[2]==0){next}
            frames<-apply(frames,2,function(y){y/sum(y)})
            infr_freq<-rowMeans(frames)[1]
            infr<-sum(psit[seq(1,length(psit),by=3)])/sum(psit)
            if(!is.na(cutoff)){
                if(infr>=cutoff & !is.na(infr)){
                    x$ave_pct_fr_st[cnt]<-round(infr_freq,digits = 4)
                    x$pct_fr_st[cnt]<-round(infr,digits = 4)
                    okorfa<-cnt
                    break
                }
            }
            
            if(!is.na(cutoff_ave)){
                if(infr_freq>=cutoff_ave & !is.na(infr_freq)){
                    x$ave_pct_fr_st[cnt]<-round(infr_freq*100,digits = 4)
                    x$pct_fr_st[cnt]<-round(infr*100,digits = 4)
                    okorfa<-cnt
                    break
                }
                
            }
            
            
        }
        x<-x[okorfa]
        x$endorf<-NULL
        return(x)
    })
    ORFs<-unlist(ORFs)
    names(ORFs)<-NULL
    ORFs$longest_ORF<-longest_ORF[match(end(ORFs),names(longest_ORF))]
    return(ORFs)
    
}

#' Collect ORF Ribo-seq statistics
#'
#' This function calculates statistics for the analysis of P_sites profiles for each ORF
#' @details Number of P_sites (uniquely mapping or all), frame percentage and multitaper test 
#' statistics are collected for each ORF. The parameter space for the multitaper analysis was explored in the RiboTaper paper.
#' @keywords SaTAnn
#' @author Lorenzo Calviello, \email{calviello.l.bio@@gmail.com}
#' @param ORFs Set of detected ORFs
#' @param P_sites_rle Rle signal of P_sites along the transcript
#' @param P_sites_uniq_rle Rle signal of uniquely mapping P_sites along the transcript
#' @param P_sites_uniq_mm_rle Rle signal of uniquely mapping P_sites with mismatches along the transcript
#' @param cutoff cutoff of average in-frame signal for each codon in the ORF. Defaults to .5
#' @param tapers Number of tapers to use in the multitaper analysis. Defaults to 24
#' @param bw time_bw parameter to use in the multitaper analysis. Defaults to 12
#' @return Set of detected ORFs, including info about the possible longest ORF for that frame.
#' @seealso \code{\link{detect_translated_orfs}}, \code{\link{get_orfs}}, \code{\link{take_Fvals_spect}}
#' @export

calc_orf_pval<-function(ORFs,P_sites_rle,P_sites_uniq_rle,P_sites_uniq_mm_rle,cutoff=.5,tapers=24,bw=12){
    ORFs$pval<-NA
    ORFs$pval_uniq<-NA
    ORFs$P_sites_raw<-NA
    ORFs$pct_uniq<-NA
    ORFs$pct_uniq_notmm<-NA
    ORFs$pct_fr<-NA
    ORFs$TrP_raw<-NA
    
    for(i in 1:length(ORFs)){
        psit<-as.vector(P_sites_rle[ORFs[i]@ranges])
        psit_uniq<-as.vector(P_sites_uniq_rle[ORFs[i]@ranges])
        psit_uniq_mm<-as.vector(P_sites_uniq_mm_rle[ORFs[i]@ranges])
        ORFs$P_sites_raw[i]<-sum(psit)
        ps_unq<-round(sum(psit_uniq)/sum(psit)*100,digits = 2)
        if(is.na(ps_unq)){ps_unq<-0}
        ORFs$pct_uniq[i]<-ps_unq
        
        ps_unq<-round((sum(psit_uniq)-sum(psit_uniq_mm))/sum(psit)*100,digits = 2)
        if(is.na(ps_unq)){ps_unq<-0}
        
        ORFs$pct_uniq_notmm[i]<-ps_unq
        ORFs$ORF_id_tr[i]<-paste(as.character(seqnames(ORFs[i])[1]),start(ORFs[i]),end(ORFs[i]),sep = "_")
        if(sum(psit)>0){
            infr<-sum(psit[seq(1,length(psit),by=3)])/sum(psit)
            ORFs$pct_fr[i]<-infr
        }
        if(sum(psit>0)>2){
            if(infr>cutoff){
                if(length(psit)<25){slepians<-dpss(n=length(psit)+(50-length(psit)),k=tapers,nw=bw)}
                if(length(psit)>=25){slepians<-dpss(n=length(psit),k=tapers,nw=bw)}
                vals<-take_Fvals_spect(x = psit,n_tapers = tapers,time_bw = bw,slepians_values = slepians)
                ORFs$pval[i]<-pf(q=vals[1],df1=2,df2=(2*24)-2,lower.tail=F)
                ORFs$TrP_raw[i]<-vals[2]
                vals<-take_Fvals_spect(x = psit_uniq,n_tapers = tapers,time_bw = bw,slepians_values = slepians)
                ORFs$pval_uniq[i]<-pf(q=vals[1],df1=2,df2=(2*24)-2,lower.tail=F)
                
                
            }
        }
    }
    return(ORFs)
}


#' Detect actively translated ORFs 
#'
#' This function detects translated ORFs
#' @details A set of transcripts, together with genome sequence and Ribo-signal are analyzed to extract translated ORFs
#' @keywords SaTAnn
#' @author Lorenzo Calviello, \email{calviello.l.bio@@gmail.com}
#' @param selected_txs set of selected transcripts, output from \code{select_txs}
#' @param P_sites GRanges object with P_sites positions
#' @param P_sites_uniq GRanges object with uniquely mapping P_sites positions
#' @param P_sites_uniq_mm GRanges object with uniquely mapping (with mismatches) P_sites positions
#' @param genomic_region GRanges object with genomic coordinates of the genomic region analyzed
#' @param genetic_code GENETIC_CODE table to use
#' @param all_starts \code{get_all_starts} parameter for the \code{get_orfs} function
#' @param nostarts \code{Stop_Stop} parameter for the \code{get_orfs} function
#' @param start_sel_cutoff \code{cutoff} parameter for the \code{select_start} function
#' @param start_sel_cutoff_ave \code{cutoff_ave} parameter for the \code{select_start} function
#' @param cutoff_fr_ave \code{cutoff} parameter for the  \code{calc_orf_pval} functions
#' @return A list with transcript coordinates, exonic coordinates and statistics for each ORF exonic bin and junction(from \code{select_txs}).\cr\cr
#' The value for each column is as follows:\cr\cr
#' \code{ave_pct_fr}: average percentage of in-frame reads for each codon in the ORF
#' \code{pct_fr}: percentage of in-frame reads in the ORF
#' \code{ave_pct_fr}: average percentage of in-frame reads for each codon in the ORF
#' \code{ave_pct_fr_st}: average percentage of in-frame reads per each codon between the selected start codon and the next candidate one
#' \code{pct_fr_st}: percentage of in-frame reads between the selected start codon and the next candidate one
#' \code{longest_ORF}: GRanges coordinates for the longest ORF with the same stop codon
#' \code{pval}: P-value for the multitaper F-test at 1/3 using the ORF P_sites profile
#' \code{pval_uniq}: P-value for the multitaper F-test at 1/3 using the ORF P_sites profile (only uniquely mapping reads)
#' \code{P_sites_raw}: Raw number of P_sites mapping to the ORF
#' \code{pct_uniq}: Percentage of raw number of P_sites mapping to the ORF
#' \code{TrP_raw}: Raw multitaper spectral coefficient at 1/3 using the P_sites ORF signal
#' \code{ORF_id_tr}: ORF id containing <tx_id>_<start>_<end>
#' \code{Protein}: AAString sequence of the translated protein
#' \code{region}: Genomic coordinates of the analyzed region
#' \code{gene_id}: gene_id for the corresponding analyzed transcript
#' \code{gene_biotype}: gene biotype for the corresponding analyzed transcript
#' \code{gene_name}: gene name for the corresponding analyzed transcript
#' \code{transcript_id}: transcript_id for the corresponding analyzed ORF
#' \code{transcript_biotype}: transcript biotype for the corresponding analyzed ORF
#' @seealso \code{\link{select_txs}}, \code{\link{get_orfs}}, \code{\link{take_Fvals_spect}}, \code{\link{select_start}}, \code{\link{prepare_annotation_files}}
#' @export

detect_translated_orfs<-function(selected_txs,genome_sequence,annotation,P_sites,P_sites_uniq,P_sites_uniq_mm,genomic_region,genetic_code,
                                 all_starts=T,nostarts=F,start_sel_cutoff=NA,start_sel_cutoff_ave=.5,
                                 cutoff_fr_ave=.5){
    
    orfs_gr<-GRangesList()
    orfs_gen_gr<-GRangesList()
    annot_tx_cds_gr<-GRangesList()
    cdss<-annotation$cds_txs
    exss<-annotation$exons_txs
    intr_txs<-annotation$introns_txs
    tr_gen<-annotation$trann
    txs_sels<-unique(unlist(selected_txs$txs_selected))
    annot_sels<-annotation$exons_txs[txs_sels]
    mapp<-mapToTranscripts(P_sites,annot_sels)
    mapp$reads<-P_sites$score[mapp$xHits]
    lens_sels<-sum(width(annot_sels))
    seqm<-seqlengths(mapp)
    seqlengths(mapp)<-lens_sels[match(names(seqm),names(lens_sels))]
    cov_txs<-coverage(mapp,weight = mapp$reads)
    
    mapp<-mapToTranscripts(P_sites_uniq,annot_sels)
    if(length(P_sites_uniq)>0){
        mapp$reads<-P_sites_uniq$score[mapp$xHits]
        seqm<-seqlengths(mapp)
        seqlengths(mapp)<-lens_sels[match(names(seqm),names(lens_sels))]
        cov_uniq_txs<-coverage(mapp,weight = mapp$reads)
    }
    
    if(length(P_sites_uniq)==0){cov_uniq_txs<-coverage(mapp)}
    
    mapp<-mapToTranscripts(P_sites_uniq_mm,annot_sels)
    
    if(length(P_sites_uniq_mm)==0){cov_uniq_mm_txs<-coverage(mapp)}
    
    if(length(P_sites_uniq_mm)>0){
        mapp$reads<-P_sites_uniq_mm$score[mapp$xHits]
        seqm<-seqlengths(mapp)
        seqlengths(mapp)<-lens_sels[match(names(seqm),names(lens_sels))]
        cov_uniq_mm_txs<-coverage(mapp,weight = mapp$reads)
    }
    txs_seqs<-extractTranscriptSeqs(genome_sequence,annot_sels)
    
    for(tx in txs_sels){
        
        ex_txs<-exss[tx]
        ex_tx<-ex_txs[[1]]
        intr_tx<-intr_txs[[tx]]
        nm_cds<-which(names(cdss)==tx)
        #map cds in tx space
        
        
        covtx<-cov_txs[[tx]]
        covtx_uniq<-cov_uniq_txs[[tx]]
        covtx_uniq_mm<-cov_uniq_mm_txs[[tx]]
        
        seq_tx<-txs_seqs[[tx]]
        if(length(covtx)==0){next}
        orfs<-unlist(get_orfs(tx_name = tx,sequence = seq_tx,get_all_starts=all_starts,Stop_Stop = F,genetic_code_table=genetic_code))
        #no need to know frame for now
        #names(orfs)<-NULL
        if(length(orfs)==0){next}
        
        orfs<-GRanges(seqnames = tx,ranges = orfs@ranges,strand = strand(orfs))
        orfs<-select_start(ORFs = orfs,P_sites_rle = covtx,cutoff = start_sel_cutoff,cutoff_ave = start_sel_cutoff_ave)
        if(length(orfs)==0){next}
        orfs<-calc_orf_pval(ORFs = orfs,P_sites_rle = covtx,P_sites_uniq_rle = covtx_uniq,P_sites_uniq_mm_rle = covtx_uniq_mm,cutoff = cutoff_fr_ave)
        if(length(orfs)==0){next}
        orfs<-subset(orfs,pval<.05)
        if(length(orfs)==0){next}
        #orfs$gene_id<-mapIds(keys = tx,x = annot,column = "GENEID",keytype = "TXNAME")
        orfs$Protein<-AAStringSet(rep("NA",length(orfs)))
        for(h in 1:length(orfs)){
            orfs$Protein[h]<-AAStringSet(as.character(translate(seq_tx[orfs@ranges[h]],genetic.code = genetic_code,if.fuzzy.codon = "solve")))
        }
        #orfs$Protein<-AAStringSet(orfs$Protein)
        orfs_gen<-from_tx_togen(ORFs = orfs,exons = ex_txs,introns = intr_tx)
        #here I should annotate
        
        tr_gen_tx<-tr_gen[as.vector(match(seqnames(orfs)[1],tr_gen[,"transcript_id"])),]
        
        orfs$region<-genomic_region
        orfs$gene_id<-unique(as.character(tr_gen_tx[,"gene_id"]))
        orfs$gene_biotype<-unique(as.character(tr_gen_tx[,"gene_biotype"]))
        orfs$gene_name<-unique(as.character(tr_gen_tx[,"gene_name"]))
        orfs$transcript_id<-unique(as.character(tr_gen_tx[,"transcript_id"]))
        orfs$transcript_biotype<-unique(as.character(tr_gen_tx[,"transcript_biotype"]))
        
        #must add the other compatible txs, to avoid calculating same stuff
        for(w in 1:length(orfs)){
            orf<-orfs[w]
            nam<-orf$ORF_id_tr
            orf$compatible_with<-NA
            orfs_gr[[nam]]<-orf
            orfs_gen_gr[[nam]]<-orfs_gen[[nam]]
            
        }
        
    }
    if(length(orfs_gr)==0){
        return(list())
    }
    tx_orfs<-unique(sapply(strsplit(names(orfs_gr),split="_"),function(x){
        len<-length(x)
        x[-c(len-1,len)]
    }))
    a<-lapply(selected_txs$txs,function(x){x[x%in%tx_orfs]})
    selected_txs$txs_orfs<-CharacterList(a)
    
    check<-sapply(selected_txs$txs_orfs,FUN = length)
    use<-rep("shared",length(check))
    use[check==1]<-"unique"
    use[check==0]<-"absent"
    use[check>1]<-"shared"
    selected_txs$use_ORFs<-use
    
    orfs_unq_gr<-GRangesList()
    
    for(j in names(orfs_gr)){
        
        orf_gen<-orfs_gen_gr[[j]]
        orf_tx<-orfs_gr[[j]]
        featexs<-selected_txs[selected_txs$type=="E"]
        featjuns<-selected_txs[selected_txs$type=="J"]
        
        over_tx<-featexs[featexs%over%orf_gen]
        if(length(featjuns)>0){
            over_tx<-sort(c(over_tx,featjuns[which(featjuns%in%gaps(orf_gen))]))
        }
        
        a<-sapply(over_tx$txs,function(x){length(x[x%in%as.character(seqnames(orf_tx))])})
        over_tx<-over_tx[a>0]
        
        orfs_unq_gr[[j]]<-over_tx
    }
    
    if(length(orfs_gr)>1){
        
        ident_mat<-matrix(FALSE,nrow=length(orfs_gr),ncol=length(orfs_gr))
        for(i in names(orfs_gr)){
            orf<-orfs_gr[[i]]
            orf$compatible_with<-NA
            gen<-orfs_gen_gr[[i]]
            
            ident<-c()
            for(j in 1:length(orfs_gen_gr)){
                ident[j]<-identical(gen,orfs_gen_gr[[j]])
            }
            ident_mat[which(names(orfs_gr)==i),]<-ident
        }
        #diag(ident_mat)<-NA
        ident_mat[lower.tri(ident_mat,diag=T)]<-NA
        ide<-which(ident_mat,arr.ind=T)
        if(length(ide)>0){
            rems<-c()
            ide<-split(ide,ide[,1])
            for(i in 1:length(ide)){
                iden<-ide[[i]]
                iden<-iden[!iden==as.numeric(names(ide)[i])]
                if(sum(iden%in%rems)>0){next}
                ind<-names(orfs_gr)[as.numeric(names(ide)[i])]
                ch<-names(orfs_gr)[iden]
                rems<-unique(c(rems,iden))
                #new_cat<-paste(unlist(orfs_gr[ch])$category_tx,collapse=";")
                new_id<-paste(unlist(orfs_gr[ch])$ORF_id_tr,collapse=";")
                orfs_gr[[ind]]$compatible_with<-new_id
                #if(length(unique(unlist(orfs_gr[ch])$category_tx))==1){next}
                #orfs_gr[[ind]]$compatible_categories<-new_cat
                #orfs_gr[[ind]]$category_tx<-"multiple"
            }
            orfs_gr<-orfs_gr[-rems]
            orfs_gen_gr<-orfs_gen_gr[-rems]
            orfs_unq_gr<-orfs_unq_gr[-rems]
        }
    }
    list_res<-list(orfs_gr,orfs_gen_gr,orfs_unq_gr)
    names(list_res)<-c("ORFs_tx_position","ORFs_genomic_position","ORFs_features")
    return(list_res)
}


#' Map transcript coordinates to genomic coordinates
#'
#' This function uses the \code{mapFromTranscripts} function to switch between transcript
#' and genomic coordinates
#' @keywords SaTAnn
#' @author Lorenzo Calviello, \email{calviello.l.bio@@gmail.com}
#' @param ORFs Set of detected ORFs from the \code{calc_orf_pval} function
#' @param exons exonic regions of the analyzed transcripts, as a GRangesList object
#' @param introns intronic regions of the analyzed transcripts, as a GRangesList object
#' @return exonic coordinates for each ORF.
#' @seealso \code{\link{mapFromTranscripts}}
#' @export

from_tx_togen<-function(ORFs,exons,introns){
    strand(ORFs)<-rep("*",length(ORFs))
    orfs_gen<-mapFromTranscripts(x = ORFs,transcripts = exons,ignore.strand=F)
    strand(orfs_gen)<-strand(exons[[1]][1])
    list_ma<-GRangesList()
    for(i in 1:length(ORFs)){
        or<-orfs_gen[i]
        or<-setdiff(or,introns)
        list_ma[[ORFs$ORF_id_tr[i]]]<-or
    }
    return(list_ma)
}


#' Select a subset of transcripts with Ribo-seq data
#'
#' This function flattens all annotated transcript structures and uses Ribo-seq to select a subset of transcripts.
#' @details Features (bins and junctions) are divided into shared and unique features, and into with support and without
#' support (with  or without reads mapping). A set of logical rules filters out transcripts with internal features with no support
#' and no unique features with reads. More specific details can be found in the SaTAnn manuscript.
#' @keywords SaTAnn
#' @author Lorenzo Calviello, \email{calviello.l.bio@@gmail.com}
#' @param region genomic region being analyzed
#' @param annotation Rannot object containing annotation of CDS and transcript structures (see \code{prepare_annotation_files})
#' @param P_sites GRanges object with P_sites positions
#' @param P_sites_uniq GRanges object with uniquely mapping P_sites positions
#' @param junction_counts GRanges object containing Ribo-seq counts on the set of annotated junctions
#' @return GRanges object with the set of counts on each exonic bin and junctions, together with the list
#' of selected transcripts
#' @seealso \code{\link{prepare_annotation_files}}
#' @export

select_txs<-function(region,annotation,P_sites,P_sites_uniq,junction_counts){
    
    stra<-as.character(region@strand)
    gene_feat <- junction_counts[junction_counts %over% region]
    
    nsns<-annotation$exons_bins
    sel_nsns<-nsns%over%region
    gen_nsns<-nsns[sel_nsns]
    genbin<-gen_nsns
    genbin$exonic_part<-NULL
    genbin$type<-"E"
    genbin$reads<-0
    genbin$unique_reads<-0
    
    d<-genbin$reads
    
    hts<-findOverlaps(genbin,P_sites,ignore.strand=F)
    hts<-cbind(queryHits(hts),P_sites[subjectHits(hts)]$score)
    
    if(length(hts)>0){
        hts<-aggregate(x = hts[,2],list(hts[,1]),FUN=sum)
        for(i in 1:dim(hts)[1]){
            d[hts[i,1]]<-hts[i,2]
        }
        genbin$reads<-d
        
    }
    
    hts<-findOverlaps(genbin,P_sites_uniq,ignore.strand=F)
    hts<-cbind(queryHits(hts),P_sites_uniq[subjectHits(hts)]$score)
    #IMPORTANT, HERE THERE WAS A IF NO UNIQ RETURN GRANGESLIST()
    if(length(hts)>0){
        hts<-aggregate(x = hts[,2],list(hts[,1]),FUN=sum)
        for(i in 1:dim(hts)[1]){
            d[hts[i,1]]<-hts[i,2]
        }
        genbin$unique_reads<-d
        
    }
    mcols(gene_feat)<-mcols(gene_feat)[,names(mcols(genbin))]
    
    gene_feat<-sort(c(gene_feat,genbin))
    gene_feat$txs<-gene_feat$tx_name
    gene_feat$tx_name<-NULL
    
    
    #mcols(genbin)<-NULL
    
    rang<-gene_feat
    a<-gene_feat$txs
    #arrange reads etc etc
    b<-gene_feat$gene_id
    c<-gene_feat$type
    d<-gene_feat$reads
    if(sum(d)<4){
        return(GRangesList())
    }
    
    
    txs_gene<-unique(unlist(a))     
    
    
    gen_bins_junct<-gene_feat
    if(length(txs_gene)<2){
        gen_bins_junct$genes<-b
        gen_bins_junct$txs<-a
        gen_bins_junct$genes_selected<-b
        gen_bins_junct$txs_selected<-a
        gen_bins_junct$reads<-d
        gen_bins_junct$use<-"unique"
        final_ranges<-sort(gen_bins_junct)
        return(final_ranges)
    }
    
    
    
    #first round
    txs_sofar<-txs_gene
    
    mat<-matrix(data=0,nrow=length(d),ncol=length(txs_sofar))
    colnames(mat)<-txs_sofar
    for(i in 1:length(txs_sofar)){
        mat[,i]<-sapply(a,function(x){sum(x==txs_sofar[i])})
    }
    
    nest<-c()
    ident<-c()
    for(i in 1:dim(mat)[2]){
        yes<-which(mat[,i]==1)
        nesti<-c()
        for(j in (1:dim(mat)[2])[-i]){
            yesj<-which(mat[,j]==1)
            if(identical(yes,yesj)){ident<-c(ident,paste(sort(colnames(mat)[c(i,j)]),collapse=";"))}
            #added if length> otherwise txs with same structure are both deleted
            nesti<-c(nesti,sum(yesj%in%yes)==length(yes) & length(mat[,j])>length(yes))
        }
        
        if(sum(nesti)>0){nest<-c(nest,colnames(mat)[i])}
        
    }
    if(length(ident)>0){nest<-nest[!nest%in%unique(sapply(strsplit(ident,";"),"[[",1))]}
    txs_sofar<-txs_sofar[!txs_sofar%in%nest]
    
    change<-1
    
    while(change>0){
        
        mat<-matrix(data=0,nrow=length(d),ncol=length(txs_sofar))
        colnames(mat)<-txs_sofar
        for(i in 1:length(txs_sofar)){
            mat[,i]<-sapply(a,function(x){sum(x==txs_sofar[i])})
        }
        
        mat_orig<-mat
        d_count<-paste(1:length(d),d,sep="_")
        good<-d_count[which(d>0)]
        bad<-d_count[which(d==0)]
        
        txs_good<-c()
        expl_good<-c()
        for(i in 1:dim(mat)[2]){
            expl_good_old<-expl_good
            #if new good feature
            tx<-d_count[which(mat[,i]>0)]
            tx_good<-tx[which(tx%in%good)]
            tx_bad<-tx[which(tx%in%bad)]
            
            if(length(tx_good)==0){next}
            
            if(sum(!tx_good%in%expl_good_old)>0){
                
                tx_torem<-c()
                tx_toscreen<-which(colnames(mat)%in%txs_good)
                if(length(tx_toscreen)>0){
                    for(j in tx_toscreen){
                        tx_contr<-d_count[which(mat[,j]>0)]
                        tx_contr_good<-tx_contr[which(tx_contr%in%good)]
                        tx_contr_bad<-tx_contr[which(tx_contr%in%bad)]
                        if(sum(tx_contr_good%in%tx_good)==length(tx_contr_good)){
                            tx_torem<-c(tx_torem,colnames(mat)[j])
                            
                        }
                        
                        if(length(tx_torem)>0){
                            txs_good<-txs_good[!txs_good%in%tx_torem]
                            
                        }
                    }
                    
                    
                    
                }
                txs_good<-unique(c(txs_good,colnames(mat)[i]))
                expl_good<-unique(c(expl_good,tx_good))
            }
            #if same good feature, but fewer bad INTERNAL features than others.
            if(sum(!tx_good%in%expl_good_old)==0){
                tx_torem<-c()
                tx_toscreen<-which(colnames(mat)%in%txs_good)
                #here a counter when at least one good feature more than competing
                moref<-c()
                for(j in tx_toscreen){
                    tx_contr<-d_count[which(mat[,j]>0)]
                    tx_contr_good<-tx_contr[which(tx_contr%in%good)]
                    tx_contr_bad<-tx_contr[which(tx_contr%in%bad)]
                    moref<-c(moref,sum(!tx_good%in%tx_contr_good)>0)
                    if(sum(tx_contr_good%in%tx_good)==length(tx_contr_good)){
                        
                        if(length(tx_good)>length(tx_contr_good)){
                            tx_torem<-c(tx_torem,colnames(mat)[j])
                        }
                        #here
                        if(length(tx_good)==length(tx_contr_good)){      
                            fi<-which(tx==tx_good[1])
                            la<-which(tx==tx_good[length(tx_good)])
                            int_tx<-tx[fi:la]
                            int_tx_bad<-tx_bad[tx_bad%in%int_tx]
                            
                            contr_fi<-which(tx_contr==tx_contr_good[1])
                            contr_la<-which(tx_contr==tx_contr_good[length(tx_contr_good)])
                            contr_int_tx<-tx_contr[contr_fi:contr_la]
                            contr_int_tx_bad<-tx_contr_bad[tx_contr_bad%in%contr_int_tx]
                            #SAME INTERNAL, TAKE
                            if(length(int_tx_bad)<=length(contr_int_tx_bad)){
                                
                                txs_good<-unique(c(txs_good,colnames(mat)[i]))
                                expl_good<-unique(c(expl_good,tx_good))
                                #LESS INTERNAL, TAKE AND REMOVE OTHER
                                if(length(int_tx_bad)<length(contr_int_tx_bad)){
                                    
                                    tx_torem<-c(tx_torem,colnames(mat)[j])}
                            }
                            
                            
                        }
                    }
                    
                    
                }
                if(length(tx_torem)>0){
                    txs_good<-txs_good[!txs_good%in%tx_torem]
                    txs_good<-unique(c(txs_good,colnames(mat)[i]))
                    expl_good<-unique(c(expl_good,tx_good))
                }
                
                if(length(tx_torem)==0 & sum(moref)==length(tx_toscreen)){
                    txs_good<-unique(c(txs_good,colnames(mat)[i]))
                    expl_good<-unique(c(expl_good,tx_good))
                }
                
                
            }
            
            
        }
        txs_sofar<-txs_good
        change<-abs(length(txs_good)-length(txs_sofar))
    }
    
    gen_bins_junct$genes<-b
    gen_bins_junct$txs<-a
    a<-lapply(a,function(x){x[x%in%txs_sofar]})
    
    genes_sofar<-unique(subset(annotation$trann,annotation$trann$transcript_id%in%txs_sofar)$gene_id)
    
    b<-lapply(b,function(x){x[x%in%genes_sofar]})
    gen_bins_junct$genes_selected<-CharacterList(b)
    gen_bins_junct$txs_selected<-CharacterList(a)
    gen_bins_junct$reads<-d
    check<-sapply(gen_bins_junct$txs,FUN = length)
    use<-rep("shared",length(check))
    use[check==1]<-"unique"
    use[check==0]<-"absent"
    use[check>1]<-"shared"
    
    gen_bins_junct$use<-use
    final_ranges<-sort(gen_bins_junct)
    return(final_ranges)
}


#' Extract possible readthrough sequences (beta) 
#'
#' This function extracts readthrough regions for subsequent analysis
#' @details The function looks for stop-stop pairs after the stop codon of the detected ORF
#' @keywords SaTAnn
#' @author Lorenzo Calviello, \email{calviello.l.bio@@gmail.com}
#' @param tx_name transcript_id
#' @param sequence DNAString object containing the sequence of the transcript
#' @param orf transcript-level ORF coordinates 
#' @param genetic_code GENETIC_CODE table to use
#' @return GRanges object with the set of possible readthrough sequences
#' @seealso \code{\link{detect_translated_orfs}}, \code{\link{select_quantify_ORFs}}
#' @export

get_reathr_seq<-function(tx_name,orf,sequence,genetic_code){
    length<-nchar(sequence)
    u=start(orf)%%3-1
    if(u==-1){u=2}
    pept<-NA
    pept<-unlist(strsplit(as.character(suppressWarnings(translate(subseq(sequence,start=u+1),genetic.code = genetic_code,if.fuzzy.codon = "solve"))),split=""))
    
    
    starts<-pept=="M"
    
    stops<-pept=="*"
    
    start_pos<-((1:length(pept))[starts])*3
    if(length(start_pos)>0){
        start_pos<-start_pos+u-2
    } else {start_pos<-NA}
    
    stop_pos<-((1:length(pept))[stops])*3-3
    if(length(stop_pos)>0){
        #here was -2 at the end, I'll -1, as the GRanges puts 1 more ???
        stop_pos<-stop_pos+u
    } else {stop_pos<-NA}
    stop_pos<-stop_pos[stop_pos>=end(orf)]
    
    vector_starts<-c()
    vector_stops<-c()
    
    if(sum(stops)==0){vector_starts<-u+1; vector_stops<-length}
    
    if(sum(stops)==1){
        vector_starts[1]<-u+1
        vector_starts[2]<-stop_pos+1
        vector_stops[1]<-stop_pos-3
        vector_stops[2]<-length
        
    }
    
    if(sum(stops)>0){
        for(stoppo in 0:(length(stop_pos))){
            start<-stop_pos[stoppo]+1
            if(stoppo==0){
                start<-u+1
            }
            end<-stop_pos[stoppo+1]-3
            if(stoppo==length(stop_pos)){
                end<-length
            }
            
            vector_starts[stoppo+1]<-start
            vector_stops[stoppo+1]<-end
            
        }
        
        
    }
    
    st_st<-data.frame(cbind(vector_starts,vector_stops))
    st_st<-st_st[!is.na(st_st[,"vector_starts"]),]
    st_st<-st_st[!is.na(st_st[,"vector_stops"]),]
    #st_st<-st_st[(st_st[,2]-st_st[,1]>11),]
    gra_par<-GRanges(seqnames = paste(tx_name,sep = "_"),strand = "+",ranges = IRanges(start = st_st[,1],end = st_st[,2]))
    gra_par<-gra_par[end(gra_par)>=end(orf)]
    return(gra_par)
}

#' Analyzed translation on possible readthrough regions (beta)
#'
#' This function uses the multitaper method to look for readthrough translation
#' @details The function looks for stop-stop pairs after the stop codon of the detected ORF
#' @keywords SaTAnn
#' @author Lorenzo Calviello, \email{calviello.l.bio@@gmail.com}
#' @param results_orf Full list of detected ORFs, from \code{select_quantify_ORFs} and \code{annotate_ORFs}
#' @param genome_sequence BSgenome object
#' @param annotation Rannot object containing annotation of CDS and transcript structures (see \code{prepare_annotation_files})
#' @param P_sites GRanges object with P_sites positions
#' @param P_sites_uniq GRanges object with uniquely mapping P_sites positions
#' @param P_sites_uniq_mm_rle Rle signal of uniquely mapping P_sites with mismatches along the transcript
#' @param cutoff_fr_ave \code{cutoff} parameter for the  \code{calc_orf_pval} functions
#' @param genetic_code_table GENETIC_CODE table to use
#' @return GRanges object with the set of translated readthrough regions
#' @seealso \code{\link{detect_translated_orfs}}, \code{\link{select_quantify_ORFs}}, \code{\link{annotate_ORFs}}, \code{\link{get_reathr_seq}}
#' @export

detect_readthrough<-function(results_orf,P_sites,P_sites_uniq,P_sites_uniq_mm,genome_sequence,annotation,genetic_code_table,cutoff_fr_ave=.5){
    P_sites<-P_sites[!P_sites%over%unlist(results_orf$ORFs_genomic_position)]
    P_sites_uniq<-P_sites_uniq[!P_sites_uniq%over%unlist(results_orf$ORFs_genomic_position)]
    P_sites_uniq_mm<-P_sites_uniq_mm[!P_sites_uniq_mm%over%unlist(results_orf$ORFs_genomic_position)]
    readthroughs<-GRanges()
    if(length(P_sites)>4){
        for(i in 1:length(results_orf$ORFs_tx_position)){
            orf_tx<-results_orf$ORFs_tx_position[[i]]
            tx<-orf_tx$transcript_id
            ex_tx<-annotation$exons_txs[[tx]]
            
            #tx_gr<-transcripts_ranges[tx_ok]
            if(as.character(strand(ex_tx)[1])=="+"){
                covtx<-suppressWarnings(unlist(coverage(P_sites,weight = P_sites$score)[ex_tx]))
                if(length(P_sites_uniq)>0){
                    covtx_uniq<-suppressWarnings(unlist(coverage(P_sites_uniq,weight = P_sites_uniq$score)[ex_tx]))
                }
                if(length(P_sites_uniq)==0){
                    covtx_uniq<-suppressWarnings(unlist(coverage(P_sites_uniq)[ex_tx]))
                }
                if(length(P_sites_uniq_mm)>0){
                    covtx_uniq_mm<-suppressWarnings(unlist(coverage(P_sites_uniq_mm,weight = P_sites_uniq_mm$score)[ex_tx]))
                }
                if(length(P_sites_uniq_mm)==0){
                    covtx_uniq_mm<-suppressWarnings(unlist(coverage(P_sites_uniq_mm)[ex_tx]))
                }
                
            }
            if(as.character(strand(ex_tx)[1])=="-"){
                covtx<-suppressWarnings(unlist(unlist(RleList(lapply(coverage(P_sites,weight = P_sites$score)[ex_tx],FUN=rev)))))
                if(length(P_sites_uniq)>0){
                    covtx_uniq<-suppressWarnings(unlist(unlist(RleList(lapply(coverage(P_sites_uniq,weight = P_sites_uniq$score)[ex_tx],FUN=rev)))))
                }
                if(length(P_sites_uniq)==0){
                    covtx_uniq<-suppressWarnings(unlist(unlist(RleList(lapply(coverage(P_sites_uniq)[ex_tx],FUN=rev)))))
                }
                if(length(P_sites_uniq_mm)>0){
                    covtx_uniq_mm<-suppressWarnings(unlist(unlist(RleList(lapply(coverage(P_sites_uniq_mm,weight = P_sites_uniq_mm$score)[ex_tx],FUN=rev)))))
                }
                if(length(P_sites_uniq_mm)==0){
                    covtx_uniq_mm<-suppressWarnings(unlist(unlist(RleList(lapply(coverage(P_sites_uniq_mm)[ex_tx],FUN=rev)))))
                }
                
            }
            seq_tx<-unlist(getSeq(x=genome_sequence,ex_tx))
            
            orfs<-get_reathr_seq(tx_name = tx,orf = orf_tx,sequence = seq_tx,genetic_code = genetic_code_table)
            
            if(length(orfs)==0){next}
            vals1<-calc_orf_pval(ORFs = orfs[1],P_sites_rle = covtx,P_sites_uniq_rle = covtx_uniq,P_sites_uniq_mm_rle = covtx_uniq_mm,cutoff = cutoff_fr_ave)
            if(is.na(vals1$pval) | vals1$pct_fr<.5 | vals1$pval>.05 ){next}
            vals1$Protein<-AAStringSet(as.character(translate(seq_tx[vals1@ranges],genetic.code = genetic_code_table,if.fuzzy.codon = "solve")))
            vals1$ORF_orig_tr<-orf_tx$ORF_id_tr
            vals1$n_stops_readth<-1
            vals1$compatible_id<-CharacterList("")
            vals1$compatible_original_id<-CharacterList("")
            mcsva<-mcols(vals1)
            mcsva[,c("gene_id","gene_biotype","gene_name","transcript_id","transcript_biotype")]<-""
            mcols(vals1)<-mcsva
            vals1$gen_coords<-GRangesList(GRanges())
            
            if(length(orfs)>1){
                keep<-1
                while(keep>0){
                    if(length(orfs)<(keep+1)){break}
                    vals<-calc_orf_pval(ORFs = orfs[keep+1],P_sites_rle = covtx,P_sites_uniq_rle = covtx_uniq,P_sites_uniq_mm_rle = covtx_uniq_mm,cutoff = cutoff_fr_ave)
                    keep<-keep+1
                    
                    if(is.na(vals$pval) | vals$pct_fr<.5 | vals$pval>.05 ){keep<-0}
                    if(!is.na(vals$pval) & vals$pct_fr>.5 & vals$pval<.05 ){
                        end(vals1)<-end(vals)
                        vals1<-calc_orf_pval(ORFs = vals1,P_sites_rle = covtx,P_sites_uniq_rle = covtx_uniq,P_sites_uniq_mm_rle = covtx_uniq_mm,cutoff = cutoff_fr_ave)
                        vals1$Protein<-AAStringSet(as.character(translate(seq_tx[vals1@ranges],genetic.code = genetic_code_table,if.fuzzy.codon = "solve")))
                        vals1$ORF_orig_tr<-orf_tx$ORF_id_tr
                        vals1$n_stops_readth<-keep
                        vals1$compatible_id<-CharacterList("")
                        vals1$compatible_original_id<-CharacterList("")
                        mcsva<-mcols(vals1)
                        mcsva[,c("gene_id","gene_biotype","gene_name","transcript_id","transcript_biotype")]<-""
                        mcols(vals1)<-mcsva
                        
                    }
                }
            }
            readthroughs<-unique(suppressWarnings(c(readthroughs,vals1)))
            mcs<-mcols(readthroughs)
            mcs_orfs_orig<-mcs$ORF_orig_tr
            mcs_orfs<-mcs$ORF_id_tr
            mcs$ORF_orig_tr<-NULL
            mcs$ORF_id_tr<-NULL
            dups<-duplicated(mcs)
            readthroughs<-readthroughs[!dups]
            for(j in 1:length(readthroughs)){
                orig_orf<-readthroughs$ORF_orig_tr[j]
                mcs_orig<-mcols(results_orf$ORFs_tx_position[[which(names(results_orf$ORFs_tx_position)==orig_orf)]])[,c("gene_id","gene_biotype","gene_name","transcript_id","transcript_biotype")]
                mcols(readthroughs)[j,c("gene_id","gene_biotype","gene_name","transcript_id","transcript_biotype")]<-mcs_orig
                readthroughs$gen_coords[j]<-from_tx_togen(readthroughs[j],annotation$exons_txs[as.character(seqnames(readthroughs[j]))],annotation$introns_txs[[as.character(seqnames(readthroughs[j]))]])
                readthroughs$compatible_id[j]<-CharacterList(mcs_orfs[which(mcs$Protein==mcs[j,"Protein"])[-j]])
                readthroughs$compatible_original_id[j]<-CharacterList(mcs_orfs_orig[which(mcs$Protein==mcs[j,"Protein"])[-j]])
                
            }
            dups<-duplicated(readthroughs$Protein) & duplicated(readthroughs$P_sites_raw)
            
            if(sum(dups)>0){readthroughs<-readthroughs[!dups]}
        }
    }
    dups<-duplicated(readthroughs$Protein) & duplicated(readthroughs$P_sites_raw)
    
    if(sum(dups)>0){readthroughs<-readthroughs[!dups]}
    return(readthroughs)
}

#' Select and quantify ORF translation
#'
#' This function selects a subset of detected ORFs and quantifies their translation
#' @details ORFs are first selected using the same method as in the \code{select_txs} function, but 
#' using ORF features (ORF structures are treated as transcript structures).\cr
#' Ribo-seq coverage (reads/length) on bins and junctions (set to a length of 60) is used to derive a scaling factor (0-1) for each ORF,
#' which indicates how much of the ORF coverage can be assigned to such ORF (1 when no other ORF is present). 
#' When no unique features are present on an ORF, an adjusted scaling value is calculated subtracting coverage expected from a ORF with a unique feature. 
#' When no unique features are present on any ORF, scaling values are calculated assuming uniform coverage on each ORF.\cr
#' ORFs are then further filtered to exclude lowly translated ORFs and quantification/selection is re-iterated until no ORF is further filtered out. 
#' Percentage of total gene translation and length-adjusted quantification estimates are produced.
#' More details about the quantificatin procedure can be found in the SaTAnn manuscript.\cr\cr
#' Additional columns are added to the ORFs_tx object:\cr
#' \code{TrP}: TrP_raw values (spectral coefficient) from \code{detect_translated_ORFs} divided by the ORF scaling value.\cr
#' \code{ORF_pct_TrP}:  Percentage of gene translation output for the ORF, derived using TrP values.\cr
#' \code{ORF_pct_TrP_pN}: Percentage of gene translation ouptut (adjusted by length) for the ORF, derived using TrP values.\cr
#' \code{P_sites}: P_sites_raw value from \code{detect_translated_ORFs} divided by the ORF scaling value.\cr
#' \code{ORF_pct_P_sites}: Percentage of gene translation output for the ORF, derived using P_sites values.\cr
#' \code{ORF_pct_P_sites_pN}: Percentage of gene translation ouptut (adjusted by length) for the ORF, derived using P_sites values.\cr
#' \code{unique_features_reads}:  initial number of reads on each unique ORF feature. \code{NA} when no unique feature is present.\cr
#' \code{adj_unique_features_reads}:  final number of reads on each unique ORF feature after the ORF filtering/quantification procedure. \code{NA} when no unique feature is present.\cr
#' \code{scaling_factors}: Set of 3 scaling factors assigned to the ORF using intial unique ORF features, after adjusting for the presence of ORFs with no unique features, 
#' and final scaling factor after correcting for total Ribo-seq coverage on the gene.
#' @keywords SaTAnn
#' @author Lorenzo Calviello, \email{calviello.l.bio@@gmail.com}
#' @param results_ORFs Full list of detected ORFs, from \code{detect_translated_ORFs}
#' @param P_sites GRanges object with P_sites positions
#' @param P_sites_uniq GRanges object with uniquely mapping P_sites positions
#' @param cutoff_cums cutoff to select ORFs until <x> percentage of total gene translation. Defaults to 99
#' @param cutoff_pct minimum percentage of total gene translation for an ORF to be selected. Defaults to 1
#' @param cutoff_P_sites minimum number of P_sites assigned to the ORF to be selected. Defaults to 10
#' @param optimiz (Beta) should numerical optimization (minimizing distance between observed coverage and expected coverage) 
#' be used to quantify ORF translation? Defaults to FALSE
#' @param scaling Additional scaling value taking into account total signal on the detected ORFs to adjust quantification estimates (recommended). Defaults to TRUE
#' @return modified \code{results_ORFs} object with the selected ORFs including quantification estimates.
#' @seealso \code{\link{detect_translated_orfs}}, \code{\link{select_txs}}
#' @export


select_quantify_ORFs<-function(results_ORFs,P_sites,P_sites_uniq,cutoff_cums=NA,cutoff_pct=2,cutoff_P_sites=NA,optimiz=FALSE,scaling=TRUE){
    
    select_feat <- results_ORFs[["ORFs_features"]]
    select_feats<-unlist(select_feat)
    select_feats_jun<-select_feats[select_feats$type=="J"]
    ran_j<-select_feats_jun@ranges
    #startend!
    df<-data.frame(stend=paste(ran_j@start,end(ran_j),sep="_"),orfs=names(ran_j),stringsAsFactors=F)
    tab_j<-as.matrix(table(df$stend,df$orfs))
    
    orfs_print<-colnames(tab_j)
    
    orfs_print<-apply(tab_j,MARGIN=1,FUN=function(x){orfs_print[which(x>0)]})
    orfs_print2<-orfs_print
    names(orfs_print2)<-NULL
    
    orfs <- results_ORFs[["ORFs_genomic_position"]]
    stra<-as.character(select_feats[1]@strand)
    
    df_orfs_ex<-data.frame(orfs)
    names(df_orfs_ex)<-c("tx_id","tx_name","tx_chrom","exon_start","exon_end","width","tx_strand")
    df_orfs_ex$exon_rank<-c(unlist(sapply(as.numeric(table(df_orfs_ex$tx_id)),FUN=function(x){1:x})))
    df_orfs<-data.frame(tx_id=sort(unique(df_orfs_ex$tx_id)),tx_name=as.character(names(orfs)),tx_chrom=as.character(unique(seqnames(orfs[[1]]))),tx_start=min(start(orfs)),tx_end=max(end(orfs)),tx_strand=as.character(unique(strand(orfs[[1]]))),stringsAsFactors=F)
    df_genes<-data.frame(tx_name=as.character(names(orfs)),gene_id="OFF")
    orfann<-suppressWarnings(makeTxDb(transcripts=df_orfs,splicings=df_orfs_ex,genes=df_genes))
    #disjointExons(orfann)
    #gene_feat<-convertToSGFeatures(convertToTxFeatures(orfann),coerce=T)
    
    exbin<-disjointExons(orfann)
    
    
    d<-rep(0,length(exbin))
    
    hts<-findOverlaps(exbin,P_sites,ignore.strand=F)
    hts<-cbind(queryHits(hts),P_sites[subjectHits(hts)]$score)
    if(length(hts)==0){
        return(GRangesList())
        
    }
    hts<-aggregate(x = hts[,2],list(hts[,1]),FUN=sum)
    for(i in 1:dim(hts)[1]){
        d[hts[i,1]]<-hts[i,2]
    }
    
    d2<-rep(0,length(exbin))
    
    hts<-findOverlaps(exbin,P_sites_uniq,ignore.strand=F)
    hts<-cbind(queryHits(hts),P_sites_uniq[subjectHits(hts)]$score)
    
    if(length(hts)>0){
        hts<-aggregate(x = hts[,2],list(hts[,1]),FUN=sum)
        for(i in 1:dim(hts)[1]){
            d2[hts[i,1]]<-hts[i,2]
        }
    }
        
    
    exbin$reads<-d
    exbin$unique_reads<-d2
    
    exbin<-GRanges(exbin)
    
    exbin$gene_id<-NULL
    exbin$exonic_part<-NULL
    exbin$X<-NULL
    mcols(exbin)<-exbin[,c("reads","unique_reads","tx_name")]
    gene_feat<-exbin
    gene_feat$type<-rep("E",length(exbin))
    
    if(length(select_feats_jun)>0){
        junc<-select_feats_jun
        names(junc)<-NULL
        reads_j<-junc$reads
        reads_j_uniq<-junc$unique_reads
        mcols(junc)<-NULL
        junc$X<-junc
        junc$reads<-reads_j
        junc$unique_reads<-reads_j_uniq
        
        orfs_jj<-orfs_print2[match(df$stend,names(orfs_print))]
        #junc$tx_name<-as(orfs_jj,"CharacterList")
        mcols(junc)<-junc[,c("reads","unique_reads")]
        tx_ex<-exbin$tx_name
        mcols(exbin)<-exbin[,c("reads","unique_reads")]
        
        gene_feat<-c(exbin,junc)
        if(is(orfs_jj,"CompressedList")){
            gene_feat$tx_name<-CharacterList(c(tx_ex,orfs_jj))
        }
        
        if(!is(orfs_jj,"CompressedList")){
            if(is.list(orfs_jj)){
                gene_feat$tx_name<-CharacterList(c(tx_ex,CharacterList(orfs_jj)))
            }
            if(!is.list(orfs_jj)){
                gene_feat$tx_name<-CharacterList(c(tx_ex,CharacterList(as.list(orfs_jj))))
            }
        }
        
        gene_feat$type<-c(rep("E",length(exbin)),rep("J",length(junc)))
    }
    
    #first round
    gene_feat_cp<-gene_feat
    #change!
    gene_feat<-gene_feat_cp[!duplicated(paste(GRanges(gene_feat_cp),gene_feat_cp$type,sep="_"))]
    txs_gene<-unique(unlist(gene_feat$tx_name))
    txs_sofar<-txs_gene
    
    
    d<-gene_feat$reads
    a<-gene_feat$tx_name
    
    
    mat<-matrix(data=0,nrow=length(d),ncol=length(txs_sofar))
    colnames(mat)<-txs_sofar
    for(i in 1:length(txs_sofar)){
        mat[,i]<-sapply(a,function(x){sum(x==txs_sofar[i])})
    }
    
    #TAKE AWAY NESTED TXS
    nest<-c()
    ident<-c()
    for(i in 1:dim(mat)[2]){
        yes<-which(mat[,i]==1)
        nesti<-c()
        for(j in (1:dim(mat)[2])[-i]){
            yesj<-which(mat[,j]==1)
            if(identical(yes,yesj)){ident<-c(ident,paste(sort(colnames(mat)[c(i,j)]),collapse=";"))}
            #added if length> otherwise txs with same structure are both deleted
            nesti<-c(nesti,sum(yesj%in%yes)==length(yes) & length(mat[,j])>length(yes))
        }
        
        if(sum(nesti)>0){nest<-c(nest,colnames(mat)[i])}
        
    }
    if(length(ident)>0){nest<-nest[!nest%in%unique(sapply(strsplit(ident,";"),"[[",1))]}
    txs_sofar<-txs_sofar[!txs_sofar%in%nest]
    change<-1
    
    while(change>0){
        
        mat<-matrix(data=0,nrow=length(d),ncol=length(txs_sofar))
        colnames(mat)<-txs_sofar
        for(i in 1:length(txs_sofar)){
            mat[,i]<-sapply(a,function(x){sum(x==txs_sofar[i])})
        }
        
        mat_orig<-mat
        d_count<-paste(1:length(d),d,sep="_")
        good<-d_count[which(d>0)]
        bad<-d_count[which(d==0)]
        
        txs_good<-c()
        expl_good<-c()
        for(i in 1:dim(mat)[2]){
            expl_good_old<-expl_good
            #if new good feature
            tx<-d_count[which(mat[,i]>0)]
            tx_good<-tx[which(tx%in%good)]
            tx_bad<-tx[which(tx%in%bad)]
            
            if(length(tx_good)==0){next}
            
            if(sum(!tx_good%in%expl_good_old)>0){
                
                tx_torem<-c()
                tx_toscreen<-which(colnames(mat)%in%txs_good)
                if(length(tx_toscreen)>0){
                    for(j in tx_toscreen){
                        tx_contr<-d_count[which(mat[,j]>0)]
                        tx_contr_good<-tx_contr[which(tx_contr%in%good)]
                        tx_contr_bad<-tx_contr[which(tx_contr%in%bad)]
                        if(sum(tx_contr_good%in%tx_good)==length(tx_contr_good)){
                            tx_torem<-c(tx_torem,colnames(mat)[j])
                            
                        }
                        
                        if(length(tx_torem)>0){
                            txs_good<-txs_good[!txs_good%in%tx_torem]
                            
                        }
                    }
                    
                    
                    
                }
                txs_good<-unique(c(txs_good,colnames(mat)[i]))
                expl_good<-unique(c(expl_good,tx_good))
            }
            #if same good feature, but fewer bad INTERNAL features than others.
            if(sum(!tx_good%in%expl_good_old)==0){
                tx_torem<-c()
                tx_toscreen<-which(colnames(mat)%in%txs_good)
                #here a counter when at least one good feature more than competing
                moref<-c()
                for(j in tx_toscreen){
                    tx_contr<-d_count[which(mat[,j]>0)]
                    tx_contr_good<-tx_contr[which(tx_contr%in%good)]
                    tx_contr_bad<-tx_contr[which(tx_contr%in%bad)]
                    moref<-c(moref,sum(!tx_good%in%tx_contr_good)>0)
                    #if same good features in competing tx, check bad internal ones
                    if(sum(tx_contr_good%in%tx_good)==length(tx_contr_good)){
                        
                        if(length(tx_good)>length(tx_contr_good)){
                            tx_torem<-c(tx_torem,colnames(mat)[j])
                        }
                        #here
                        if(length(tx_good)==length(tx_contr_good)){      
                            fi<-which(tx==tx_good[1])
                            la<-which(tx==tx_good[length(tx_good)])
                            int_tx<-tx[fi:la]
                            int_tx_bad<-tx_bad[tx_bad%in%int_tx]
                            
                            contr_fi<-which(tx_contr==tx_contr_good[1])
                            contr_la<-which(tx_contr==tx_contr_good[length(tx_contr_good)])
                            contr_int_tx<-tx_contr[contr_fi:contr_la]
                            contr_int_tx_bad<-tx_contr_bad[tx_contr_bad%in%contr_int_tx]
                            #SAME INTERNAL, TAKE
                            if(length(int_tx_bad)<=length(contr_int_tx_bad)){
                                
                                txs_good<-unique(c(txs_good,colnames(mat)[i]))
                                expl_good<-unique(c(expl_good,tx_good))
                                #LESS INTERNAL, TAKE AND REMOVE OTHER
                                if(length(int_tx_bad)<length(contr_int_tx_bad)){
                                    
                                    tx_torem<-c(tx_torem,colnames(mat)[j])}
                            }
                            
                            
                        }
                    }
                    
                    
                }
                if(length(tx_torem)>0){
                    txs_good<-txs_good[!txs_good%in%tx_torem]
                    txs_good<-unique(c(txs_good,colnames(mat)[i]))
                    expl_good<-unique(c(expl_good,tx_good))
                }
                
                if(length(tx_torem)==0 & sum(moref)==length(tx_toscreen)){
                    txs_good<-unique(c(txs_good,colnames(mat)[i]))
                    expl_good<-unique(c(expl_good,tx_good))
                }
                
                
            }
            
            
        }
        txs_sofar<-txs_good
        change<-abs(length(txs_good)-length(txs_sofar))
    }
    
    gene_feat$ORF_id_tr<-gene_feat$tx_name
    gene_feat$tx_name<-NULL
    a<-gene_feat$ORF_id_tr
    a<-lapply(a,function(x){x[x%in%txs_good]})
    gene_feat$ORF_id_tr_selected<-CharacterList(a)
    
    check<-sapply(gene_feat$ORF_id_tr,FUN = length)
    use<-rep("shared",length(check))
    use[check==1]<-"unique"
    use[check==0]<-"absent"
    use[check>1]<-"shared"
    gene_feat$use_ORF<-use
    
    check<-sapply(gene_feat$ORF_id_tr_selected,FUN = length)
    use<-rep("shared",length(check))
    use[check==1]<-"unique"
    use[check==0]<-"absent"
    use[check>1]<-"shared"
    gene_feat$use_ORF_selected<-use
    
    final_ranges<-sort(gene_feat)
    sel_feats<-list()
    for(i in txs_good){
        featexs<-gene_feat[gene_feat$type=="E"]
        featjuns<-gene_feat[gene_feat$type=="J"]
        
        
        ok<-featexs[featexs%over%orfs[[i]]]
        if(length(featjuns)>0){
            ok<-sort(c(ok,featjuns[which(featjuns%in%gaps(orfs[[i]]))]))
        }
        a<-sapply(ok$ORF_id_tr,function(x){length(x[x%in%i])})
        ok<-ok[a>0]
        sel_feats[[i]]<-unique(ok)
    }
    all_feats<-results_ORFs$selected_ORFs_features
    selected_ORFs<-lapply(results_ORFs,FUN=function(x){x[names(x)%in%txs_good]})
    selected_ORFs$selected_ORFs_features<-sel_feats
    
    #quantif 
    
    
    results_ORFs<-selected_ORFs
    feats<-results_ORFs$selected_ORFs_features
    orfs_tx<-results_ORFs$ORFs_tx_position
    orfs_tx<-lapply(orfs_tx,function(x){
        cols<-mcols(x)
        cols[,c("TrP","ORF_pct_TrP","ORF_pct_TrP_pN","P_sites","ORF_pct_P_sites","ORF_pct_P_sites_pN")]<-NA
        cols[,"unique_features_reads"]<-NumericList("")
        cols[,"adj_unique_features_reads"]<-NumericList("")
        cols[,"scaling_factors"]<-NumericList("")
        mcols(x)<-cols
        x
    })
    
    #first round of unq
    
    orf_del<-c("")
    counter<-1
    while(length(orf_del)>0){
        
        gene_feat$ORF_id_tr_selected_quant<- gene_feat$ORF_id_tr_selected
        gene_feat$use_ORF_selected_quant<-gene_feat$use_ORF_selected
        feats<-feats[!names(feats)%in%orf_del]
        nms<-sapply(feats,length)
        nms<-rep(names(nms),nms)
        feats<-unlist(GRangesList(unlist(feats)))
        names(feats)<-nms
        
        feats$ORF_id_tr_selected<-CharacterList(lapply(feats$ORF_id_tr_selected,function(x){
            unique(x[!x%in%orf_del])
        }))
        
        gene_feat$ORF_id_tr_selected_quant<-CharacterList(lapply(gene_feat$ORF_id_tr_selected,function(x){
            unique(x[!x%in%orf_del])
        }))
        lens<-sapply(feats$ORF_id_tr_selected,length)
        lens2<-sapply(gene_feat$ORF_id_tr_selected_quant,length)
        gene_feat$use_ORF_selected_quant<-"shared"
        gene_feat$use_ORF_selected_quant[lens2==1]<-"unique"
        gene_feat$use_ORF_selected_quant[lens2==0]<-"absent"
        
        feats$use_ORF_selected<-"shared"
        feats$use_ORF_selected[lens==1]<-"unique"
        feats<-split(feats,names(feats))
        
        orfs_tx<-orfs_tx[!names(orfs_tx)%in%orf_del]
        
        
        unqs<-rep(NA,length(feats))
        names(unqs)<-names(feats)
        for(i in names(feats)){
            feat<-feats[[i]]
            orf_tx<-orfs_tx[[i]]
            cov_feat<-feat$reads/width(feat)
            js<-feat$type=="J"
            if(sum(js)>0){
                cov_feat[js]<-feat[js]$reads/60
            }
            unq<-feat$use_ORF_selected=="unique"
            if(sum(unq)>0){
                unq_rat<-mean(cov_feat[unq])/mean(cov_feat)
                if(unq_rat>1){unq_rat<-1}
                orfs_tx[[i]]$unique_features_reads<-NumericList(feat$reads[unq])
                orfs_tx[[i]]$adj_unique_features_reads<-NumericList(feat$reads[unq])
                
                
            }
            if(sum(unq)==0){
                orfs_tx[[i]]$unique_features_reads<-NumericList(NA)
                unq_rat<-NA
            }
            unqs[i]<-unq_rat
        }
        unqs_adj<-unqs
        unqnas<-unqs_adj[is.na(unqs_adj)]
        unqs_okk<-unqs_adj[!is.na(unqs_adj)]
        #NA_adjustment
        
        #if all NAs
        if(length(unqs_okk)==0){
            unqs_na<-names(unqs_adj[is.na(unqs_adj)])
            for(i in unqs_na){
                feat<-feats[[i]]
                cov_feat<-feat$reads/width(feat)
                js<-feat$type=="J"
                if(sum(js)>0){
                    cov_feat[js]<-feat$reads[js]/60
                }
                cov_adj<-cov_feat
                for(j in 1:length(feat)){
                    fea<-feat[j]
                    txs_fea<-unlist(fea$ORF_id_tr_selected)
                    nass<-txs_fea%in%unqs_na
                    txs_fea<-txs_fea[!nass]
                    adj<-cov_feat[j]-(cov_feat[j]*sum(unqs_adj[txs_fea]))
                    if(sum(nass)>1){
                        adj<-(cov_feat[j]-(cov_feat[j]*sum(unqs_adj[txs_fea])))/sum(nass)
                    }
                    if(length(txs_fea)==0){
                        adj<-cov_feat[j]/(sum(nass))
                    }
                    if(adj<0){adj=0}
                    cov_adj[j]<-adj
                }
                unq<-mean(cov_adj)/mean(cov_feat)
                if(unq>1){unq<-1}
                unqs_adj[i]<-unq
            }
        }
        unqnas<-unqs_adj[is.na(unqs_adj)]
        unqs_okk<-unqs_adj[!is.na(unqs_adj)]
        
        #if all 0
        
        if(sum(unqs_okk==0)==length(unqs_adj)){
            unqs_zero<-names(unqs_okk)
            for(i in unqs_zero){
                feat<-feats[[i]]
                cov_feat<-feat$reads/width(feat)
                js<-feat$type=="J"
                if(sum(js)>0){
                    cov_feat[js]<-feat$reads[js]/60
                }
                cov_adj<-cov_feat
                for(j in 1:length(feat)){
                    fea<-feat[j]
                    txs_fea<-unlist(fea$ORF_id_tr_selected)
                    nass<-txs_fea%in%unqs_zero
                    txs_fea<-txs_fea[!nass]
                    adj<-cov_feat[j]-(cov_feat[j]*sum(unqs_okk[txs_fea]))
                    if(sum(nass)>1){
                        adj<-(cov_feat[j]-(cov_feat[j]*sum(unqs_okk[txs_fea])))/sum(nass)
                    }
                    if(length(txs_fea)==0){
                        adj<-cov_feat[j]/(sum(nass))
                    }
                    if(adj<0){adj=0}
                    cov_adj[j]<-adj
                }
                unq<-mean(cov_adj)/mean(cov_feat)
                if(unq>1){unq<-1}
                unqs_okk[i]<-unq
                unqs_adj[i]<-unq
                
            }
        }
        unqnas<-unqs_adj[is.na(unqs_adj)]
        unqs_okk<-unqs_adj[!is.na(unqs_adj)]
        
        if(length(unqnas)>0){
            nonas<--1
            
            while(nonas<0){
                
                prev_nas<-length(unqnas)
                if(length(unqs_okk)>0){
                    for(i in names(unqnas)){
                        unqs_okk_noi<-unqs_okk[names(unqs_okk)!=i]
                        feat<-feats[[i]]
                        orf_tx<-orfs_tx[[i]]
                        cov_feat<-feat$reads/width(feat)
                        js<-feat$type=="J"
                        if(sum(js)>0){
                            cov_feat[js]<-feat$reads[js]/60
                        }
                        adj_use<-feat$use_ORF_selected
                        adj_cov_feat<-cov_feat
                        for(j in 1:length(feat)){
                            txs_fea<-feat$ORF_id_tr_selected[[j]]
                            unqs_okk_noi_feat<-unqs_okk_noi[names(unqs_okk_noi)%in%txs_fea]
                            txs_fea_adj<-txs_fea[!txs_fea%in%names(unqs_okk_noi)]
                            adj<-cov_feat[j]
                            usef<-"shared"
                            if(length(txs_fea_adj)==1){usef<-"unique"}
                            
                            if(length(unqs_okk_noi_feat[!is.na(unqs_okk_noi_feat)])>0){
                                adj<-adj-(adj*sum(unqs_okk_noi_feat[!is.na(unqs_okk_noi_feat)]))     
                                if(adj<0){adj=0}
                            }
                            adj_use[j]<-usef
                            adj_cov_feat[j]<-adj
                        }
                        
                        unq<-adj_use=="unique"
                        
                        if(sum(unq)>0){
                            unq_rat<-mean(adj_cov_feat[adj_use=="unique"])/mean(adj_cov_feat)
                            if(mean(adj_cov_feat)==0){unq_rat<-0}
                            if(unq_rat>1){unq_rat<-1}
                            orfs_tx[[i]]$adj_unique_features_reads<-NumericList(feat$reads[unq])
                            
                        }
                        if(sum(unq)==0){
                            orfs_tx[[i]]$adj_unique_features_reads<-NumericList(NA)
                            unq_rat<-NA
                        }
                        unqs_adj[i]<-unq_rat
                        
                        
                    }
                    unqnas<-unqs_adj[is.na(unqs_adj)]
                    unqs_okk<-unqs_adj[!is.na(unqs_adj)]
                    nonas<-length(unqnas)-prev_nas
                    
                }
                
                
            }
            #if still NAs
            if(sum(is.na(unqs_adj))>0){
                unqs_na<-names(unqs_adj[is.na(unqs_adj)])
                for(i in unqs_na){
                    feat<-feats[[i]]
                    cov_feat<-feat$reads/width(feat)
                    js<-feat$type=="J"
                    if(sum(js)>0){
                        cov_feat[js]<-feat[js]$reads/60
                    }
                    cov_adj<-cov_feat
                    for(j in 1:length(feat)){
                        fea<-feat[j]
                        txs_fea<-unlist(fea$ORF_id_tr_selected)
                        nass<-txs_fea%in%unqs_na
                        txs_fea<-txs_fea[!nass]
                        adj<-cov_feat[j]-(cov_feat[j]*sum(unqs_adj[txs_fea]))
                        if(sum(nass)>1){
                            adj<-(cov_feat[j]-(cov_feat[j]*sum(unqs_adj[txs_fea])))/sum(nass)
                        }
                        if(length(txs_fea)==0){
                            adj<-cov_feat[j]/(sum(nass))
                        }
                        if(adj<0){adj=0}
                        cov_adj[j]<-adj
                    }
                    unq<-mean(cov_adj)/mean(cov_feat)
                    if(unq>1){unq<-1}
                    unqs_adj[i]<-unq
                }
                
            }
            
            
        }
        
        
        # 
        # if(sum(unqs_adj>0)==0){
        #      nmmm<-names(unqs_adj)
        #      unqs_adj<-rep(1/length(nmmm),length(nmmm))
        #      names(unqs_adj)<-nmmm
        # }
        
        orftxs<-unlist(results_ORFs[["ORFs_tx_position"]])
        unqs_optim<-unqs_adj
        
        if(!is(feats,"GRangesList")){feats<-GRangesList(feats)}
        featsall<-sort(unlist(feats))
        featsall<-featsall[!duplicated(paste(GRanges(featsall),featsall$type,sep="_"))]
        
        #optimization option
        
        if(optimiz==TRUE){
            unqs_optim_noopt<-unqs_optim
            cov_ps_unqs<-orftxs$P_sites_raw/width(orftxs)
            names(cov_ps_unqs)<-orftxs$ORF_id_tr
            cov_ps_unqs<-cov_ps_unqs[names(unqs_adj)]
            featsall$coverage<-featsall$reads/width(featsall)
            jxs<-featsall$type=="J"
            featsall$coverage[jxs]<-featsall$reads[jxs]/60
            
            vals<-cov_ps_unqs*unqs_optim
            expect<-unlist(lapply(featsall$ORF_id_tr_selected,function(x){sum(vals[x])}))
            maxdist<-sum(abs(expect-featsall$coverage))
            
            calc_dist_exp<-function(unqs_optim,maxval=maxdist){
                vals<-cov_ps_unqs*unqs_optim
                #sizzs<-width(featsall)
                #sizzs[featsall$type=="J"]<-60
                
                expect<-unlist(lapply(featsall$ORF_id_tr_selected,function(x){sum(vals[x])}))
                if(sum(expect)>0){
                    expect<-expect/sum(expect)
                }
                uniq_feats<-featsall$use_ORF_selected=="unique"
                trucov<-featsall$coverage
                if(sum(expect)>0){
                    trucov<-trucov/sum(trucov)
                }
                #or do something different, like minimize % error per each feature after adding pseudocount
                if(sum(trucov>0 & expect==0)>0){return(maxval+1)}
                
                #sum(abs(expect-featsall$coverage)*log(sizzs+1))
                #-cor.test(trucov,expect,method = "p")$estimate
                mean(abs(expect-trucov))
            }
            #inspired by Alpine: https://github.com/mikelove/alpine/blob/master/R/estimate_abundance.R
            optimm<-optim(par = unqs_optim,fn = calc_dist_exp,lower = rep(0,length(unqs_optim)),upper = rep(1,length(unqs_optim)),method = "L-BFGS-B")
            unqs_optim<-optimm$par
            if(sum(unqs_optim>0)==0){unqs_optim<-unqs_optim_noopt}
        }
        
        if(scaling==TRUE){
            
            #scale to adjust coverage?
            cov_ps_unqs<-orftxs$P_sites_raw/width(orftxs)
            names(cov_ps_unqs)<-orftxs$ORF_id_tr
            cov_ps_unqs<-cov_ps_unqs[names(unqs_optim)]
            
            featsall$coverage<-featsall$reads/width(featsall)
            jxs<-featsall$type=="J"
            featsall$coverage[jxs]<-featsall$reads[jxs]/60
            
            cov_ps_unqs_adj<-cov_ps_unqs*unqs_optim
            cov_unpcts<-NumericList(lapply(featsall$ORF_id_tr_selected,function(x){cov_ps_unqs_adj[x]}))
            cov_unpcts<-sum(cov_unpcts)
            
            scale_f<-sum(featsall$coverage)/sum(cov_unpcts)
            unqs_optim<-unqs_optim*scale_f
        }
        
        
        #apply quantification factor
        
        for(i in names(feats)){
            feat<-feats[[i]]
            orf_tx<-orfs_tx[[i]]
            trpk<-orf_tx$TrP_raw
            ps<-orf_tx$P_sites_raw
            unq_rat<-unqs_optim[i]
            trpk_norm<-trpk*unq_rat
            ps_norm<-ps*unq_rat
            
            orfs_tx[[i]]$TrP<-trpk_norm
            orfs_tx[[i]]$P_sites<-ps_norm
            scalss<-c(unqs[i],unqs_adj[i],unqs_optim[i])
            names(scalss)<-c("unq_feats","adj_feats","optim_feats")
            orfs_tx[[i]]$scaling_factors<-NumericList(round(scalss,digits = 4))
            
        }
        
        genes<-unlist(GRangesList(orfs_tx))$gene_id
        genes_unq<-unique(genes)
        orfs_genes<-split(unlist(GRangesList(orfs_tx)),f=unlist(GRangesList(orfs_tx))$gene_id)
        orfs_genes<-GRangesList(lapply(orfs_genes,FUN=function(x){
            xnot<-x[is.na(x$TrP)]
            x<-x[!is.na(x$TrP)]
            x$ORF_pct_TrP<-x$TrP*100/sum(x$TrP)
            #added this when genes, mostly overlapping ones, get no reads
            if(sum(x$TrP)==0){x$ORF_pct_TrP<-0}
            
            x$ORF_pct_TrP_pN<-(x$TrP/width(x))*100/sum(x$TrP/width(x))
            #added this when genes, mostly overlapping ones, get no reads
            if(sum(x$TrP)==0){x$ORF_pct_TrP<-0;x$ORF_pct_TrP_pN<-0}
            
            
            x<-c(x[order(x$ORF_pct_TrP,decreasing=T)],xnot)
            
            xnot<-x[is.na(x$P_sites)]
            x<-x[!is.na(x$P_sites)]
            x$ORF_pct_P_sites<-x$P_sites*100/sum(x$P_sites)
            x$ORF_pct_P_sites_pN<-(x$P_sites/width(x))*100/sum(x$P_sites/width(x))
            #added this when genes, mostly overlapping ones, get no reads
            
            if(sum(x$P_sites)==0){x$ORF_pct_P_sites<-0;x$ORF_pct_P_sites_pN<-0}
            
            c(x[order(x$ORF_pct_P_sites,decreasing=T)],xnot)
            
            
        }))
        
        orf_del_cums<-c()
        orf_del_iso<-c()
        orf_del_ps<-c()
        
        list_genes<-list()
        list_genes_feats<-list()
        
        cums_list<-list()
        for(h in names(orfs_genes)){
            x<-orfs_genes[[h]]
            cums<-cumsum(x$ORF_pct_P_sites)
            names(cums)<-x$ORF_id_tr
            cums_list[[h]]<-cums
        }
        if(is.numeric(cutoff_cums)){
            orf_del_cums<-lapply(cums_list,function(x){
                del<-which(x>cutoff_cums)
                delna<-which(is.na(x))
                if(length(del)==1){del<-c()}
                if(length(del)>1){del<-del[-1]}
                if(length(delna)==1){del<-c(del,delna)}
                del
                
            })
            names(orf_del_cums)<-NULL
            orf_del_cums<-names(unlist(orf_del_cums))
        }
        
        if(is.numeric(cutoff_pct)){
            orfgrlun<-unlist(orfs_genes)
            orf_del_iso<-unique(c(orf_del_iso,orfgrlun$ORF_id_tr[which(orfgrlun$ORF_pct_P_sites<cutoff_pct)]))
        }
        
        if(is.numeric(cutoff_P_sites)){
            orfgrlun<-unlist(orfs_genes)
            orf_del_ps<-orfgrlun$ORF_id_tr[which(orfgrlun$P_sites<cutoff_P_sites)]
            
        }
        
        orf_del<-unique(c(orf_del_cums,orf_del_iso,orf_del_ps))
        
        fs<-unlist(orfs_genes)
        #put isovalues
        for(g in names(orfs_tx)){
            orfs_tx[[g]]$ORF_pct_TrP<-fs$ORF_pct_TrP[fs$ORF_id_tr==g]
            orfs_tx[[g]]$ORF_pct_TrP_pN<-fs$ORF_pct_TrP_pN[fs$ORF_id_tr==g]
            orfs_tx[[g]]$ORF_pct_P_sites<-fs$ORF_pct_P_sites[fs$ORF_id_tr==g]
            orfs_tx[[g]]$ORF_pct_P_sites_pN<-fs$ORF_pct_P_sites_pN[fs$ORF_id_tr==g]
        }
        counter<-counter+1
    }
    
    results_ORFs$ORFs_tx_position<-orfs_tx
    results_ORFs$ORFs_genomic_position<-results_ORFs$ORFs_genomic_position[names(results_ORFs$ORFs_tx_position)]
    results_ORFs$ORFs_features<-results_ORFs$ORFs_features[names(results_ORFs$ORFs_tx_position)]
    results_ORFs$tx_annotated_ORFs<-results_ORFs$tx_annotated_ORFs[names(results_ORFs$ORFs_tx_position)]
    #adjust feats!
    new_feats<-feats
    if(is(new_feats,"GRangesList")){
        new_feats<-as.list(new_feats)
    }
    results_ORFs$selected_ORFs_features<-gene_feat
    return(results_ORFs)
    
}

#' Annotate splice features of detected ORFs
#'
#' This function detects usage of different exons and exonic boundaries of one ORF with respect to a reference ORF.
#' @details each exon is aligned to the closest one to match acceptor and donor sites, or to annotate missing exons.
#' \code{5ss} and \code{3ss} indicate exon 5' and 3', respectively. \code{CDS_spanning} indicates retained intron;
#' \code{missing_CDS} indicates no overlapping exon (missed or included); \code{monoCDS} indicates a single-exon ORF; 
#' \code{firstCDS} and \code{lastCDS} indicate first CDS exon or last CDS exon.
#' @keywords SaTAnn
#' @author Lorenzo Calviello, \email{calviello.l.bio@@gmail.com}
#' @param orf_gen Exon structure of a detected ORF
#' @param ref_cds Exon structure of a reference ORF
#' @return Exon structure of detected ORF including possible missing exons from reference, together with a \code{spl_type} column
#' including the annotation for each exon (e.g. alternative acceptors or donor).
#' @seealso \code{\link{detect_translated_orfs}}, \code{\link{annotate_ORFs}}
#' @export

annotate_splicing<-function(orf_gen,ref_cds){
    
    overref<-orf_gen%over%ref_cds
    refover<-ref_cds%over%orf_gen
    spl_ran<-GRanges()
    
    if(sum(!refover)>0){
        spl_ran<-c(spl_ran,ref_cds[!refover])
        grliss<-GRangesList()
        refgrl<-ref_cds[!refover]
        for(gri in 1:length(refgrl)){
            grliss[[gri]]<-refgrl[gri]
        }
        spl_ran$ref<-grliss
        spl_ran$spl_type<-"missing_CDS"
        spl_ran$cds_id<-NULL
        spl_ran$cds_name<-NULL
        spl_ran$exon_rank<-NULL
        
    }
    
    orf_gen<-sort(orf_gen)
    if(length(orf_gen)>0){
        for(f in 1:length(orf_gen)){
            ran<-orf_gen[f]
            last_ex<-length(orf_gen)
            if(overref[f]==T){
                ref_over<-ref_cds[ref_cds%over%ran]
                #annotate for 5' and 3'; porcoddio
                
                if(length(ref_over)>1){
                    ran$ref<-GRangesList(ref_over)
                    ran$spl_type<-"CDS_spanning"
                    if(as.vector(strand(orf_gen[1]))=="+"){
                        if(start(ran)==min(start(ref_over))){
                            if(end(ran)==max(end(ref_over))){
                                ran$spl_type<-"CDS_spanning;same_5ss;same_3ss"
                                if(f==last_ex){ran$spl_type<-"CDS_spanning;same_5ss;same_lastCDS"}
                                if(f==1){ran$spl_type<-"CDS_spanning;same_firstCDS;same_3ss"}
                                if(1==last_ex){ran$spl_type<-"CDS_spanning;same_5monoCDS;same_3monoCDS"}
                            }
                            if(end(ran)>max(end(ref_over))){
                                ran$spl_type<-"CDS_spanning;same_5ss;down_3ss"
                                if(f==last_ex){ran$spl_type<-"CDS_spanning;same_5ss;down_lastCDS"}
                                if(f==1){ran$spl_type<-"CDS_spanning;same_firstCDS;down_3ss"}
                                if(1==last_ex){ran$spl_type<-"CDS_spanning;same_5monoCDS;down_3monoCDS"}
                            }
                            if(end(ran)<max(end(ref_over))){
                                ran$spl_type<-"CDS_spanning;same_5ss;up_3ss"
                                if(f==last_ex){ran$spl_type<-"CDS_spanning;same_5ss;up_lastCDS"}
                                if(f==1){ran$spl_type<-"CDS_spanning;same_firstCDS;up_3ss"}
                                if(1==last_ex){ran$spl_type<-"CDS_spanning;same_5monoCDS;up_3monoCDS"}
                            }
                            
                        }
                        if(end(ran)==max(end(ref_over))){
                            if(start(ran)>min(start(ref_over))){
                                ran$spl_type<-"CDS_spanning;down_5ss;same_3ss"
                                if(f==last_ex){ran$spl_type<-"CDS_spanning;down_5ss;same_lastCDS"}
                                if(f==1){ran$spl_type<-"CDS_spanning;down_firstCDS;same_3ss"}
                                if(1==last_ex){ran$spl_type<-"CDS_spanning;down_5monoCDS;same_3monoCDS"}
                            }
                            if(start(ran)<min(start(ref_over))){
                                ran$spl_type<-"CDS_spanning;up_5ss;same_3ss"
                                if(f==last_ex){ran$spl_type<-"CDS_spanning;up_5ss;same_lastCDS"}
                                if(f==1){ran$spl_type<-"CDS_spanning;up_firstCDS;same_3ss"}
                                if(1==last_ex){ran$spl_type<-"CDS_spanning;up_5monoCDS;same_3monoCDS"}
                            }
                            
                        }
                        
                        if(end(ran)>max(end(ref_over))){
                            if(start(ran)>min(start(ref_over))){
                                ran$spl_type<-"CDS_spanning;down_5ss;down_3ss"
                                if(f==last_ex){ran$spl_type<-"CDS_spanning;down_5ss;down_lastCDS"}
                                if(f==1){ran$spl_type<-"CDS_spanning;down_firstCDS;down_3ss"}
                                if(1==last_ex){ran$spl_type<-"CDS_spanning;down_5monoCDS;down_3monoCDS"}
                            }
                            if(start(ran)<min(start(ref_over))){
                                ran$spl_type<-"CDS_spanning;up_5ss;down_3ss"
                                if(f==last_ex){ran$spl_type<-"CDS_spanning;up_5ss;down_lastCDS"}
                                if(f==1){ran$spl_type<-"CDS_spanning;up_firstCDS;down_3ss"}
                                if(1==last_ex){ran$spl_type<-"CDS_spanning;up_5monoCDS;down_3monoCDS"}
                            }
                            
                        }
                        
                        if(end(ran)<max(end(ref_over))){
                            if(start(ran)>min(start(ref_over))){
                                ran$spl_type<-"CDS_spanning;down_5ss;up_3ss"
                                if(f==last_ex){ran$spl_type<-"CDS_spanning;down_5ss;up_lastCDS"}
                                if(f==1){ran$spl_type<-"CDS_spanning;down_firstCDS;up_3ss"}
                                if(1==last_ex){ran$spl_type<-"CDS_spanning;down_5monoCDS;up_3monoCDS"}
                            }
                            if(start(ran)<min(start(ref_over))){
                                ran$spl_type<-"CDS_spanning;up_5ss;up_3ss"
                                if(f==last_ex){ran$spl_type<-"CDS_spanning;up_5ss;up_lastCDS"}
                                if(f==1){ran$spl_type<-"CDS_spanning;up_firstCDS;up_3ss"}
                                if(1==last_ex){ran$spl_type<-"CDS_spanning;up_5monoCDS;up_3monoCDS"}
                            }
                            
                        }
                        
                        
                        
                        
                    }
                    
                    #if - and spanning
                    
                    if(as.vector(strand(orf_gen[1]))=="-"){
                        if(start(ran)==min(start(ref_over))){
                            if(end(ran)==max(end(ref_over))){
                                ran$spl_type<-"CDS_spanning;same_5ss;same_3ss"
                                if(f==1){ran$spl_type<-"CDS_spanning;same_5ss;same_lastCDS"}
                                if(f==last_ex){ran$spl_type<-"CDS_spanning;same_firstCDS;same_3ss"}
                                if(1==last_ex){ran$spl_type<-"CDS_spanning;same_5monoCDS;same_3monoCDS"}
                            }
                            if(end(ran)>max(end(ref_over))){
                                ran$spl_type<-"CDS_spanning;up_5ss;same_3ss"
                                if(f==1){ran$spl_type<-"CDS_spanning;up_5ss;same_lastCDS"}
                                if(f==last_ex){ran$spl_type<-"CDS_spanning;up_firstCDS;same_3ss"}
                                if(1==last_ex){ran$spl_type<-"CDS_spanning;up_5monoCDS;same_3monoCDS"}
                            }
                            if(end(ran)<max(end(ref_over))){
                                ran$spl_type<-"CDS_spanning;down_5ss;same_3ss"
                                if(f==1){ran$spl_type<-"CDS_spanning;down_5ss;same_lastCDS"}
                                if(f==last_ex){ran$spl_type<-"CDS_spanning;down_firstCDS;same_3ss"}
                                if(1==last_ex){ran$spl_type<-"CDS_spanning;down_5monoCDS;same_3monoCDS"}
                            }
                            
                        }
                        if(end(ran)==max(end(ref_over))){
                            if(start(ran)>min(start(ref_over))){
                                ran$spl_type<-"CDS_spanning;same_5ss;up_3ss"
                                if(f==1){ran$spl_type<-"CDS_spanning;same_5ss;up_lastCDS"}
                                if(f==last_ex){ran$spl_type<-"CDS_spanning;same_firstCDS;up_3ss"}
                                if(1==last_ex){ran$spl_type<-"CDS_spanning;same_5monoCDS;up_3monoCDS"}
                            }
                            if(start(ran)<min(start(ref_over))){
                                ran$spl_type<-"CDS_spanning;same_5ss;down_3ss"
                                if(f==1){ran$spl_type<-"CDS_spanning;same_5ss;down_lastCDS"}
                                if(f==last_ex){ran$spl_type<-"CDS_spanning;same_firstCDS;down_3ss"}
                                if(1==last_ex){ran$spl_type<-"CDS_spanning;same_5monoCDS;down_3monoCDS"}
                            }
                            
                        }
                        
                        if(end(ran)>max(end(ref_over))){
                            if(start(ran)>min(start(ref_over))){
                                ran$spl_type<-"CDS_spanning;up_5ss;up_3ss"
                                if(f==1){ran$spl_type<-"CDS_spanning;up_5ss;up_lastCDS"}
                                if(f==last_ex){ran$spl_type<-"CDS_spanning;up_firstCDS;up_3ss"}
                                if(1==last_ex){ran$spl_type<-"CDS_spanning;up_5monoCDS;up_3monoCDS"}
                            }
                            if(start(ran)<min(start(ref_over))){
                                ran$spl_type<-"CDS_spanning;up_5ss;down_3ss"
                                if(f==1){ran$spl_type<-"CDS_spanning;up_5ss;down_lastCDS"}
                                if(f==last_ex){ran$spl_type<-"CDS_spanning;up_firstCDS;down_3ss"}
                                if(1==last_ex){ran$spl_type<-"CDS_spanning;up_5monoCDS;down_3monoCDS"}
                            }
                            
                        }
                        
                        if(end(ran)<max(end(ref_over))){
                            if(start(ran)>min(start(ref_over))){
                                ran$spl_type<-"CDS_spanning;down_5ss;up_3ss"
                                if(f==1){ran$spl_type<-"CDS_spanning;down_5ss;up_lastCDS"}
                                if(f==last_ex){ran$spl_type<-"CDS_spanning;down_firstCDS;up_3ss"}
                                if(1==last_ex){ran$spl_type<-"CDS_spanning;down_5monoCDS;up_3monoCDS"}
                            }
                            if(start(ran)<min(start(ref_over))){
                                ran$spl_type<-"CDS_spanning;down_5ss;down_3ss"
                                if(f==1){ran$spl_type<-"CDS_spanning;down_5ss;down_lastCDS"}
                                if(f==last_ex){ran$spl_type<-"CDS_spanning;down_firstCDS;down_3ss"}
                                if(1==last_ex){ran$spl_type<-"CDS_spanning;down_5monoCDS;down_3monoCDS"}
                            }
                            
                        }
                    }
                    
                    
                }
                if(length(ref_over)==1){
                    ran$ref<-GRangesList(ref_over)
                    ran$spl_type<-NA
                    if(as.vector(strand(orf_gen[1]))=="+"){
                        if(start(ran)==(start(ref_over))){
                            if(end(ran)==(end(ref_over))){
                                ran$spl_type<-"same_5ss;same_3ss"
                                if(f==last_ex){ran$spl_type<-"same_5ss;same_lastCDS"}
                                if(f==1){ran$spl_type<-"same_firstCDS;same_3ss"}
                                if(1==last_ex){ran$spl_type<-"same_5monoCDS;same_3monoCDS"}
                            }
                            if(end(ran)>(end(ref_over))){
                                ran$spl_type<-"same_5ss;down_3ss"
                                if(f==last_ex){ran$spl_type<-"same_5ss;down_lastCDS"}
                                if(f==1){ran$spl_type<-"same_firstCDS;down_3ss"}
                                if(1==last_ex){ran$spl_type<-"same_5monoCDS;down_3monoCDS"}
                            }
                            if(end(ran)<(end(ref_over))){
                                ran$spl_type<-"same_5ss;up_3ss"
                                if(f==last_ex){ran$spl_type<-"same_5ss;up_lastCDS"}
                                if(f==1){ran$spl_type<-"same_firstCDS;up_3ss"}
                                if(1==last_ex){ran$spl_type<-"same_5monoCDS;up_3monoCDS"}
                            }
                            
                        }
                        if(end(ran)==(end(ref_over))){
                            if(start(ran)>(start(ref_over))){
                                ran$spl_type<-"down_5ss;same_3ss"
                                if(f==last_ex){ran$spl_type<-"down_5ss;same_lastCDS"}
                                if(f==1){ran$spl_type<-"down_firstCDS;same_3ss"}
                                if(1==last_ex){ran$spl_type<-"down_5monoCDS;same_3monoCDS"}
                            }
                            if(start(ran)<(start(ref_over))){
                                ran$spl_type<-"up_5ss;same_3ss"
                                if(f==last_ex){ran$spl_type<-"up_5ss;same_lastCDS"}
                                if(f==1){ran$spl_type<-"up_firstCDS;same_3ss"}
                                if(1==last_ex){ran$spl_type<-"up_5monoCDS;same_3monoCDS"}
                            }
                            
                        }
                        
                        if(end(ran)>(end(ref_over))){
                            if(start(ran)>(start(ref_over))){
                                ran$spl_type<-"down_5ss;down_3ss"
                                if(f==last_ex){ran$spl_type<-"down_5ss;down_lastCDS"}
                                if(f==1){ran$spl_type<-"down_firstCDS;down_3ss"}
                                if(1==last_ex){ran$spl_type<-"down_5monoCDS;down_3monoCDS"}
                            }
                            if(start(ran)<(start(ref_over))){
                                ran$spl_type<-"up_5ss;down_3ss"
                                if(f==last_ex){ran$spl_type<-"up_5ss;down_lastCDS"}
                                if(f==1){ran$spl_type<-"up_firstCDS;down_3ss"}
                                if(1==last_ex){ran$spl_type<-"up_5monoCDS;down_3monoCDS"}
                            }
                            
                        }
                        
                        if(end(ran)<(end(ref_over))){
                            if(start(ran)>(start(ref_over))){
                                ran$spl_type<-"down_5ss;up_3ss"
                                if(f==last_ex){ran$spl_type<-"down_5ss;up_lastCDS"}
                                if(f==1){ran$spl_type<-"down_firstCDS;up_3ss"}
                                if(1==last_ex){ran$spl_type<-"down_5monoCDS;up_3monoCDS"}
                            }
                            if(start(ran)<(start(ref_over))){
                                ran$spl_type<-"up_5ss;up_3ss"
                                if(f==last_ex){ran$spl_type<-"up_5ss;up_lastCDS"}
                                if(f==1){ran$spl_type<-"up_firstCDS;up_3ss"}
                                if(1==last_ex){ran$spl_type<-"up_5monoCDS;up_3monoCDS"}
                            }
                            
                        }
                        
                        
                        
                        
                    }
                    
                    if(as.vector(strand(orf_gen[1]))=="-"){
                        if(start(ran)==(start(ref_over))){
                            if(end(ran)==(end(ref_over))){
                                ran$spl_type<-"same_5ss;same_3ss"
                                if(f==1){ran$spl_type<-"same_5ss;same_lastCDS"}
                                if(f==last_ex){ran$spl_type<-"same_firstCDS;same_3ss"}
                                if(1==last_ex){ran$spl_type<-"same_5monoCDS;same_3monoCDS"}
                            }
                            if(end(ran)>(end(ref_over))){
                                ran$spl_type<-"up_5ss;same_3ss"
                                if(f==1){ran$spl_type<-"up_5ss;same_lastCDS"}
                                if(f==last_ex){ran$spl_type<-"up_firstCDS;same_3ss"}
                                if(1==last_ex){ran$spl_type<-"up_5monoCDS;same_3monoCDS"}
                            }
                            if(end(ran)<(end(ref_over))){
                                ran$spl_type<-"down_5ss;same_3ss"
                                if(f==1){ran$spl_type<-"down_5ss;same_lastCDS"}
                                if(f==last_ex){ran$spl_type<-"down_firstCDS;same_3ss"}
                                if(1==last_ex){ran$spl_type<-"down_5monoCDS;same_3monoCDS"}
                            }
                            
                        }
                        if(end(ran)==(end(ref_over))){
                            if(start(ran)>(start(ref_over))){
                                ran$spl_type<-"same_5ss;up_3ss"
                                if(f==1){ran$spl_type<-"same_5ss;up_lastCDS"}
                                if(f==last_ex){ran$spl_type<-"same_firstCDS;up_3ss"}
                                if(1==last_ex){ran$spl_type<-"same_5monoCDS;up_3monoCDS"}
                            }
                            if(start(ran)<(start(ref_over))){
                                ran$spl_type<-"same_5ss;down_3ss"
                                if(f==1){ran$spl_type<-"same_5ss;down_lastCDS"}
                                if(f==last_ex){ran$spl_type<-"same_firstCDS;down_3ss"}
                                if(1==last_ex){ran$spl_type<-"same_5monoCDS;down_3monoCDS"}
                            }
                            
                        }
                        
                        if(end(ran)>(end(ref_over))){
                            if(start(ran)>(start(ref_over))){
                                ran$spl_type<-"up_5ss;up_3ss"
                                if(f==1){ran$spl_type<-"up_5ss;up_lastCDS"}
                                if(f==last_ex){ran$spl_type<-"up_firstCDS;up_3ss"}
                                if(1==last_ex){ran$spl_type<-"up_5monoCDS;up_3monoCDS"}
                            }
                            if(start(ran)<(start(ref_over))){
                                ran$spl_type<-"up_5ss;down_3ss"
                                if(f==1){ran$spl_type<-"up_5ss;down_lastCDS"}
                                if(f==last_ex){ran$spl_type<-"up_firstCDS;down_3ss"}
                                if(1==last_ex){ran$spl_type<-"up_5monoCDS;down_3monoCDS"}
                            }
                            
                        }
                        
                        if(end(ran)<(end(ref_over))){
                            if(start(ran)>(start(ref_over))){
                                ran$spl_type<-"down_5ss;up_3ss"
                                if(f==1){ran$spl_type<-"down_5ss;up_lastCDS"}
                                if(f==last_ex){ran$spl_type<-"down_firstCDS;up_3ss"}
                                if(1==last_ex){ran$spl_type<-"down_5monoCDS;up_3monoCDS"}
                            }
                            if(start(ran)<(start(ref_over))){
                                ran$spl_type<-"down_5ss;down_3ss"
                                if(f==1){ran$spl_type<-"down_5ss;down_lastCDS"}
                                if(f==last_ex){ran$spl_type<-"down_firstCDS;down_3ss"}
                                if(1==last_ex){ran$spl_type<-"down_5monoCDS;down_3monoCDS"}
                            }
                            
                        }
                    }
                    
                    
                    
                    
                }
                
            }
            if(overref[f]==F){
                if(length(ref_cds)>0){ran$ref<-GRangesList(ref_cds[nearest(x=ran,subject=ref_cds)])}
                if(length(ref_cds)==0){ran$ref<-GRangesList(GRanges())}
                ran$spl_type<-"new_CDS"
                if(f==last_ex){
                    if(as.vector(strand(orf_gen[1]))=="+"){
                        ran$spl_type<-"new_lastCDS"
                    }
                    if(as.vector(strand(orf_gen[1]))=="-"){
                        ran$spl_type<-"new_firstCDS"
                    }
                }
                if(f==1){
                    
                    if(as.vector(strand(orf_gen[1]))=="-"){
                        ran$spl_type<-"new_lastCDS"
                    }
                    if(as.vector(strand(orf_gen[1]))=="+"){
                        ran$spl_type<-"new_firstCDS"
                    }                                       
                }
                if(1==last_ex){
                    ran$spl_type<-"new_monoCDS"
                    
                }
            }
            spl_ran<-sort(c(spl_ran,ran))
            
            
        }
        
    }
    
    newspl<-spl_ran$spl_type
    newspl[grep(spl_ran$spl_type,pattern = "new")]<-"new_miss"
    newspl[grep(spl_ran$spl_type,pattern = "missing")]<-"new_miss"
    rlesp<-Rle(newspl)
    
    #change new and missing
    if(runValue(rlesp)[1]=="new_miss"){
        if(as.character(strand(spl_ran)[1])=="+"){spl_ran$spl_type[1:runLength(rlesp)[1]]<-paste(spl_ran$spl_type[1:runLength(rlesp)[1]],"_5prime",sep = "")}
        if(as.character(strand(spl_ran)[1])=="-"){spl_ran$spl_type[1:runLength(rlesp)[1]]<-paste(spl_ran$spl_type[1:runLength(rlesp)[1]],"_3prime",sep = "")}
    }
    lenna<-length(runValue(rlesp))
    if(runValue(rlesp)[lenna]=="new_miss"){
        if(as.character(strand(spl_ran)[1])=="+"){spl_ran$spl_type[(length(spl_ran)-(runLength(rlesp)[lenna]-1)):length(spl_ran)]<-paste(spl_ran$spl_type[(length(spl_ran)-(runLength(rlesp)[lenna]-1)):length(spl_ran)],"_3prime",sep = "")}
        if(as.character(strand(spl_ran)[1])=="-"){paste(spl_ran$spl_type[(length(spl_ran)-(runLength(rlesp)[lenna]-1)):length(spl_ran)],"_5prime",sep = "")}
    }
    spl_ran$spl_type<-gsub(spl_ran$spl_type,pattern = "_5prime_3prime",replacement = "_notoverl")
    spl_ran
}

#' Annotate detected ORFs in transcript and genome space
#'
#' This function annotates quantified ORFs with respect to other detected ORFs and annotated ones, in both genome and transcript space.
#' @details As multiple transcripts can contain the same ORF,
#' all the transcript and transcript biotypes are indicated, with a preference for protein_coding transcripts in the "compatible" 
#' columns (to be conservative when assessing translation of non-protein coding transcripts). Such compatibility is also output considering the most upstream
#' start codon for that ORF. \cr
#' Splice features of each orf is annotated with respect to the longest coding transcripts and to the highest translated ORF in that gene.\cr
#' Variants in N or C terminus of the translated proteins are also indicated (Beta).\cr
#' ORF annotation with respect to the annotated transcript is also indicated, as follows:\cr\cr
#' \code{novel}: no ORF annotated in the transcript.\cr
#' \code{ORF_annotated}: same exact ORF as annotated.\cr
#' \code{N_extension}: N terminal extension.\cr
#' \code{N_truncation}: N terminal extension.\cr
#' \code{uORF}: upstream ORF.\cr
#' \code{overl_uORF}: upstream overlappin uORF.\cr
#' \code{NC_extension}: N and C termini extension.\cr
#' \code{dORF}: downstream ORF.\cr
#' \code{overl_dORF}: downstream overlapping ORF.\cr
#' \code{nested_ORF}: nested ORF.\cr
#' \code{C_truncation}: C terminal truncation.\cr
#' \code{C_extension}: C terminal extension.\cr\cr
#' As transcipt-specific annotation can be misleading due to a plethora of different transcripts, it is important to distinguish ORFs
#' also on the basis of their overlap with know CDS regions.
#' ORF annotation with respect to the entire set of CDS exon for the analyzed genomic regions is  indicated as follows:\cr\cr
#' \code{novel}: No CDS region is annotated in the entire region.\cr
#' \code{novel_Upstream}: ORF is upstream of annotated CDS regions (does not overlap).\cr
#' \code{novel_Downstream}: ORF is downstream of annotated CDS regions (does not overlap).\cr
#' \code{novel_Internal}: genomic location of the ORF is present between the start of the first,
#'  and the end of the last CDS region (does not overlap).\cr
#' \code{exact_start_stop}: Same start and end locations.\cr
#' \code{Alt5_start}: Different start region, upstream.\cr
#' \code{Alt3_start}: Different start region, downstream.\cr
#' \code{Alt5_stop}: Different end region, upstream.\cr
#' \code{Alt3_stop}: Different end region, downstream.\cr\cr
#' Another layer of annotation is performed by checking the position of the ORF stop codon 
#' with respect to the last exon-exon junction.
#' @keywords SaTAnn
#' @author Lorenzo Calviello, \email{calviello.l.bio@@gmail.com}
#' @param results_ORFs Full list of detected ORFs, from \code{select_quantify_ORFs}
#' @param Annotation Rannot object containing annotation of CDS and transcript structures (see \code{prepare_annotation_files}
#' @param genome_sequence BSgenome object
#' @param region genomic region being analyzed
#' @param genetic_code GENETIC_CODE table to use
#' @return Exon structure of detected ORF including possible missing exons from reference, together with a \code{spl_type} column
#' including the annotation for each exon (e.g. alternative acceptors or donor).\cr\cr
#' Additional columns are added to the ORFs_tx object:\cr
#' \code{compatible_with}: Set of transcript ids possibly containing the entire ORF structure.\cr
#' \code{compatible_biotype}: Compatible transcript biotype; if a protein coding transcript can contain 
#' the ORF, this is set to protein_coding.\cr
#' \code{compatible_tx}: One selected compatible transcript (preference if protein_coding).\cr
#' \code{compatible_ORF_id_tr}: ORF_id_tr id if selecting the compatible transcript.\cr
#' \code{compatible_with_longest}: Same as \code{compatible_with} but using the most upstream start codon.\cr
#' \code{compatible_ORF_id_tr_longest}: Same as \code{compatible_ORF_id_tr} but using the most upstream start codon .\cr
#' \code{ref_id}: transcript_id of the transcript used to annotate splicing (longest) .\cr
#' \code{ref_id_maxORF}: ORF_id_tr of the ORF used to annotated splicing (most translated of the gene).\cr
#' \code{NC_protein_isoform}: Annotation of possible N or C termini variant (when transcript is protein_coding) .\cr
#' \code{ORF_category_Tx}: ORF annotation with respect to ORF position in the transcript .\cr
#' \code{ORF_category_Tx_compatible}: ORF annotation with respect to ORF position in the transcript, using the \code{compatible_ORF_id_tr} .\cr
#' \code{ORF_category_Gen}: ORF annotation with respect to its genomic position .\cr
#' \code{NMD_candidate}: TRUE or FALSE, depending on the presence of an additional exon-exon junction downstream the stop codon.\cr
#' \code{Distance_to_lastExEx}: Distance (in nt) between the last exon-exon junction and the stop codon.
#' @seealso \code{\link{select_quantify_ORFs}}, \code{\link{annotate_splicing}}
#' @export

annotate_ORFs<-function(results_ORFs,Annotation,genome_sequence,region,genetic_code){
    
    annotated_cds<-Annotation$cds_genes[Annotation$cds_genes%over%region]
    annotated_cds_tx<-Annotation$cds_txs[Annotation$cds_txs%over%region]
    annotated_cds_tx_genes<-Annotation$trann$gene_id[match(names(annotated_cds_tx),Annotation$trann$transcript_id)]
    annotated_exons_tx<-Annotation$exons_txs[Annotation$exons_txs%over%region]
    
    
    
    ORFs_tx<-results_ORFs$ORFs_tx_position
    ORFs_gen<-results_ORFs$ORFs_genomic_position
    ORFs_splice_feats<-GRangesList()
    ORFs_splice_feats_tomaxORF<-GRangesList()
    orfssss_tx<-unlist(GRangesList(ORFs_tx))
    orfssss_tx<-orfssss_tx[!is.na(orfssss_tx$ORF_pct_P_sites)]
    maxORF_orf<-c()
    max_cds<-c()
    max_cdsok<-GRanges()
    
    for(i in unique(orfssss_tx$gene_id)){
        okorfsss<-orfssss_tx[orfssss_tx$gene_id==i]
        maxORF_orf[i]<-okorfsss$ORF_id_tr[which.max(okorfsss$ORF_pct_P_sites)]
        anncdss<-annotated_cds_tx[annotated_cds_tx_genes==i]
        if(length(anncdss)>0){
            max_cds[i]<-names(which.max(sum(width(anncdss))))
        }
        
        if(length(anncdss)==0){
            orf_gen<-reduce(unlist(ORFs_gen[okorfsss$ORF_id_tr]))
            
            moret<-sapply(annotated_cds_tx,FUN=function(x){
                sum(width(setdiff(orf_gen,x)))
            })
            moret<-t(data.frame(moret,stringsAsFactors=F))
            max_cds[i]<-colnames(moret)[which.min(colSums(moret))]
        }
        
        
    }
    
    #compatibilities
    
    for(i in names(ORFs_gen)){
        x<-ORFs_gen[[i]]
        mapp<-mapToTranscripts(x,transcripts = annotated_exons_tx)
        redmapp<-reduce(split(mapp,seqnames(mapp)))
        
        redmapp<-redmapp[which(sum(width(redmapp))==sum(width(x)))]
        redmapp<-redmapp[elementNROWS(redmapp)==1]
        
        comp<-sapply(redmapp,function(x){paste(seqnames(x),start(x),end(x),sep="_")})
        names(comp)<-NULL
        ORFs_tx[[i]]$compatible_with<-NULL
        ORFs_tx[[i]]$compatible_with<-CharacterList(unlist(comp))
        
        
        ORFs_tx[[i]]$compatible_biotype<-ORFs_tx[[i]]$transcript_biotype
        ORFs_tx[[i]]$compatible_tx<-ORFs_tx[[i]]$transcript_id
        ORFs_tx[[i]]$compatible_ORF_id_tr<-ORFs_tx[[i]]$ORF_id_tr
        compats<-elementNROWS(ORFs_tx[[i]]$compatible_with)>1
        comp_txs<-ORFs_tx[[i]]$compatible_with[compats]
        if(length(comp_txs)>0){
            compid<-sapply(comp_txs,function(x){
                txs<-sapply(strsplit(x,split = "_"),"[[",1)
                btps<-Annotation$trann$transcript_biotype[match(txs,Annotation$trann$transcript_id)]
                pcd<-btps=="protein_coding"
                if(sum(pcd)>0){c(sort(x[pcd])[1],sort(txs[pcd])[1],"protein_coding")}else{c(x[1],txs[1],btps[1])}
            })
            ORFs_tx[[i]]$compatible_ORF_id_tr[compats]<-t(compid)[,1]
            ORFs_tx[[i]]$compatible_tx[compats]<-t(compid)[,2]
            ORFs_tx[[i]]$compatible_biotype[compats]<-t(compid)[,3]
            
        }
        ORFs_tx[[i]]$compatible_with_longest<-ORFs_tx[[i]]$compatible_with
        ORFs_tx[[i]]$compatible_biotype_longest<-ORFs_tx[[i]]$compatible_biotype
        ORFs_tx[[i]]$compatible_tx_longest<-ORFs_tx[[i]]$compatible_tx
        ORFs_tx[[i]]$compatible_ORF_id_tr_longest<-ORFs_tx[[i]]$compatible_ORF_id_tr
        lng<-ORFs_tx[[i]]$longest_ORF
        lng$ORF_id_tr<-paste(seqnames(lng),start(lng),end(lng),sep="_")
        if(start(ORFs_tx[[i]])!=start(lng)){
            x<-from_tx_togen(ORFs = lng,exons = Annotation$exons_txs[ORFs_tx[[i]]$transcript_id],introns = Annotation$introns_txs[[ORFs_tx[[i]]$transcript_id]])[[1]]
            mapp<-mapToTranscripts(x,transcripts = annotated_exons_tx)
            redmapp<-reduce(split(mapp,seqnames(mapp)))
            
            redmapp<-redmapp[which(sum(width(redmapp))==sum(width(x)))]
            redmapp<-redmapp[elementNROWS(redmapp)==1]
            
            comp<-sapply(redmapp,function(x){paste(seqnames(x),start(x),end(x),sep="_")})
            names(comp)<-NULL
            ORFs_tx[[i]]$compatible_with_longest<-CharacterList(unlist(comp))
            ORFs_tx[[i]]$compatible_biotype_longest<-ORFs_tx[[i]]$transcript_biotype
            ORFs_tx[[i]]$compatible_tx_longest<-ORFs_tx[[i]]$transcript_id
            ORFs_tx[[i]]$compatible_ORF_id_tr_longest<-paste(as.character(seqnames(lng)[1]),start(lng),end(lng),sep = "_")
            
            compats<-elementNROWS(ORFs_tx[[i]]$compatible_with)>1
            comp_txs<-ORFs_tx[[i]]$compatible_with_longest[compats]
            if(length(comp_txs)>0){
                compid<-sapply(comp_txs,function(x){
                    txs<-sapply(strsplit(x,split = "_"),function(x){paste(x[-((length(x)-1):length(x))],collapse="_")})
                    btps<-Annotation$trann$transcript_biotype[match(txs,Annotation$trann$transcript_id)]
                    pcd<-btps=="protein_coding"
                    if(sum(pcd)>0){c(sort(x[pcd])[1],sort(txs[pcd])[1],"protein_coding")}else{c(x[1],txs[1],btps[1])}
                })
                ORFs_tx[[i]]$compatible_ORF_id_tr_longest[compats]<-t(compid)[,1]
                ORFs_tx[[i]]$compatible_tx_longest[compats]<-t(compid)[,2]
                ORFs_tx[[i]]$compatible_biotype_longest[compats]<-t(compid)[,3]
                
            }        
            
        }
        
    }
    
    for(i in names(ORFs_gen)){
        
        compss<-ORFs_tx[[i]]$compatible_with[[1]]
        ok_id<-compss[grep(compss,pattern = ORFs_tx[[i]]$compatible_tx_longest)]
        comp_ln<-ORFs_tx[[i]]$compatible_biotype_longest
        comp_prev<-ORFs_tx[[i]]$compatible_biotype
        if(comp_ln=="protein_coding" | (comp_prev!="protein_coding" & comp_ln!="protein_coding") ){
            ORFs_tx[[i]]$compatible_ORF_id_tr<-ok_id
            ORFs_tx[[i]]$compatible_tx<-ORFs_tx[[i]]$compatible_tx_longest
            ORFs_tx[[i]]$compatible_biotype<-ORFs_tx[[i]]$compatible_biotype_longest
        }
        ORFs_tx[[i]]$compatible_tx_longest<-NULL
        ORFs_tx[[i]]$compatible_biotype_longest<-NULL
        
    }
    
    #annotate NMD candidates
    exs<-annotated_exons_tx[unique(unlist(GRangesList(ORFs_tx))$transcript_id)]
    
    strands_exs<-sapply(strand(exs),function(x){x@values[1]})
    exs_pos<-exs[strands_exs=="+"]
    exs_neg<-exs[strands_exs=="-"]
    
    
    last_ex_pos<-which.max(start(exs_pos))
    last_ex_pos<-exs_pos[splitAsList(unname(last_ex_pos), names(last_ex_pos))]
    last_ex_pos<-last_ex_pos[match(names(exs_pos),names(last_ex_pos))]
    txs_pos<-pmapToTranscripts(last_ex_pos,transcripts = exs_pos)
    
    
    last_ex_neg<-which.min(start(exs_neg))
    last_ex_neg<-exs_neg[splitAsList(unname(last_ex_neg), names(last_ex_neg))]
    last_ex_neg<-last_ex_neg[match(names(exs_neg),names(last_ex_neg))]
    txs_neg<-pmapToTranscripts(last_ex_neg,transcripts = exs_neg)
    txs_all<-unlist(c(txs_pos,txs_neg))
    last_exexs<-start(txs_all)[match(unlist(GRangesList(ORFs_tx))$transcript_id,names(txs_all))]
    Distance_EJCs<-last_exexs-end(unlist(GRangesList(ORFs_tx)))
    
    
    ORFs_tx<-lapply(ORFs_tx,function(x){
        cols<-mcols(x)
        cols[,c("ref_id","ref_id_maxORF","NC_protein_isoform","ORF_category_Tx","ORF_category_Tx_compatible","ORF_category_Gen","NMD_candidate","Distance_to_lastExEx")]<-NA
        mcols(x)<-cols
        x
    })
    
    for(i in 1:length(ORFs_tx)){
        nmd<-FALSE
        if(Distance_EJCs[i]>0){
            nmd<-TRUE
        }
        ORFs_tx[[i]]$NMD_candidate<-nmd
        ORFs_tx[[i]]$Distance_to_lastExEx<-Distance_EJCs[i]
    }
    
    
    
    annotated_cds_tx2<-annotated_cds_tx
    
    #here bulk of work
    
    for(i in 1:length(ORFs_tx)){
        orf_tx<-ORFs_tx[[i]]
        ORFs_splice_feats[[orf_tx$ORF_id_tr]]<-GRanges()
        ORFs_splice_feats_tomaxORF[[orf_tx$ORF_id_tr]]<-GRanges()
        
        #annotate tx position
        
        annotated_ORF<-Annotation$cds_txs_coords[as.character(seqnames(Annotation$cds_txs_coords))==orf_tx$transcript_id]
        annotated_ORF_compatible<-Annotation$cds_txs_coords[as.character(seqnames(Annotation$cds_txs_coords))==orf_tx$compatible_tx]
        
        if(length(annotated_ORF)==0){
            ORFs_tx[[i]]$ORF_category_Tx<-"novel"
        }
        if(length(annotated_ORF_compatible)==0){
            ORFs_tx[[i]]$ORF_category_Tx_compatible<-"novel"
        }
        
        if(length(annotated_ORF)>0){
            
            ann_sta<-start(annotated_ORF)
            ann_sto<-end(annotated_ORF)-3
            sta<-start(orf_tx)
            sto<-end(orf_tx)
            if(sto==ann_sto){
                
                if(sta==ann_sta){ORFs_tx[[i]]$ORF_category_Tx<-"ORF_annotated"}
                if(sta<ann_sta){ORFs_tx[[i]]$ORF_category_Tx<-"N_extension"}
                if(sta>ann_sta){ORFs_tx[[i]]$ORF_category_Tx<-"N_truncation"}
                
            }
            if(sto!=ann_sto){
                
                if(sta<ann_sta & sto<ann_sto){ORFs_tx[[i]]$ORF_category_Tx<-"overl_uORF"}
                if(sta<ann_sta & sto<ann_sta){ORFs_tx[[i]]$ORF_category_Tx<-"uORF"}
                if(sta<ann_sta & sto>ann_sto){ORFs_tx[[i]]$ORF_category_Tx<-"NC_extension"}
                if(sta>ann_sta & sto>ann_sto){ORFs_tx[[i]]$ORF_category_Tx<-"overl_dORF"}
                if(sta>ann_sto & sto>ann_sto){ORFs_tx[[i]]$ORF_category_Tx<-"dORF"}
                if(sta>ann_sta & sto<ann_sto){ORFs_tx[[i]]$ORF_category_Tx<-"nested_ORF"}
                if(sta==ann_sta & sto<ann_sto){ORFs_tx[[i]]$ORF_category_Tx<-"C_truncation"}
                if(sta==ann_sta & sto>ann_sto){ORFs_tx[[i]]$ORF_category_Tx<-"C_extension"}
                
            }
        }
        
        
        if(length(annotated_ORF_compatible)>0){
            
            ann_sta<-start(annotated_ORF_compatible)
            ann_sto<-end(annotated_ORF_compatible)-3
            #change
            sta<-as.numeric(sapply(strsplit(orf_tx$compatible_ORF_id_tr,"_"),function(x){x[length(x)-1]}))
            sto<-as.numeric(sapply(strsplit(orf_tx$compatible_ORF_id_tr,"_"),function(x){x[length(x)]}))
            if(sto==ann_sto){
                
                if(sta==ann_sta){ORFs_tx[[i]]$ORF_category_Tx_compatible<-"ORF_annotated"}
                if(sta<ann_sta){ORFs_tx[[i]]$ORF_category_Tx_compatible<-"N_extension"}
                if(sta>ann_sta){ORFs_tx[[i]]$ORF_category_Tx_compatible<-"N_truncation"}
                
            }
            if(sto!=ann_sto){
                
                if(sta<ann_sta & sto<ann_sto){ORFs_tx[[i]]$ORF_category_Tx_compatible<-"overl_uORF"}
                if(sta<ann_sta & sto<ann_sta){ORFs_tx[[i]]$ORF_category_Tx_compatible<-"uORF"}
                if(sta<ann_sta & sto>ann_sto){ORFs_tx[[i]]$ORF_category_Tx_compatible<-"NC_extension"}
                if(sta>ann_sta & sto>ann_sto){ORFs_tx[[i]]$ORF_category_Tx_compatible<-"overl_dORF"}
                if(sta>ann_sto & sto>ann_sto){ORFs_tx[[i]]$ORF_category_Tx_compatible<-"dORF"}
                if(sta>ann_sta & sto<ann_sto){ORFs_tx[[i]]$ORF_category_Tx_compatible<-"nested_ORF"}
                if(sta==ann_sta & sto<ann_sto){ORFs_tx[[i]]$ORF_category_Tx_compatible<-"C_truncation"}
                if(sta==ann_sta & sto>ann_sto){ORFs_tx[[i]]$ORF_category_Tx_compatible<-"C_extension"}
                
            }
        }
        
        
        #annotate splice, genomic position and protein termini based on max cds and max pct
        
        orf_gen<-ORFs_gen[[orf_tx$ORF_id_tr]]
        
        #1 of multiple overlapping cds per gene
        
        if(length(annotated_cds)>1){
            moreg<-sapply(annotated_cds,FUN=function(x){
                orf_gen%over%x
            })
            if(length(orf_gen)==1){moreg<-t(data.frame(moreg,stringsAsFactors=F))}
            annotated_cds2<-reduce(unlist(annotated_cds[[colnames(moreg)[which.max(colSums(moreg))]]]))
            
            #if(length(annotated_cds_tx2)>1){annotated_cds_tx<-annotated_cds_tx2[annotated_cds_tx2%over%annotated_cds2]}
            
        }
        
        #otherwise list with 1 gene
        if(length(annotated_cds)==1){annotated_cds2<-reduce(unlist(annotated_cds))}
        if(length(annotated_cds)==0){annotated_cds2<-annotated_cds}
        overl<-orf_gen%over%annotated_cds2
        
        
        if(sum(overl)==0){
            ORFs_tx[[i]]$ORF_category_Gen<-"novel"
            if(length(annotated_cds2)>0){
                nearest_cds<-annotated_cds[[names(unlist(annotated_cds))[nearest(orf_gen,unlist(annotated_cds))[1]]]]
                overl_whole<-orf_gen@ranges%over%IRanges(start=min(start(nearest_cds)),end=max(end(nearest_cds)))
                
                if(as.vector(strand(orf_gen[1]))=="+"){
                    
                    if(sum(overl_whole)==0){
                        if(min(start(orf_gen))<min(start(nearest_cds))){
                            ORFs_tx[[i]]$ORF_category_Gen<-"novel_Upstream"
                        }
                        if(min(start(orf_gen))>max(end(nearest_cds))){
                            ORFs_tx[[i]]$ORF_category_Gen<-"novel_Downstream"
                        }
                    }
                    if(sum(overl_whole)>0){
                        ORFs_tx[[i]]$ORF_category_Gen<-"novel_Internal"
                    }
                    
                }
                if(as.vector(strand(orf_gen[1]))=="-"){
                    if(sum(overl_whole)==0){
                        if(max(end(orf_gen))>max(end(nearest_cds))){
                            ORFs_tx[[i]]$ORF_category_Gen<-"novel_Upstream"
                        }
                        if(min(start(orf_gen))<min(start(nearest_cds))){
                            ORFs_tx[[i]]$ORF_category_Gen<-"novel_Downstream"
                        }
                    }
                    if(sum(overl_whole)>0){
                        ORFs_tx[[i]]$ORF_category_Gen<-"novel_Internal"
                    }                                        
                }
            }
        }
        
        #if overlaps CDS
        spl_ran<-GRanges()
        if(sum(overl)>0){
            
            #annotated NC wrt maxcds
            
            ORFs_tx[[i]]$ORF_category_Gen<-"overlaps_CDS"
            max_cdsok<-annotated_cds_tx[[max_cds[ORFs_tx[[i]]$gene_id]]]
            if(length(max_cdsok)==0){
                max_cdsok<-annotated_cds_tx[[which.max(sum(width(annotated_cds_tx)))]]
            }
            ORFs_tx[[i]]$ref_id<-max_cds[ORFs_tx[[i]]$gene_id]
            max_cds_seq<-unlist(getSeq(x=genome_sequence,max_cdsok))
            segm<-10
            if(length(max_cds_seq)<33 | nchar(orf_tx$Protein)<10){
                segm<-min(c(as.integer(length(max_cds_seq)/3)-1,nchar(orf_tx$Protein)))
            }
            N_pr<-AAString(unlist(orf_tx$Protein))[1:segm]
            C_pr<-AAString(unlist(orf_tx$Protein))[(nchar(unlist(orf_tx$Protein))-(segm-1)):nchar(unlist(orf_tx$Protein))]
            N_ann<-translate(max_cds_seq[1:(segm*3)],genetic.code = genetic_code,if.fuzzy.codon="solve")
            C_ann<-translate(head(tail(max_cds_seq,(segm*3+3)),(segm*3)),genetic.code = genetic_code,if.fuzzy.codon="solve")
            
            
            ORFs_tx[[i]]$NC_protein_isoform<-"N_C"
            if(N_pr==N_ann){
                if(C_pr==C_ann){
                    ORFs_tx[[i]]$NC_protein_isoform<-"same"
                } else {ORFs_tx[[i]]$NC_protein_isoform<-"C"}
            }
            if(C_pr==C_ann & N_pr!=N_ann){
                ORFs_tx[[i]]$NC_protein_isoform<-"N"                                        
            }
            
            #ann genomic
            
            if(as.vector(strand(orf_gen[1]))=="+"){
                
                gen_sta<-min(start(max_cdsok))
                gen_sto<-max(end(max_cdsok))
                
                sta_or<-min(start(orf_gen))
                sto_or<-max(end(orf_gen))+3
                if(sto_or==gen_sto){
                    if(sta_or==gen_sta){ORFs_tx[[i]]$ORF_category_Gen<-"exact_start_stop"}
                    if(sta_or<gen_sta){ORFs_tx[[i]]$ORF_category_Gen<-"Alt5_start"}
                    if(sta_or>gen_sta){ORFs_tx[[i]]$ORF_category_Gen<-"Alt3_start"}
                    
                }
                
                if(sto_or!=gen_sto){
                    if(sta_or<gen_sta & sto_or<gen_sto){ORFs_tx[[i]]$ORF_category_Gen<-"Alt5_start_Alt5_stop"}
                    if(sta_or<gen_sta & sto_or>gen_sto){ORFs_tx[[i]]$ORF_category_Gen<-"Alt5_start_Alt3_stop"}
                    if(sta_or>gen_sta & sto_or>gen_sto){ORFs_tx[[i]]$ORF_category_Gen<-"Alt3_start_Alt3_stop"}
                    if(sta_or>gen_sta & sto_or<gen_sto){ORFs_tx[[i]]$ORF_category_Gen<-"Alt3_start_Alt5_stop"}
                    if(sta_or==gen_sta & sto_or<gen_sto){ORFs_tx[[i]]$ORF_category_Gen<-"Alt5_stop"}
                    if(sta_or==gen_sta & sto_or>gen_sto){ORFs_tx[[i]]$ORF_category_Gen<-"Alt3_stop"}
                    
                }
            }
            if(as.vector(strand(orf_gen[1]))=="-"){
                
                gen_sta<-max(end(max_cdsok))
                gen_sto<-min(start(max_cdsok))
                
                sta_or<-max(end(orf_gen))
                sto_or<-min(start(orf_gen))-3
                
                if(sto_or==gen_sto){
                    if(sta_or==gen_sta){ORFs_tx[[i]]$ORF_category_Gen<-"exact_start_stop"}
                    if(sta_or<gen_sta){ORFs_tx[[i]]$ORF_category_Gen<-"Alt3_start"}
                    if(sta_or>gen_sta){ORFs_tx[[i]]$ORF_category_Gen<-"Alt5_start"}
                    
                }
                
                if(sto_or!=gen_sto){
                    if(sta_or>gen_sta & sto_or>gen_sto){ORFs_tx[[i]]$ORF_category_Gen<-"Alt5_start_Alt5_stop"}
                    
                    if(sta_or>gen_sta & sto_or<gen_sto){ORFs_tx[[i]]$ORF_category_Gen<-"Alt5_start_Alt3_stop"}
                    if(sta_or<gen_sta & sto_or<gen_sto){ORFs_tx[[i]]$ORF_category_Gen<-"Alt3_start_Alt3_stop"}
                    if(sta_or<gen_sta & sto_or>gen_sto){ORFs_tx[[i]]$ORF_category_Gen<-"Alt3_start_Alt5_stop"}
                    if(sta_or==gen_sta & sto_or>gen_sto){ORFs_tx[[i]]$ORF_category_Gen<-"Alt5_stop"}
                    if(sta_or==gen_sta & sto_or<gen_sto){ORFs_tx[[i]]$ORF_category_Gen<-"Alt3_stop"}
                    
                }
                
                
                
            }
        }     
        
        ORFs_splice_feats[[orf_tx$ORF_id_tr]]<-annotate_splicing(orf_gen = orf_gen,ref_cds = max_cdsok)
        #to maxORF
        max_pct<-ORFs_gen[[maxORF_orf[ORFs_tx[[i]]$gene_id]]]
        ORFs_tx[[i]]$ref_id_maxORF<-maxORF_orf[ORFs_tx[[i]]$gene_id]
        ORFs_splice_feats_tomaxORF[[orf_tx$ORF_id_tr]]<-annotate_splicing(orf_gen = orf_gen,ref_cds = max_pct)
        
        
        
    }
    
    results_ORFs$ORFs_tx_position<-ORFs_tx
    list_spl_res<-list(ORFs_splice_feats,ORFs_splice_feats_tomaxORF)
    names(list_spl_res)<-c("annotation_wrt_longest","annotation_wrt_maxORF")
    results_ORFs$ORFs_splice_feats<-list_spl_res
    return(results_ORFs)
}


#' Detection, quantification and annotation of translated ORFs in a genomic region
#'
#' This function detects, quantifies and annotates actively translated ORF in a genomic region
#' @details A set of transcripts, together with genome sequence and Ribo-signal are analyzed to extract translated ORFs
#' @keywords SaTAnn
#' @author Lorenzo Calviello, \email{calviello.l.bio@@gmail.com}
#' @param region GRanges object with genomic coordinates of the genomic region analyzed
#' @param for_SaTAnn "for_SaTAnn" Robject containing P_sites positions and junction reads
#' @param genetic_code_region GENETIC_CODE table to use
#' @param orf_find.all_starts \code{get_all_starts} parameter for the \code{detect_translated_orfs} function
#' @param orf_find.nostarts \code{Stop_Stop} parameter for the \code{detect_translated_orfs} function
#' @param orf_find.start_sel_cutoff \code{cutoff} parameter for the \code{detect_translated_orfs} function
#' @param orf_find.start_sel_cutoff_ave \code{cutoff_ave} parameter for the \code{detect_translated_orfs} function
#' @param orf_find.cutoff_fr_ave \code{cutoff} parameter for the \code{detect_translated_orfs} function
#' @param orf_quant.cutoff_cums \code{cutoff_cums} parameter for the \code{select_quantify_ORFs} function
#' @param orf_quant.cutoff_pct \code{cutoff_pct} parameter for the \code{select_quantify_ORFs} function
#' @param orf_quant.cutoff_P_sites \code{cutoff_P_sites} parameter for the \code{select_quantify_ORFs} function
#' @return A list containing transcript coordinates, exonic coordinates and annotation for each ORF.\cr\cr
#' The description for each list object is as follows:\cr\cr
#' \code{ORFs_tx}: transcript coordinates of the detected ORFs.\cr
#' \code{ORFs_gen}: genomic (exon) coordinates of the detected ORFs.\cr
#' \code{ORFs_feat}: list of ORF features together with mapping reads and uniqueness.\cr
#' \code{ORFs_txs_feats}: list of transcript features present in the genomic region, together with mapping reads and uniqueness.\cr
#' \code{ORFs_spl_feat_longest}: splicing annotation for each ORF exon, with respect to the longest annotated coding transcript for each gene.\cr
#' \code{ORFs_spl_feat_maxORF}: splicing annotation for each ORF exon, with respect to the most translated ORF in each gene.\cr
#' \code{selected_txs}: character vector containing the transcript ids of the selected transcripts.\cr
#' \code{ORFs_readthroughs}: (Beta) transcript coordinates of the detected ORFs readthroughs.\cr
#' @seealso \code{\link{select_txs}}, \code{\link{detect_translated_orfs}}, \code{\link{select_quantify_ORFs}}, \code{\link{annotate_ORFs}}, \code{\link{detect_readthrough}}
#' @export

SaTAnn<-function(region,for_SaTAnn,genetic_code_region,
                 orf_find.all_starts=T,orf_find.nostarts=F,orf_find.start_sel_cutoff = NA,orf_find.start_sel_cutoff_ave = .5,
                 orf_find.cutoff_fr_ave=.5,orf_quant.cutoff_cums = NA,orf_quant.cutoff_pct = 2,orf_quant.cutoff_P_sites=NA){
    
    P_sites_region<-for_SaTAnn$P_sites_all[for_SaTAnn$P_sites_all%over%region]
    P_sites_uniq_region<-for_SaTAnn$P_sites_uniq[for_SaTAnn$P_sites_uniq%over%region]
    P_sites_uniq_mm_region<-for_SaTAnn$P_sites_uniq_mm[for_SaTAnn$P_sites_uniq_mm%over%region]
    
    res_orfs<-list()
    
    if(length(P_sites_region)>4){
        
        selected_transcripts<-select_txs(region = region,P_sites = P_sites_region,P_sites_uniq = P_sites_uniq_region,annotation = GTF_annotation,junction_counts=for_SaTAnn$junctions)
        if(length(selected_transcripts)>0){
            res_orfs<-suppressWarnings(detect_translated_orfs(selected_txs = selected_transcripts,genome_sequence = genome_seq,annotation = GTF_annotation,
                                                              P_sites = P_sites_region,P_sites_uniq = P_sites_uniq_region,P_sites_uniq_mm = P_sites_uniq_mm_region,
                                                              genomic_region=region,genetic_code=genetic_code_region,
                                                              all_starts=orf_find.all_starts,nostarts=,orf_find.nostarts,
                                                              start_sel_cutoff=orf_find.start_sel_cutoff,
                                                              start_sel_cutoff_ave=orf_find.start_sel_cutoff_ave,
                                                              cutoff_fr_ave=orf_find.cutoff_fr_ave))
        }
        if(length(res_orfs)>0){
            res_orfs<-select_quantify_ORFs(results_ORFs=res_orfs,P_sites = P_sites_region,P_sites_uniq = P_sites_uniq_region,
                                           cutoff_cums = orf_quant.cutoff_cums,cutoff_pct = orf_quant.cutoff_pct,cutoff_P_sites=orf_quant.cutoff_P_sites)
        }
        if(length(res_orfs)>0){
            
            res_orfs<-annotate_ORFs(results_ORFs=res_orfs,Annotation=GTF_annotation,genome_sequence = genome_seq,region=region,genetic_code=genetic_code_region)
            res_orfs[["readthrough"]]<-suppressWarnings(detect_readthrough(results_orf = res_orfs,P_sites = P_sites_region,P_sites_uniq = P_sites_uniq_region,P_sites_uniq_mm = P_sites_uniq_mm_region,
                                                                           genome_sequence=genome_seq, annotation = GTF_annotation,genetic_code_table=genetic_code_region,cutoff_fr_ave=orf_find.cutoff_fr_ave))
            
            
        }
        res_orfs[["genomic_features"]]<-selected_transcripts
        
    }
    
    return(res_orfs)
}

#' Run the SaTAnn pipeline
#'
#' This wrapper function runs the entire SaTAnn pipeline
#' @details A set of transcripts, together with genome sequence and Ribo-signal are analyzed to extract translated ORFs
#' @keywords SaTAnn
#' @author Lorenzo Calviello, \email{calviello.l.bio@@gmail.com}
#' @param annotation_file path to the *Rannot R file in the annotation directory used in the \code{prepare_annotation_files function}
#' @param for_SaTAnn_file path to the "for_SaTAnn" file containing P_sites positions and junction reads
#' @param n_cores number of cores to use
#' @param prefix prefix to use for the output files. Defaults to same as \code{for_SaTAnn_file} (appends to its filename)
#' @param gene_name \code{character} vector of gene names to analyze
#' @param gene_id \code{character} vector of gene ids to analyze
#' @param genomic_region \code{GRanges} object with genomic regions to analyze
#' @param write_temp_files write temporary files. Defaults to \code{TRUE}
#' @param write_GTF_file write a GTF files with the ORF coordinates. Defaults to \code{TRUE}
#' @param write_protein_fasta write a protein fasta file. Defaults to \code{TRUE}
#' @param interactive should put R object in global environment? Defaults to \code{TRUE}
#' @param stn.orf_find.all_starts \code{orf_find.all_starts} parameter for the \code{SaTAnn} function
#' @param stn.orf_find.nostarts \code{orf_find.nostarts} parameter for the \code{SaTAnn} function
#' @param stn.orf_find.start_sel_cutoff \code{orf_find.start_sel_cutoff} parameter for the \code{SaTAnn} function
#' @param stn.orf_find.start_sel_cutoff_ave \code{orf_find.start_sel_cutoff_ave} parameter for the \code{SaTAnn} functio
#' @param stn.orf_find.cutoff_fr_ave \code{orf_find.cutoff_fr_ave} parameter for the \code{SaTAnn} function
#' @param stn.orf_quant.cutoff_cums \code{orf_quant.cutoff_cums} parameter for the \code{SaTAnn} function
#' @param stn.orf_quant.cutoff_pct \code{orf_quant.cutoff_pct} parameter for the \code{SaTAnn} function
#' @param stn.orf_quant.cutoff_P_sites \code{orf_quant.cutoff_P_sites} parameter for the \code{SaTAnn} function
#' @return A set of output files containing transcript coordinates, exonic coordinates and annotation for each ORF, including optional GTF and protein fasta files.\cr\cr
#' The description for each list object is as follows:\cr\cr
#' \code{tmp_SaTAnn_results}: (Optional) RData object file containing the entire set of results for each genomic region.\cr
#' \code{final_SaTAnn_results}: RData object file containing the final SaTAnn results, see \code{SaTAnn}.\cr
#' \code{Protein_sequences.fasta}: (Optional) Fasta file containing the set of translated proteins .\cr
#' \code{Detected_ORFs.gtf}: GTF file containing coordinates of the detected ORFs.\cr\cr
#' In addition, new columns are added in the ORFs_tx file:\cr\cr
#' \code{TrP_pM}: (Beta) multitaper spectral coefficient of the P_sites track for each ORF, summing up to a million.\cr
#' \code{TrP_pN}: (Beta) multitaper spectral coefficient of the P_sites track for each ORF, divided by ORF length.\cr
#' \code{TrP_pNpM}: (Beta) multitaper spectral coefficient of the P_sites track for each ORF, divided by ORF length and summing up to a million (akin to TPM).\cr
#' \code{P_sites_pM}: number of P_sites for each ORF, summing up to a million.\cr
#' \code{P_sites_pN}: number of P_sites for each ORF, divided by ORF length.\cr
#' \code{P_sites_pNpM}: number of P_sites for each ORF, divided by ORF length and summing up to a million (akin to TPM).\cr
#' @seealso \code{\link{prepare_annotation_files}}, \code{\link{load_annotation}}, \code{\link{SaTAnn}}
#' @export

run_SaTAnn<-function(for_SaTAnn_file,annotation_file,n_cores,prefix=for_SaTAnn_file,gene_name=NA,gene_id=NA,genomic_region=NA,
                     write_temp_files=T,write_GTF_file=T,write_protein_fasta=T,interactive=T,
                     stn.orf_find.all_starts=T,stn.orf_find.nostarts=F,stn.orf_find.start_sel_cutoff = NA,
                     stn.orf_find.start_sel_cutoff_ave = .5,stn.orf_find.cutoff_fr_ave=.5,
                     stn.orf_quant.cutoff_cums = NA,stn.orf_quant.cutoff_pct = 2,stn.orf_quant.cutoff_P_sites=NA){    
    if(n_cores>1){
        registerDoMC(n_cores)
    }
    
    for (f in c(for_SaTAnn_file,annotation_file)){
        if(file.access(f, 0)==-1) {
            stop("The following files don't exist:\n",
                 f, "\n")
        }
    }
    
    cat(paste("Loading annotation and Ribo-seq signal ... ",date(),"\n",sep = ""))
    
    load_annotation(annotation_file)
    for_SaTAnn_data<-get(load(for_SaTAnn_file))
    
    genes_red<-reduce(unlist(GTF_annotation$txs_gene))
    
    if(!is.na(gene_name[1])){
        gnid<-unique(GTF_annotation$trann$gene_id[GTF_annotation$trann$gene_name%in%gene_name])
        genes_red<-genes_red[genes_red%over%GTF_annotation$genes[gnid]]
    }
    
    if(!is.na(gene_id[1])){
        genes_red<-genes_red[genes_red%over%GTF_annotation$genes[gene_id]]
    }
    
    if(!is.na(genomic_region[1])){
        genes_red<-genes_red[genes_red%over%genomic_region]
    }
    
    if(length(genes_red)==0){
        stop(paste("Incorrect gene_id | gene_name | genomic_region! ",date(),sep = ""))
    }
    
    cat(paste("Loading annotation and Ribo-seq signal --- Done! ",date(),"\n",sep = ""))
    
    ovs_genesred<-summarizeOverlaps(genes_red,reads = for_SaTAnn_data$P_sites_all)
    
    genes_red<-genes_red[which(assay(ovs_genesred)>4)]
    
    if(length(genes_red)==0){
        stop(paste("Not enough P_sites signal over genomic regions! ",date(),sep = ""))
    }
    
    cat(paste("Summoning SaTAnn with ", sum(for_SaTAnn_data$P_sites_all%over%genes_red)," P_sites positions over ", length(genes_red), " genomic regions using ",n_cores," processor(s) ... ",date(),"\n",sep = ""))
    
    if(n_cores>1){
        
        ORFs_found<-foreach(g=1:length(genes_red),.packages='GenomicRanges') %dopar%{
            
            gen_region<-genes_red[g]
            genetcd<-GTF_annotation$genetic_codes$genetic_code[rownames(GTF_annotation$genetic_codes)==as.character(seqnames(gen_region))]
            genetcd<-getGeneticCode(genetcd)
            
            SaTAnn(region=gen_region,for_SaTAnn=for_SaTAnn_data,genetic_code_region=genetcd,
                   orf_find.all_starts=stn.orf_find.all_starts,orf_find.nostarts=stn.orf_find.nostarts,
                   orf_find.start_sel_cutoff = stn.orf_find.start_sel_cutoff,orf_find.start_sel_cutoff_ave = stn.orf_find.start_sel_cutoff_ave,
                   orf_find.cutoff_fr_ave=stn.orf_find.cutoff_fr_ave,orf_quant.cutoff_cums = stn.orf_quant.cutoff_cums,
                   orf_quant.cutoff_pct = stn.orf_quant.cutoff_pct,orf_quant.cutoff_P_sites=stn.orf_quant.cutoff_P_sites)
        }
        
    }
    
    if(n_cores==1){
        ORFs_found<-list()
        for(g in 1:length(genes_red)){
            
            gen_region<-genes_red[g]
            genetcd<-GTF_annotation$genetic_codes$genetic_code[rownames(GTF_annotation$genetic_codes)==as.character(seqnames(gen_region))]
            genetcd<-getGeneticCode(genetcd)
            
            ORFs_found[[g]]<-SaTAnn(region=gen_region,for_SaTAnn=for_SaTAnn_data,genetic_code=genetcd,
                                    orf_find.all_starts=stn.orf_find.all_starts,orf_find.nostarts=stn.orf_find.nostarts,
                                    orf_find.start_sel_cutoff = stn.orf_find.start_sel_cutoff,orf_find.start_sel_cutoff_ave = stn.orf_find.start_sel_cutoff_ave,
                                    orf_find.cutoff_fr_ave=stn.orf_find.cutoff_fr_ave,orf_quant.cutoff_cums = stn.orf_quant.cutoff_cums,
                                    orf_quant.cutoff_pct = stn.orf_quant.cutoff_pct,orf_quant.cutoff_P_sites=stn.orf_quant.cutoff_P_sites)
            
            
        }
        
    }
    cat(paste("Summoning SaTAnn --- Done! ",date(),"\n",sep = ""))
    
    cat(paste("Exporting SaTAnn results ... ",date(),"\n",sep = ""))
    
    if(write_temp_files){
        save(ORFs_found,file=paste(prefix,"tmp_SaTAnn_results",sep="_"))
    }
    
    lens<-elementNROWS(ORFs_found)
    
    ORFs_found<-ORFs_found[lens>0]
    
    ORFs_txs_feats<-unlist(GRangesList(lapply(ORFs_found,function(x){unlist(x$genomic_features)})))
    ORFs_txs_feats<-ORFs_txs_feats[!duplicated(mcols(ORFs_txs_feats)) | !duplicated(ORFs_txs_feats)]
    
    selected_txs<-sort(unique(unlist(ORFs_txs_feats$txs_selected)))
    
    lens<-elementNROWS(ORFs_found)
    
    ORFs_found<-ORFs_found[lens>1]
    ORFs_tx<-unlist(GRangesList(unlist(sapply(ORFs_found,function(x){unlist(x$ORFs_tx_position)}))))
    
    ORFs_tx$TrP_pM<-NA
    na_trp<-is.na(ORFs_tx$TrP)
    ORFs_tx$TrP_pM[!na_trp]<-ORFs_tx$TrP[!na_trp]*(1000000/(sum(ORFs_tx$TrP[!na_trp])))
    ORFs_tx$TrP_pN<-NA
    ORFs_tx$TrP_pN[!na_trp]<-ORFs_tx$TrP[!na_trp]/(width(ORFs_tx)[!na_trp])
    ORFs_tx$TrP_pNpM<-NA
    ORFs_tx$TrP_pNpM[!na_trp]<-ORFs_tx$TrP_pN[!na_trp]*(1000000/(sum(ORFs_tx$TrP_pN[!na_trp])))
    ORFs_tx$P_sites_pM<-NA
    na_ps<-is.na(ORFs_tx$P_sites)
    ORFs_tx$P_sites_pM[!na_ps]<-ORFs_tx$P_sites[!na_ps]*(1000000/(sum(ORFs_tx$P_sites[!na_ps])))
    ORFs_tx$P_sites_pN<-NA
    ORFs_tx$P_sites_pN[!na_ps]<-ORFs_tx$P_sites[!na_ps]/(width(ORFs_tx)[!na_ps])
    ORFs_tx$P_sites_pNpM<-NA
    ORFs_tx$P_sites_pNpM[!na_ps]<-ORFs_tx$P_sites_pN[!na_ps]*(1000000/(sum(ORFs_tx$P_sites_pN[!na_ps])))
    
    
    ORFs_gen<-unlist(GRangesList(sapply(ORFs_found,function(x){unlist(x$ORFs_genomic_position)})))
    
    ORFs_feat<-unlist(sapply(ORFs_found,function(x){unlist(x$selected_ORFs_features)}))
    ORFs_feat<-GRangesList(sapply(ORFs_feat,function(x){
        x$X$tx_name<-NULL
        return(x)
    }))
    
    ORFs_spl_feat_longest<-unlist(GRangesList(sapply(ORFs_found,function(x){unlist(x$ORFs_splice_feats$annotation_wrt_longest)})))
    ORFs_spl_feat_maxORF<-unlist(GRangesList(sapply(ORFs_found,function(x){unlist(x$ORFs_splice_feats$annotation_wrt_maxORF)})))
    ORFs_readthroughs<-unlist(GRangesList(unlist(sapply(ORFs_found,function(x){unlist(x$readthrough)}))))
    if(length(ORFs_readthroughs)>0){
        ORFs_readthroughs<-ORFs_readthroughs[order(ORFs_readthroughs$P_sites_raw,decreasing = T)]
    }
    SaTAnn_results<-list(ORFs_tx,ORFs_gen,ORFs_feat,ORFs_spl_feat_longest,ORFs_spl_feat_maxORF,ORFs_readthroughs,ORFs_txs_feats,selected_txs)
    names(SaTAnn_results)<-c("ORFs_tx","ORFs_gen","ORFs_feat","ORFs_spl_feat_longest","ORFs_spl_feat_maxORF","ORFs_readthroughs","ORFs_txs_feats","selected_txs")
    
    save(SaTAnn_results ,file = paste(prefix,"final_SaTAnn_results",sep="_"))
    
    if(write_GTF_file){
        map_tx_genes<-mcols(ORFs_tx)[,c("ORF_id_tr","gene_id","gene_biotype","gene_name","transcript_id","transcript_biotype","TrP","ORF_pct_TrP","ORF_pct_TrP_pN","TrP_pNpM","P_sites","ORF_pct_P_sites","ORF_pct_P_sites_pN","P_sites_pNpM")]
        
        match_ORF<-match(names(ORFs_gen),map_tx_genes$ORF_id_tr)
        
        ORFs_gen$transcript_id<-map_tx_genes[match_ORF,"transcript_id"]
        
        match_tx<-match(ORFs_gen$transcript_id,map_tx_genes$transcript_id)
        
        ORFs_gen$transcript_biotype<-map_tx_genes[match_tx,"transcript_biotype"]
        ORFs_gen$gene_id<-map_tx_genes[match_tx,"gene_id"]
        ORFs_gen$gene_biotype<-map_tx_genes[match_tx,"gene_biotype"]
        ORFs_gen$gene_name<-map_tx_genes[match_tx,"gene_name"]
        ORFs_gen$ORF_id<-map_tx_genes[match_tx,"ORF_id_tr"]
        
        ORFs_gen$TrP<-round(map_tx_genes[match_ORF,"TrP"],digits=4)
        ORFs_gen$ORF_pct_TrP<-round(map_tx_genes[match_ORF,"ORF_pct_TrP"],digits=4)
        ORFs_gen$ORF_pct_TrP_pN<-round(map_tx_genes[match_ORF,"ORF_pct_TrP_pN"],digits=4)
        ORFs_gen$TrP_pNpM<-round(map_tx_genes[match_ORF,"TrP_pNpM"],digits=4)
        
        ORFs_gen$P_sites<-round(map_tx_genes[match_ORF,"P_sites"],digits=4)
        ORFs_gen$ORF_pct_P_sites<-round(map_tx_genes[match_ORF,"ORF_pct_P_sites"],digits=4)
        ORFs_gen$ORF_pct_P_sites_pN<-round(map_tx_genes[match_ORF,"ORF_pct_P_sites_pN"],digits=4)
        ORFs_gen$P_sites_pNpM<-round(map_tx_genes[match_ORF,"P_sites_pNpM"],digits=4)
        
        proteins_readthrough<-AAStringSet(ORFs_readthroughs$Protein)
        if(length(proteins_readthrough)>0){
            names(proteins_readthrough)<-paste(ORFs_readthroughs$ORF_id_tr,ORFs_readthroughs$gene_biotype,ORFs_readthroughs$gene_id,"readthrough","readthrough",sep="|")
            proteins_readthrough<-narrow(proteins_readthrough,start = start(proteins_readthrough)[1]+1)
            proteins_readthrough<-AAStringSet(gsub(proteins_readthrough,pattern = "[*]",replacement = "X"))
        }
        
        proteins<-AAStringSet(ORFs_tx$Protein)
        names(proteins)<-paste(ORFs_tx$ORF_id_tr,ORFs_tx$gene_biotype,ORFs_tx$gene_id,ORFs_tx$ORF_category_Gen,ORFs_tx$ORF_category_Tx_compatible,sep="|")
        proteins<-c(proteins,proteins_readthrough)
        if(write_protein_fasta){
            writeXStringSet(proteins,filepath= paste(prefix,"Protein_sequences.fasta",sep="_"))
        }
        
        map_tx_genes<-GTF_annotation$trann
        #ORFs_gen$transcript_id<-names(ORFs_gen)
        ORFs_gen$type="CDS"
        exs_gtf<-unlist(GTF_annotation$exons_txs[selected_txs])
        mcols(exs_gtf)<-NULL
        exs_gtf$transcript_id<-names(exs_gtf)
        exs_gtf$transcript_biotype<-map_tx_genes[match(exs_gtf$transcript_id,map_tx_genes$transcript_id),"transcript_biotype"]
        exs_gtf$gene_id<-map_tx_genes[match(exs_gtf$transcript_id,map_tx_genes$transcript_id),"gene_id"]
        exs_gtf$gene_biotype<-map_tx_genes[match(exs_gtf$transcript_id,map_tx_genes$transcript_id),"gene_biotype"]
        exs_gtf$gene_name<-map_tx_genes[match(exs_gtf$transcript_id,map_tx_genes$transcript_id),"gene_name"]
        mcols(exs_gtf)[,names(mcols(ORFs_gen))[!names(mcols(ORFs_gen))%in%names(mcols(exs_gtf))]]<-NA
        exs_gtf$type<-"exon"
        mcols(ORFs_gen)<-mcols(ORFs_gen)[,names(mcols(exs_gtf))]
        all<-sort(c(exs_gtf,ORFs_gen))
        all$`source`="SaTAnn"
        names(all)<-NULL
        suppressWarnings(export.gff2(object=all,con=paste(prefix,"Detected_ORFs.gtf",sep="_")))
    }
    
    if(interactive){
        for_SaTAnn<<-for_SaTAnn_data
        ORFs_tx<<-ORFs_tx
        ORFs_gen<<-ORFs_gen
        ORFs_feat<<-ORFs_feat
        ORFs_spl_feat_longest<<-ORFs_spl_feat_longest
        ORFs_spl_feat_maxORF<<-ORFs_spl_feat_maxORF
        ORFs_txs_feats<<-ORFs_txs_feats
        proteins<<-proteins
        ORFs_readthroughs<<-ORFs_readthroughs
    }
    cat(paste("Exporting SaTAnn results --- Done! ",date(),"\n",sep = ""))
    
}


#' Load genomic features and genome sequence
#'
#' This function loads the annotation created by the \code{prepare_annotation_files function}
#' @keywords SaTAnn, Ribo-seQC
#' @author Lorenzo Calviello, \email{calviello.l.bio@@gmail.com}
#' @param path Full path to the *Rannot R file in the annotation directory used in the \code{prepare_annotation_files function}
#' @return introduces a \code{GTF_annotation} object and a \code{genome_seq} object in the parent environment
#' @seealso \code{\link{prepare_annotation_files}}
#' @export

load_annotation<-function(path){
    GTF_annotation<-get(load(path))
    library(GTF_annotation$genome_package,character.only = T)
    genome_sequence<-get(GTF_annotation$genome_package)
    GTF_annotation<<-GTF_annotation
    genome_seq<<-genome_sequence
}



#' Prepare comprehensive sets of annotated genomic features
#'
#' This function processes a gtf file and a twobit file (created using faToTwoBit from ucsc tools: http://hgdownload.soe.ucsc.edu/admin/exe/ ) to create a comprehensive set of genomic regions of interest in genomic and transcriptomic space (e.g. introns, UTRs, start/stop codons).
#'    In addition, by linking genome sequence and annotation, it extracts additional info, such as gene and transcript biotypes, genetic codes for different organelles, or chromosomes and transcripts lengths.
#' @keywords SaTAnn, Ribo.seQC
#' @author Lorenzo Calviello, \email{calviello.l.bio@@gmail.com}
#' @param annotation_directory The target directory which will contain the output files
#' @param twobit_file Full path to the genome file in twobit format
#' @param gtf_file Full path to the annotation file in GTF format
#' @param scientific_name A name to give to the organism studied; must be two words separated by a ".", defaults to Homo.sapiens
#' @param annotation_name A name to give to annotation used; defaults to genc25
#' @param export_bed_tables_TxDb Export coordinates and info about different genomic regions in the annotation_directory? It defaults to \code{TRUE}
#' @param forge_BSgenome Forge and install a \code{BSgenome} package? It defaults to \code{TRUE}
#' @param create_TxDb Create a \code{TxDb} object and a *Rannot object? It defaults to \code{TRUE}
#' @details This function uses the \code{makeTxDbFromGFF} function to  create a TxDb object and extract
#' genomic regions and other info to a *Rannot R file; the \code{mapToTranscripts} and \code{mapFromTranscripts} functions are used to 
#' map features to genomic or transcript-level coordinates. GTF file mist contain "exon" and "CDS" lines,
#' where each line contains "transcript_id" and "gene_id" values. Additional values such as "gene_biotype" or "gene_name" are also extracted.
#' Regarding sequences, the twobit file, together with input scientific and annotation names, is used to forge and install a 
#' BSgenome package using the \code{forgeBSgenomeDataPkg} function.\cr\cr
#' The resulting GTF_annotation object (obtained after runnning \code{load_annotation}) contains:\cr\cr
#' \code{txs}: annotated transcript boundaries.\cr
#' \code{txs_gene}: GRangesList including transcript grouped by gene.\cr
#' \code{seqinfo}: indicating chromosomes and chromosome lengths.\cr
#' \code{start_stop_codons}: the set of annotated start and stop codon, with respective transcript and gene_ids.
#' reprentative_mostcommon,reprentative_boundaries and reprentative_5len represent the most common start/stop codon,
#' the most upstream/downstream start/stop codons and the start/stop codons residing on transcripts with the longest 5'UTRs\cr
#' \code{cds_txs}: GRangesList including CDS grouped by transcript.\cr
#' \code{introns_txs}: GRangesList including introns grouped by transcript.\cr
#' \code{cds_genes}: GRangesList including CDS grouped by gene.\cr
#' \code{exons_txs}: GRangesList including exons grouped by transcript.\cr
#' \code{exons_bins}: the list of exonic bins with associated transcripts and genes.\cr
#' \code{junctions}: the list of annotated splice junctions, with associated transcripts and genes.\cr
#' \code{genes}: annotated genes coordinates.\cr
#' \code{threeutrs}: collapsed set of 3'UTR regions, with correspinding gene_ids. This set does not overlap CDS region.\cr
#' \code{fiveutrs}: collapsed set of 5'UTR regions, with correspinding gene_ids. This set does not overlap CDS region.\cr
#' \code{ncIsof}: collapsed set of exonic regions of protein_coding genes, with correspinding gene_ids. This set does not overlap CDS region.\cr
#' \code{ncRNAs}: collapsed set of exonic regions of non_coding genes, with correspinding gene_ids. This set does not overlap CDS region.\cr
#' \code{introns}: collapsed set of intronic regions, with correspinding gene_ids. This set does not overlap exonic region.\cr
#' \code{intergenicRegions}: set of intergenic regions, defined as regions with no annotated genes on either strand.\cr
#' \code{trann}: DataFrame object including (when available) the mapping between gene_id, gene_name, gene_biotypes, transcript_id and transcript_biotypes.\cr
#' \code{cds_txs_coords}: transcript-level coordinates of ORF boundaries, for each annotated coding transcript. Additional columns are the same as as for the \code{start_stop_codons} object.\cr
#' \code{genetic_codes}: an object containing the list of genetic code ids used for each chromosome/organelle. see GENETIC_CODE_TABLE for more info.\cr
#' \code{genome_package}: the name of the forged BSgenome package. Loaded with \code{load_annotation} function.\cr
#' \code{stop_in_gtf}: stop codon, as defined in the annotation.\cr
#' @return a TxDb file and a *Rannot files are created in the specified \code{annotation_directory}. 
#' In addition, a BSgenome object is forged, installed, and linked to the *Rannot object
#' @seealso \code{\link{load_annotation}}, \code{\link{forgeBSgenomeDataPkg}}, \code{\link{makeTxDbFromGFF}}.
#' @export

prepare_annotation_files<-function(annotation_directory,twobit_file,gtf_file,scientific_name="Homo.sapiens",annotation_name="genc25",export_bed_tables_TxDb=T,forge_BSgenome=T,create_TxDb=T){
    
    
    DEFAULT_CIRC_SEQS <- unique(c("chrM","MT","MtDNA","mit","Mito","mitochondrion",
                                  "dmel_mitochondrion_genome","Pltd","ChrC","Pt","chloroplast",
                                  "Chloro","2micron","2-micron","2uM",
                                  "Mt", "NC_001879.2", "NC_006581.1","ChrM"))
    #adjust variable names (some chars not permitted)
    annotation_name<-gsub(annotation_name,pattern = "_",replacement = "")
    annotation_name<-gsub(annotation_name,pattern = "-",replacement = "")
    if(!dir.exists(annotation_directory)){dir.create(path = annotation_directory,recursive = T)}
    annotation_directory<-normalizePath(annotation_directory)
    twobit_file<-normalizePath(twobit_file)
    gtf_file<-normalizePath(gtf_file)
    
    for (f in c(twobit_file,gtf_file)){
        if(file.access(f, 0)==-1) {
            stop("
                 The following files don't exist:\n",
                 f, "\n")
        }
    }
    
    
    scientific_name_spl<-strsplit(scientific_name,"[.]")[[1]]
    ok<-length(scientific_name_spl)==2
    if(!ok){stop("\"scientific_name\" must be two words separated by a \".\", like \"Homo.sapiens\"")}
    
    #get circular sequences
    
    seqinfotwob<-seqinfo(TwoBitFile(twobit_file))
    circss<-seqnames(seqinfotwob)[which(seqnames(seqinfotwob)%in%DEFAULT_CIRC_SEQS)]
    seqinfotwob@is_circular[which(seqnames(seqinfotwob)%in%DEFAULT_CIRC_SEQS)]<-TRUE
    pkgnm<-paste("BSgenome",scientific_name,annotation_name,sep=".")
    
    circseed<-circss
    if(length(circseed)==0){circseed<-NULL}
    
    #Forge a BSGenome package
    
    if(forge_BSgenome){
        cat(paste("Creating the BSgenome package ... ",date(),"\n",sep = ""))
        seed_text<-paste("Package: BSgenome.",scientific_name,".",annotation_name,"\n",
                         "Title: Full genome sequences for ",scientific_name,", ",annotation_name,"\n",
                         "Description: Full genome sequences for ",scientific_name,", ",annotation_name,"\n",
                         "Version: 1.0","\n",
                         "organism: ",scientific_name,"\n",
                         "common_name: ",scientific_name,"\n",
                         "provider: NA","\n",
                         "provider_version: ",annotation_name,"\n",
                         "release_date: NA","\n",
                         "release_name: NA","\n",
                         "source_url: NA","\n",
                         "organism_biocview: ", scientific_name,"\n",
                         "BSgenomeObjname: ",scientific_name,"\n",
                         "seqs_srcdir: ",dirname(twobit_file),"\n",
                         "seqfile_name: ",basename(twobit_file),sep="")
        
        
        seed_dest<-paste(annotation_directory,"/",basename(twobit_file),"_",scientific_name,"_seed",sep = "")
        
        if(length(circseed)==1){
            seed_text<-paste(seed_text,"\n",
                             "circ_seqs: \"",circseed,"\"",sep="")
            writeLines(text = seed_text,con = seed_dest)
        }
        
        if(length(circseed)>1){
            circseed<-paste('c("',paste(circseed,collapse=","),'")',sep="")
            circseed<-gsub(circseed,pattern = ",",replacement='","')
            
            cat(seed_text,"\n","circ_seqs: ",circseed,"\n",sep="",file = seed_dest)
        }
        
        
        
        unlink(paste(annotation_directory,pkgnm,sep="/"),recursive=T)
        
        forgeBSgenomeDataPkg(x=seed_dest,destdir=annotation_directory,seqs_srcdir=dirname(twobit_file))
        cat(paste("Creating the BSgenome package --- Done! ",date(),"\n",sep = ""))
        
        cat(paste("Installing the BSgenome package ... ",date(),"\n",sep = ""))
        
        install(paste(annotation_directory,pkgnm,sep="/"))
        cat(paste("Installing the BSgenome package --- Done! ",date(),"\n",sep = ""))
        
    }
    
    #Create the TxDb from GTF and BSGenome info
    
    if(create_TxDb){
        cat(paste("Creating the TxDb object ... ",date(),"\n",sep = ""))
        
        annotation<-makeTxDbFromGFF(file=gtf_file,format="gtf",chrominfo = seqinfotwob)
        
        saveDb(annotation, file=paste(annotation_directory,"/",basename(gtf_file),"_TxDb",sep=""))
        cat(paste("Creating the TxDb object --- Done! ",date(),"\n",sep = ""))
        cat(paste("Extracting genomic regions ... ",date(),"\n",sep = ""))
        
        genes<-genes(annotation)
        exons_ge<-exonsBy(annotation,by="gene")
        exons_ge<-reduce(exons_ge)
        
        cds_gen<-cdsBy(annotation,"gene")
        cds_ge<-reduce(cds_gen)
        
        
        #define regions not overlapping CDS ( or exons when defining introns)
        
        threeutrs<-reduce(GenomicRanges::setdiff(unlist(threeUTRsByTranscript(annotation)),unlist(cds_ge),ignore.strand=FALSE))
        
        fiveutrs<-reduce(GenomicRanges::setdiff(unlist(fiveUTRsByTranscript(annotation)),unlist(cds_ge),ignore.strand=FALSE))
        
        introns<-reduce(GenomicRanges::setdiff(unlist(intronsByTranscript(annotation)),unlist(exons_ge),ignore.strand=FALSE))
        
        nc_exons<-reduce(GenomicRanges::setdiff(unlist(exons_ge),reduce(c(unlist(cds_ge),fiveutrs,threeutrs)),ignore.strand=FALSE))
        
        #assign gene ids (mutiple when overlapping multiple genes)
        ov<-findOverlaps(threeutrs,genes)
        ov<-split(subjectHits(ov),queryHits(ov))
        threeutrs$gene_id<-CharacterList(lapply(ov,FUN = function(x){names(genes)[x]}))
        ov<-findOverlaps(fiveutrs,genes)
        ov<-split(subjectHits(ov),queryHits(ov))
        fiveutrs$gene_id<-CharacterList(lapply(ov,FUN = function(x){names(genes)[x]}))
        ov<-findOverlaps(introns,genes)
        ov<-split(subjectHits(ov),queryHits(ov))
        introns$gene_id<-CharacterList(lapply(ov,FUN = function(x){names(genes)[x]}))
        ov<-findOverlaps(nc_exons,genes)
        ov<-split(subjectHits(ov),queryHits(ov))
        nc_exons$gene_id<-CharacterList(lapply(ov,FUN = function(x){names(genes)[x]}))
        
        intergenicRegions<-genes
        strand(intergenicRegions)<-"*"
        intergenicRegions <- gaps(reduce(intergenicRegions))
        intergenicRegions<-intergenicRegions[strand(intergenicRegions)=="*"]
        
        cds_tx<-cdsBy(annotation,"tx",use.names=T)
        txs_gene<-transcriptsBy(annotation,by="gene")
        genes_red<-reduce(sort(genes(annotation)))
        
        exons_tx<-exonsBy(annotation,"tx",use.names=T)
        
        transcripts_db<-transcripts(annotation)
        intron_names_tx<-intronsByTranscript(annotation,use.names=T)
        
        
        #define exonic bins, including regions overlapping multiple genes
        nsns<-disjointExons(annotation,aggregateGenes=T)
        
        
        
        #define tx_coordinates of ORF boundaries
        
        exsss_cds<-exons_tx[names(cds_tx)]
        chunks<-seq(1,length(cds_tx),by = 20000)
        if(chunks[length(chunks)]<length(cds_tx)){chunks<-c(chunks,length(cds_tx))}
        mapp<-GRangesList()
        for(i in 1:(length(chunks)-1)){
            if(i!=(length(chunks)-1)){
                mapp<-suppressWarnings(c(mapp,pmapToTranscripts(cds_tx[chunks[i]:(chunks[i+1]-1)],transcripts = exsss_cds[chunks[i]:(chunks[i+1]-1)])))
            }
            if(i==(length(chunks)-1)){
                mapp<-suppressWarnings(c(mapp,pmapToTranscripts(cds_tx[chunks[i]:(chunks[i+1])],transcripts = exsss_cds[chunks[i]:(chunks[i+1])])))
            }
        }
        cds_txscoords<-unlist(mapp)
        
        
        #extract biotypes and ids
        
        cat(paste("Extracting ids and biotypes ... ",date(),"\n",sep = ""))
        
        trann<-unique(mcols(import.gff2(gtf_file,colnames=c("gene_id","gene_biotype","gene_type","gene_name","gene_symbol","transcript_id","transcript_biotype","transcript_type"))))
        trann<-trann[!is.na(trann$transcript_id),]
        trann<-data.frame(unique(trann),stringsAsFactors=F)
        
        if(sum(!is.na(trann$transcript_biotype))==0 & sum(!is.na(trann$transcript_type))==0 ){
            trann$transcript_biotype<-"no_type"
        }
        if(sum(!is.na(trann$transcript_biotype))==0){trann$transcript_biotype<-NULL}
        if(sum(!is.na(trann$transcript_type))==0){trann$transcript_type<-NULL}
        
        
        if(sum(!is.na(trann$gene_biotype))==0 & sum(!is.na(trann$gene_type))==0 ){
            
            trann$gene_type<-"no_type"
            
        }
        if(sum(!is.na(trann$gene_name))==0 & sum(!is.na(trann$gene_symbol))==0 ){
            
            trann$gene_name<-"no_name"
            
        }
        if(sum(!is.na(trann$gene_biotype))==0){trann$gene_biotype<-NULL}
        if(sum(!is.na(trann$gene_type))==0){trann$gene_type<-NULL}
        if(sum(!is.na(trann$gene_name))==0){trann$gene_name<-NULL}
        if(sum(!is.na(trann$gene_symbol))==0){trann$gene_symbol<-NULL}
        colnames(trann)<-c("gene_id","gene_biotype","gene_name","transcript_id","transcript_biotype")
        
        trann<-DataFrame(trann)
        
        
        
        #introns and transcript_ids/gene_ids
        unq_intr<-sort(unique(unlist(intron_names_tx)))
        names(unq_intr)<-NULL
        all_intr<-unlist(intron_names_tx)
        
        ov<-findOverlaps(unq_intr,all_intr,type="equal")
        ov<-split(subjectHits(ov),queryHits(ov))
        a_nam<-CharacterList(lapply(ov,FUN = function(x){unique(names(all_intr)[x])}))
        
        unq_intr$type="J"
        unq_intr$tx_name<-a_nam
        
        
        mat_genes<-match(unq_intr$tx_name,trann$transcript_id)
        g<-unlist(apply(cbind(1:length(mat_genes),Y = elementNROWS(mat_genes)),FUN =function(x) rep(x[1],x[2]),MARGIN = 1))
        g2<-split(trann[unlist(mat_genes),"gene_id"],g)
        unq_intr$gene_id<-CharacterList(lapply(g2,unique))
        
        
        #filter ncRNA and ncIsof regions
        ncrnas<-nc_exons[!nc_exons%over%genes[trann$gene_id[trann$gene_biotype=="protein_coding"]]]
        ncisof<-nc_exons[nc_exons%over%genes[trann$gene_id[trann$gene_biotype=="protein_coding"]]]
        
        
        # define genetic codes to use
        # IMPORTANT : modify if needed (e.g. different organelles or species) check ids of GENETIC_CODE_TABLE for more info
        
        ifs<-seqinfo(annotation)
        translations<-as.data.frame(ifs)
        translations$genetic_code<-"1"
        
        #insert new codes for chromosome name
        
        #Mammalian mito
        translations$genetic_code[rownames(translations)%in%c("chrM","MT","MtDNA","mit","mitochondrion")]<-"2"
        
        #Yeast mito
        translations$genetic_code[rownames(translations)%in%c("Mito")]<-"3"
        
        #Drosophila mito
        translations$genetic_code[rownames(translations)%in%c("dmel_mitochondrion_genome")]<-"5"
        
        circs<-ifs@seqnames[which(ifs@is_circular)]
        
        
        #define start and stop codons (genome space)
        
        suppressPackageStartupMessages(library(pkgnm,character.only=TRUE))
        genome<-get(pkgnm)
        tocheck<-as.character(runValue(seqnames(cds_tx)))
        tocheck<-cds_tx[!tocheck%in%circs]
        seqcds<-extractTranscriptSeqs(genome,transcripts = tocheck)
        cd<-unique(translations$genetic_code[!rownames(translations)%in%circs])
        trsl<-suppressWarnings(translate(seqcds,genetic.code = getGeneticCode(cd),if.fuzzy.codon = "solve"))
        trslend<-as.character(narrow(trsl,end = width(trsl),width = 1))
        stop_inannot<-NA
        if(names(sort(table(trslend),decreasing = T)[1])=="*"){stop_inannot<-"*"}
        
        cds_txscoords$gene_id<-trann$gene_id[match(as.vector(seqnames(cds_txscoords)),trann$transcript_id)]
        cds_cc<-cds_txscoords
        strand(cds_cc)<-"*"
        sta_cc<-resize(cds_cc,width = 1,"start")
        sta_cc<-unlist(pmapFromTranscripts(sta_cc,exons_tx[seqnames(sta_cc)],ignore.strand=F))
        sta_cc$gene_id<-trann$gene_id[match(names(sta_cc),trann$transcript_id)]
        sta_cc<-sta_cc[sta_cc$hit]
        strand(sta_cc)<-structure(as.vector(strand(transcripts_db)),names=transcripts_db$tx_name)[names(sta_cc)]
        sta_cc$type<-"start_codon"
        mcols(sta_cc)<-mcols(sta_cc)[,c("exon_rank","type","gene_id")]
        
        sto_cc<-resize(cds_cc,width = 1,"end")
        #stop codon is the 1st nt, e.g. U of the UAA
        #To-do: update with regards to different organelles, and different annotations
        sto_cc<-shift(sto_cc,-2)
        if(is.na(stop_inannot)){sto_cc<-shift(sto_cc,3)}
        
        sto_cc<-unlist(pmapFromTranscripts(sto_cc,exons_tx[seqnames(sto_cc)],ignore.strand=F))
        sto_cc<-sto_cc[sto_cc$hit]
        sto_cc$gene_id<-trann$gene_id[match(names(sto_cc),trann$transcript_id)]
        strand(sto_cc)<-structure(as.vector(strand(transcripts_db)),names=transcripts_db$tx_name)[names(sto_cc)]
        sto_cc$type<-"stop_codon"
        mcols(sto_cc)<-mcols(sto_cc)[,c("exon_rank","type","gene_id")]
        
        
        #define most common, most upstream/downstream
        
        cat(paste("Defining most common start/stop codons ... ",date(),"\n",sep = ""))
        
        start_stop_cc<-sort(c(sta_cc,sto_cc))
        start_stop_cc$transcript_id<-names(start_stop_cc)
        start_stop_cc$most_up_downstream<-FALSE
        start_stop_cc$most_frequent<-FALSE
        
        df<-cbind.DataFrame(start(start_stop_cc),start_stop_cc$type,start_stop_cc$gene_id)
        colnames(df)<-c("start_pos","type","gene_id")
        upst<-by(df$start_pos,INDICES = df$gene_id,function(x){x==min(x) | x==max(x)})
        start_stop_cc$most_up_downstream<-unlist(upst[unique(df$gene_id)])
        
        mostfr<-by(df[,c("start_pos","type")],INDICES = df$gene_id,function(x){
            mfreq<-table(x)
            x$start_pos%in%as.numeric(names(which(mfreq[,1]==max(mfreq[,1])))) | x$start_pos%in%as.numeric(names(which(mfreq[,2]==max(mfreq[,2]))))
        })
        
        start_stop_cc$most_frequent<-unlist(mostfr[unique(df$gene_id)])
        
        names(start_stop_cc)<-NULL
        
        
        
        #define transcripts as containing frequent start/stop codons or most upstream ones, in relation with 5'UTR length
        
        mostupstr_tx<-sum(LogicalList(split(start_stop_cc$most_up_downstream,start_stop_cc$transcript_id)))[as.character(seqnames(cds_txscoords))]
        cds_txscoords$upstr_stasto<-mostupstr_tx
        mostfreq_tx<-sum(LogicalList(split(start_stop_cc$most_frequent,start_stop_cc$transcript_id)))[as.character(seqnames(cds_txscoords))]
        cds_txscoords$mostfreq_stasto<-mostfreq_tx
        cds_txscoords$lentx<-sum(width(exons_tx[as.character(seqnames(cds_txscoords))]))
        df<-cbind.DataFrame(as.character(seqnames(cds_txscoords)),width(cds_txscoords),start(cds_txscoords),cds_txscoords$mostfreq_stasto,cds_txscoords$gene_id)
        colnames(df)<-c("txid","cdslen","utr5len","var","gene_id")
        repres_freq<-by(df[,c("txid","cdslen","utr5len","var")],df$gene_id,function(x){
            x<-x[order(x$var,x$utr5len,x$cdslen,decreasing = T),]
            x<-x[x$var==max(x$var),]
            ok<-x$txid[which(x$cdslen==max(x$cdslen) & x$utr5len==max(x$utr5len) & x$var==max(x$var))][1]
            if(length(ok)==0 | is.na(ok[1])){ok<-x$txid[1]}
            ok
        })
        
        df<-cbind.DataFrame(as.character(seqnames(cds_txscoords)),width(cds_txscoords),start(cds_txscoords),cds_txscoords$upstr_stasto,cds_txscoords$gene_id)
        colnames(df)<-c("txid","cdslen","utr5len","var","gene_id")
        repres_upstr<-by(df[,c("txid","cdslen","utr5len","var")],df$gene_id,function(x){
            x<-x[order(x$var,x$utr5len,x$utr5len,decreasing = T),]
            x<-x[x$var==max(x$var),]
            ok<-x$txid[which(x$cdslen==max(x$cdslen) & x$utr5len==max(x$utr5len) & x$var==max(x$var))][1]
            if(length(ok)==0 | is.na(ok[1])){ok<-x$txid[1]}
            ok
        })
        df<-cbind.DataFrame(as.character(seqnames(cds_txscoords)),width(cds_txscoords),start(cds_txscoords),cds_txscoords$upstr_stasto,cds_txscoords$gene_id)
        colnames(df)<-c("txid","cdslen","utr5len","var","gene_id")
        repres_len5<-by(df[,c("txid","cdslen","utr5len","var")],df$gene_id,function(x){
            x<-x[order(x$utr5len,x$var,x$cdslen,decreasing = T),]
            ok<-x$txid[which(x$utr5len==max(x$utr5len) & x$var==max(x$var))][1]
            if(length(ok)==0 | is.na(ok[1])){ok<-x$txid[1]}
            ok
        })
        
        cds_txscoords$reprentative_mostcommon<-as.character(seqnames(cds_txscoords))%in%unlist(repres_freq)
        cds_txscoords$reprentative_boundaries<-as.character(seqnames(cds_txscoords))%in%unlist(repres_upstr)
        cds_txscoords$reprentative_5len<-as.character(seqnames(cds_txscoords))%in%unlist(repres_len5)
        unq_stst<-start_stop_cc
        mcols(unq_stst)<-NULL
        unq_stst<-sort(unique(unq_stst))
        ov<-findOverlaps(unq_stst,start_stop_cc,type="equal")
        ov<-split(subjectHits(ov),queryHits(ov))
        unq_stst$type<-CharacterList(lapply(ov,FUN = function(x){unique(start_stop_cc$type[x])}))
        unq_stst$transcript_id<-CharacterList(lapply(ov,FUN = function(x){start_stop_cc$transcript_id[x]}))
        unq_stst$gene_id<-CharacterList(lapply(ov,FUN = function(x){unique(start_stop_cc$gene_id[x])}))
        
        unq_stst$reprentative_mostcommon<-sum(!is.na(match(unq_stst$transcript_id,unlist(as(repres_freq,"CharacterList")))))>0
        unq_stst$reprentative_boundaries<-sum(!is.na(match(unq_stst$transcript_id,unlist(as(repres_upstr,"CharacterList")))))>0
        unq_stst$reprentative_5len<-sum(!is.na(match(unq_stst$transcript_id,unlist(as(repres_len5,"CharacterList")))))>0
        
        
        #put in a list
        GTF_annotation<-list(transcripts_db,txs_gene,ifs,unq_stst,cds_tx,intron_names_tx,cds_gen,exons_tx,nsns,unq_intr,genes,threeutrs,fiveutrs,ncisof,ncrnas,introns,intergenicRegions,trann,cds_txscoords,translations,pkgnm,stop_inannot)
        names(GTF_annotation)<-c("txs","txs_gene","seqinfo","start_stop_codons","cds_txs","introns_txs","cds_genes","exons_txs","exons_bins","junctions","genes","threeutrs","fiveutrs","ncIsof","ncRNAs","introns","intergenicRegions","trann","cds_txs_coords","genetic_codes","genome_package","stop_in_gtf")
        
        #Save as a RData object
        save(GTF_annotation,file=paste(annotation_directory,"/",basename(gtf_file),"_Rannot",sep=""))
        cat(paste("Rannot object created!   ",date(),"\n",sep = ""))
        
        
        #create tables and bed files (with colnames, so with header)
        if(export_bed_tables_TxDb==T){
            cat(paste("Exporting annotation tables ... ",date(),"\n",sep = ""))
            for(bed_file in c("fiveutrs","threeutrs","ncIsof","ncRNAs","introns","cds_txs_coords")){
                bf<-GTF_annotation[[bed_file]]
                bf_t<-data.frame(chromosome=seqnames(bf),start=start(bf),end=end(bf),name=".",score=width(bf),strand=strand(bf))
                meccole<-mcols(bf)
                for(mecc in names(meccole)){
                    if(is(meccole[,mecc],"CharacterList") | is(meccole[,mecc],"NumericList") | is(meccole[,mecc],"IntegerList")){
                        meccole[,mecc]<-paste(meccole[,mecc],collapse=";")
                    }
                }
                bf_t<-cbind.data.frame(bf_t,meccole)
                write.table(bf_t,file = paste(annotation_directory,"/",bed_file,"_similbed.bed",sep=""),sep="\t",quote = FALSE,row.names = FALSE)
                
            }
            
            write.table(GTF_annotation$trann,file = paste(annotation_directory,"/table_gene_tx_IDs",sep=""),sep="\t",quote = FALSE,row.names = FALSE)
            seqi<-as.data.frame(GTF_annotation$seqinfo)
            seqi$chromosome<-rownames(seqi)
            write.table(seqi,file = paste(annotation_directory,"/seqinfo",sep=""),sep="\t",quote = FALSE,row.names = FALSE)
            
            gen_cod<-as.data.frame(GTF_annotation$genetic_codes)
            gen_cod$chromosome<-rownames(gen_cod)
            write.table(gen_cod,file = paste(annotation_directory,"/genetic_codes",sep=""),sep="\t",quote = FALSE,row.names = FALSE)
            cat(paste("Exporting annotation tables --- Done! ",date(),"\n",sep = ""))
            
        }
        
    }
    
    }



#' Offset spliced reads on plus strand
#'
#' This function calculates P-sites positions for spliced reads on the plus strand
#' @keywords Ribo-seQC, SaTAnn
#' @author Lorenzo Calviello, \email{calviello.l.bio@@gmail.com}
#' @param x a \code{GAlignments} object with a cigar string
#' @param cutoff number representing the offset value
#' @return a \code{GRanges} object with offset reads
#' @seealso \code{\link{prepare_for_SaTAnn}}
#' @export

get_ps_fromspliceplus<-function(x,cutoff){
    rang<-cigarRangesAlongReferenceSpace(cigar(x), pos=start(x),ops="M")
    cs<-lapply(rang,function(x){cumsum(x@width)})
    rangok<-lapply(which(IntegerList(cs)>cutoff),"[[",1)
    rangok<-unlist(rangok)
    gr<-as(x,"GRanges")
    
    ones<-rangok==1
    mores<-rangok>1
    psmores<-GRanges()
    psones<-GRanges()
    
    if(sum(ones)>0){
        psones<-shift(resize(gr[ones],width=1,fix="start"),shift=cutoff)
    }
    
    if(sum(mores)>0){
        rangmore<-rang[mores]
        rangok<-rangok[mores]
        cms<-cumsum(width(rangmore))
        shft<-c()
        for(i in 1:length(rangok)){shft<-c(shft,cutoff-cms[[i]][rangok[i]-1])}
        stt<-start(rangmore)
        stok<-c()
        for(i in 1:length(shft)){stok<-c(stok,stt[[i]][rangok[i]]+shft[i])}
        psmores<-GRanges(IRanges(start=stok,width = 1),seqnames = seqnames(x[mores]),strand=strand(x[mores]),seqlengths=seqlengths(x[mores]))
        
    }
    ps<-sort(c(psones,psmores))
    return(ps)
}

#' Offset spliced reads on minus strand
#'
#' This function calculates P-sites positions for spliced reads on the minus strand
#' @keywords Ribo-seQC, SaTAnn
#' @author Lorenzo Calviello, \email{calviello.l.bio@@gmail.com}
#' @param x a \code{GAlignments} object with a cigar string
#' @param cutoff number representing the offset value
#' @return a \code{GRanges} object with offset reads
#' @seealso \code{\link{prepare_for_SaTAnn}}
#' @export

get_ps_fromsplicemin<-function(x,cutoff){
    rang<-cigarRangesAlongReferenceSpace(cigar(x), pos=start(x),ops="M")
    rang<-endoapply(rang,rev)
    cs<-lapply(rang,function(x){cumsum(x@width)})
    rangok<-lapply(which(IntegerList(cs)>cutoff),"[[",1)
    rangok<-unlist(rangok)
    gr<-as(x,"GRanges")
    
    ones<-rangok==1
    mores<-rangok>1
    psmores<-GRanges()
    psones<-GRanges()
    
    
    if(sum(ones)>0){
        psones<-shift(resize(gr[ones],width=1,fix="start"),shift=-cutoff)
    }
    
    
    if(sum(mores)>0){
        rangmore<-rang[mores]
        rangok<-rangok[mores]
        cms<-cumsum(width(rangmore))
        shft<-c()
        for(i in 1:length(rangok)){shft<-c(shft,cutoff-cms[[i]][rangok[i]-1])}
        #start?
        stt<-end(rangmore)
        stok<-c()
        for(i in 1:length(shft)){stok<-c(stok,stt[[i]][rangok[i]]-shft[i])}
        psmores<-GRanges(IRanges(start=stok,width = 1),seqnames = seqnames(x[mores]),strand=strand(x[mores]),seqlengths=seqlengths(x[mores]))
        
    }
    ps<-sort(c(psones,psmores))
    return(ps)
    
    
    if(rangok!=1){
        
        ps<-shift(resize(GRanges(rang[rangok],seqnames=seqnames(x),strand=strand(x),seqlengths=seqlengths(x)),width=1,fix="start"),shift=-(cutoff-sum(rang[1:(rangok-1)]@width)))
    }
    return(ps)
}

#' Prepare the "for_SaTAnn" file
#'
#' 
#' @details This function uses a list of pre-determined read lengths, cutoffs and compartments to calculate P_sites positions.\cr
#' Alternatively, bigwig files containing P_sites position for each strand can be specified. Optional bigwig files for uniquely mapping P_sites position (with and without mismatches)
#' can be specified to obtain more statistics on the SaTAnn-identified ORFs
#' @keywords SaTAnn
#' @author Lorenzo Calviello, \email{calviello.l.bio@@gmail.com}
#' @param annotation_file Full path to the annotation file (*Rannot)
#' @param bam_file Full path to the bam file
#' @param chunk_size the number of alignments to read at each iteration, defaults to 5000000, increase when more RAM is available
#' @param path_to_rl_cutoff_file path to the rl_cutoff_file file specifying in 3 columns the read lengths, cutoffs and compartments
#' @param path_to_P_sites_plus_bw path to a bigwig file containing P_sites positions on the plus strand
#' @param path_to_P_sites_minus_bw path to a bigwig file containing P_sites positions on the minus strand
#' @param path_to_P_sites_uniq_plus_bw (Optional) path to a bigwig file containing uniquely mapping P_sites positions on the plus strand
#' @param path_to_P_sites_uniq_minus_bw (Optional) path to a bigwig file containing uniquely mapping P_sites positions on the minus strand
#' @param path_to_P_sites_uniq_mm_plus_bw (Optional) path to a bigwig file containing uniquely mapping (with mismatches) P_sites positions on the plus strand
#' @param path_to_P_sites_uniq_mm_minus_bw (Optional) path to a bigwig file containing uniquely mapping (with mismatches) P_sites positions on the minus strand
#' @param dest_name prefix to use for the output files. Defaults to same as \code{bam_file} (appends "for_SaTAnn" to its filename)
#' @seealso \code{\link{run_SaTAnn}}
#' @export

prepare_for_SaTAnn<-function(annotation_file,bam_file,path_to_rl_cutoff_file=NA,chunk_size=5000000,path_to_P_sites_plus_bw=NA,
                             path_to_P_sites_minus_bw=NA,path_to_P_sites_uniq_plus_bw=NA,path_to_P_sites_uniq_minus_bw=NA,
                             path_to_P_sites_uniq_mm_plus_bw=NA,path_to_P_sites_uniq_mm_minus_bw=NA,
                             dest_name=NA){
    
    load_annotation(annotation_file)
    
    if(is.na(dest_name)){dest_name=bam_file}
    
    if(is.na(path_to_rl_cutoff_file) & is.na(path_to_P_sites_plus_bw) & is.na(path_to_P_sites_minus_bw)){
        stop(paste("Please input either the paths to the P_sites bw files, or the path a suitable rl_cutoff table! ", date(),sep=""))
    }
    
    if(!is.na(path_to_rl_cutoff_file) & !is.na(path_to_P_sites_plus_bw) & !is.na(path_to_P_sites_minus_bw)){
        stop(paste("Please input either the paths to the P_sites bw files, or the path a suitable rl_cutoff table! ", date(),sep=""))
    }
    
    if(!is.na(path_to_rl_cutoff_file)){
        rl_cutoff<-read.table(path_to_rl_cutoff_file,header = T,sep = "\t",stringsAsFactors = F)
        
        if(dim(rl_cutoff)[2]!=3){stop(
            paste("Error: please format the rl_cutoff file correctly, using 3 tab-separated columns with 'rl', 'cutoff' and 'compartment' as column names! ",date(),sep="")
        )}
        
        rl_cutoffs_comp<-split(rl_cutoff,rl_cutoff[,3])
        compnms<-names(rl_cutoffs_comp)
        
        for(compar in compnms){
            cat(paste("Using ",paste(rl_cutoffs_comp[[compar]][,1],collapse=","), " nt long footprints with ",paste(rl_cutoffs_comp[[compar]][,2],collapse=",")," as cutoffs, '", compar,"' compartment ... ","\n",sep=""))
        }
    }
    
    opts <- BamFile(file=bam_file, yieldSize=chunk_size) 
    circs_seq<-seqnames(GTF_annotation$seqinfo)[which(isCircular(GTF_annotation$seqinfo))]
    seqs <- seqinfo(opts)
    circs <- seqs@seqnames[which(seqs@seqnames%in%circs_seq)]
    
    param <- ScanBamParam(flag=scanBamFlag(isDuplicate=FALSE,isSecondaryAlignment=FALSE),what=c("mapq"),tag = "MD")
    seqllll<-seqlevels(GTF_annotation$seqinfo)
    seqleee<-seqlengths(GTF_annotation$seqinfo)
    
    input_P_sites<-GRanges()
    seqlevels(input_P_sites)<-seqllll
    seqlengths(input_P_sites)<-seqleee
    input_P_sites_uniq<-input_P_sites
    input_P_sites_uniq_mm<-input_P_sites
    
    if(!is.na(path_to_P_sites_plus_bw)){
        input_P_sites_mn<-GRanges()
        input_P_sites_pl<-import(path_to_P_sites_plus_bw)
        strand(input_P_sites_pl)<-"+"
        if(!is.na(path_to_P_sites_minus_bw)){
            input_P_sites_mn<-import(path_to_P_sites_minus_bw)
            strand(input_P_sites_mn)<-"-"
        }
        suppressWarnings(input_P_sites<-sort(c(input_P_sites_pl,input_P_sites_mn)))
        seqlevels(input_P_sites,pruning.mode="coarse")<-seqllll
        seqlengths(input_P_sites)<-seqleee
        
    }
    
    if(!is.na(path_to_P_sites_uniq_plus_bw)){
        input_P_sites_uniq_mn<-GRanges()
        input_P_sites_uniq_pl<-import(path_to_P_sites_uniq_plus_bw)
        strand(input_P_sites_uniq_pl)<-"+"
        if(!is.na(path_to_P_sites_uniq_minus_bw)){
            input_P_sites_uniq_mn<-import(path_to_P_sites_uniq_minus_bw)
            strand(input_P_sites_uniq_mn)<-"-"
        }
        suppressWarnings(input_P_sites_uniq<-sort(c(input_P_sites_uniq_pl,input_P_sites_uniq_mn)))
        seqlevels(input_P_sites_uniq,pruning.mode="coarse")<-seqllll
        seqlengths(input_P_sites_uniq)<-seqleee
        
    }
    
    if(!is.na(path_to_P_sites_uniq_mm_plus_bw)){
        input_P_sites_uniq_mm_mn<-GRanges()
        input_P_sites_uniq_mm_pl<-import(path_to_P_sites_uniq_mm_plus_bw)
        strand(input_P_sites_uniq_mm_pl)<-"+"
        if(!is.na(path_to_P_sites_uniq_mm_minus_bw)){
            input_P_sites_uniq_mm_mn<-import(path_to_P_sites_uniq_mm_minus_bw)
            strand(input_P_sites_uniq_mm_mn)<-"-"
        }
        suppressWarnings(input_P_sites_uniq<-sort(c(input_P_sites_uniq_mm_pl,input_P_sites_uniq_mm_mn)))
        seqlevels(input_P_sites_uniq,pruning.mode="coarse")<-seqllll
        seqlengths(input_P_sites_uniq)<-seqleee
        
    }
    
    reduc<-function(x,y){
        all_ps<-x[["P_sites_all"]]
        uniq_ps<-x[["P_sites_uniq"]]
        uniq_mm_ps<-x[["P_sites_uniq_mm"]]
        
        if(!is.na(path_to_rl_cutoff_file)){
            all_ps<-GRangesList()
            rls<-unique(c(names(x[["P_sites_all"]]),names(y[["P_sites_all"]])))
            
            for(rl in rls){
                reads_x<-GRanges()
                reads_y<-GRanges()
                
                seqlevels(reads_x)<-seqllll
                seqlevels(reads_y)<-seqllll
                
                seqlengths(reads_x)<-seqleee
                seqlengths(reads_y)<-seqleee
                
                if(sum(rl%in%names(x[["P_sites_all"]]))>0){reads_x<-x[["P_sites_all"]][[rl]]}
                if(sum(rl%in%names(y[["P_sites_all"]]))>0){reads_y<-y[["P_sites_all"]][[rl]]}
                
                plx<-reads_x[strand(reads_x)=="+"]
                mnx<-reads_x[strand(reads_x)=="-"]
                ply<-reads_y[strand(reads_y)=="+"]
                mny<-reads_y[strand(reads_y)=="-"]
                if(length(plx)>0){covv_pl<-coverage(plx,weight = plx$score)}else{covv_pl<-coverage(plx)}
                if(length(ply)>0){covv_pl<-covv_pl+coverage(ply,weight = ply$score)}
                
                covv_pl<-GRanges(covv_pl)
                covv_pl<-covv_pl[covv_pl$score>0]
                
                if(length(mnx)>0){covv_min<-coverage(mnx,weight = mnx$score)}else{covv_min<-coverage(mnx)}
                if(length(mny)>0){covv_min<-covv_min+coverage(mny,weight = mny$score)}
                
                covv_min<-GRanges(covv_min)
                covv_min<-covv_min[covv_min$score>0]
                
                strand(covv_pl)<-"+"
                strand(covv_min)<-"-"
                
                all_ps[[rl]]<-sort(c(covv_pl,covv_min))
                
            }
            
            uniq_ps<-GRangesList()
            rls<-unique(c(names(x[["P_sites_uniq"]]),names(y[["P_sites_uniq"]])))
            
            for(rl in rls){
                reads_x<-GRanges()
                reads_y<-GRanges()
                
                seqlevels(reads_x)<-seqllll
                seqlevels(reads_y)<-seqllll
                
                seqlengths(reads_x)<-seqleee
                seqlengths(reads_y)<-seqleee
                if(sum(rl%in%names(x[["P_sites_uniq"]]))>0){reads_x<-x[["P_sites_uniq"]][[rl]]}
                if(sum(rl%in%names(y[["P_sites_uniq"]]))>0){reads_y<-y[["P_sites_uniq"]][[rl]]}
                
                plx<-reads_x[strand(reads_x)=="+"]
                mnx<-reads_x[strand(reads_x)=="-"]
                ply<-reads_y[strand(reads_y)=="+"]
                mny<-reads_y[strand(reads_y)=="-"]
                if(length(plx)>0){covv_pl<-coverage(plx,weight = plx$score)}else{covv_pl<-coverage(plx)}
                if(length(ply)>0){covv_pl<-covv_pl+coverage(ply,weight = ply$score)}
                
                covv_pl<-GRanges(covv_pl)
                covv_pl<-covv_pl[covv_pl$score>0]
                
                if(length(mnx)>0){covv_min<-coverage(mnx,weight = mnx$score)}else{covv_min<-coverage(mnx)}
                if(length(mny)>0){covv_min<-covv_min+coverage(mny,weight = mny$score)}
                
                covv_min<-GRanges(covv_min)
                covv_min<-covv_min[covv_min$score>0]
                
                strand(covv_pl)<-"+"
                strand(covv_min)<-"-"
                
                uniq_ps[[rl]]<-sort(c(covv_pl,covv_min))
                
                
            }
            
            uniq_mm_ps<-GRangesList()
            rls<-unique(c(names(x[["P_sites_uniq_mm"]]),names(y[["P_sites_uniq_mm"]])))
            
            for(rl in rls){
                reads_x<-GRanges()
                reads_y<-GRanges()
                
                seqlevels(reads_x)<-seqllll
                seqlevels(reads_y)<-seqllll
                
                seqlengths(reads_x)<-seqleee
                seqlengths(reads_y)<-seqleee
                if(sum(rl%in%names(x[["P_sites_uniq_mm"]]))>0){reads_x<-x[["P_sites_uniq_mm"]][[rl]]}
                if(sum(rl%in%names(y[["P_sites_uniq_mm"]]))>0){reads_y<-y[["P_sites_uniq_mm"]][[rl]]}
                
                plx<-reads_x[strand(reads_x)=="+"]
                mnx<-reads_x[strand(reads_x)=="-"]
                ply<-reads_y[strand(reads_y)=="+"]
                mny<-reads_y[strand(reads_y)=="-"]
                if(length(plx)>0){covv_pl<-coverage(plx,weight = plx$score)}else{covv_pl<-coverage(plx)}
                if(length(ply)>0){covv_pl<-covv_pl+coverage(ply,weight = ply$score)}
                
                covv_pl<-GRanges(covv_pl)
                covv_pl<-covv_pl[covv_pl$score>0]
                
                if(length(mnx)>0){covv_min<-coverage(mnx,weight = mnx$score)}else{covv_min<-coverage(mnx)}
                if(length(mny)>0){covv_min<-covv_min+coverage(mny,weight = mny$score)}
                
                covv_min<-GRanges(covv_min)
                covv_min<-covv_min[covv_min$score>0]
                
                strand(covv_pl)<-"+"
                strand(covv_min)<-"-"
                
                uniq_mm_ps[[rl]]<-sort(c(covv_pl,covv_min))
                
            }
        }
        
        rang_jun<-x$junctions
        rang_jun$reads<-rang_jun$reads+y$junctions$reads
        rang_jun$unique_reads<-rang_jun$unique_reads+y$junctions$unique_reads
        
        list_res<-list(all_ps,uniq_ps,uniq_mm_ps,rang_jun)
        names(list_res)<-c("P_sites_all","P_sites_uniq","P_sites_uniq_mm","junctions")
        
        
        return(list_res)
    }
    
    #what to do with each chunk (read as alignment file)
    
    yiel<-function(x){
        readGAlignments(x,param = param)
    }
    
    #operations on the chunk (here count reads and whatnot)
    
    mapp<-function(x){
        x_I<-x[grep("I",cigar(x))]
        
        if(length(x_I)>0){
            x<-x[grep("I",cigar(x),invert=T)]
            
        }
        x_D<-x[grep("D",cigar(x))]
        if(length(x_D)>0){
            x<-x[grep("D",cigar(x),invert=T)]
            
        }
        
        
        # softclipping
        
        
        clipp <- width(cigarRangesAlongQuerySpace(x@cigar, ops="S"))
        clipp[elementNROWS(clipp)==0] <- 0
        len_adj <- qwidth(x)-sum(clipp)
        mcols(x)$len_adj <- len_adj
        
        # Remove S from Cigar (read positions/length are already adjusted)
        # it helps calculating P-sites positions for spliced reads
        
        cigg<-cigar(x)
        cigg_s<-grep(cigg,pattern = "S")
        if(length(cigg_s)>0){
            cigs<-cigg[cigg_s]
            cigs<-gsub(cigs,pattern = "^[0-9]+S",replacement = "")
            cigs<-gsub(cigs,pattern = "[0-9]+S$",replacement = "")
            cigg[cigg_s]<-cigs
            x@cigar<-cigg
        }
        mcols(x)$cigar_str<-x@cigar
        x_uniq<-x[x@elementMetadata$mapq>50]
        
        pos<-x[strand(x)=="+"]
        neg<-x[strand(x)=="-"]
        
        uniq_pos<-x_uniq[strand(x_uniq)=="+"]
        uniq_neg<-x_uniq[strand(x_uniq)=="-"]
        
        
        
        # junctions
        
        juns<-summarizeJunctions(x)
        juns_pos<-juns
        juns_neg<-juns
        mcols(juns_pos)<-NULL
        mcols(juns_neg)<-NULL
        juns_pos$reads<-juns$plus_score
        juns_neg$reads<-juns$minus_score
        strand(juns_pos)<-"+"
        strand(juns_neg)<-"-"
        juns<-sort(c(juns_pos,juns_neg))
        juns<-juns[juns$reads>0]
        
        uniq_juns<-summarizeJunctions(x_uniq)
        uniq_juns_pos<-uniq_juns
        uniq_juns_neg<-uniq_juns
        mcols(uniq_juns_pos)<-NULL
        mcols(uniq_juns_neg)<-NULL
        uniq_juns_pos$reads<-uniq_juns$plus_score
        uniq_juns_neg$reads<-uniq_juns$minus_score
        strand(uniq_juns_pos)<-"+"
        strand(uniq_juns_neg)<-"-"
        uniq_juns<-sort(c(uniq_juns_pos,uniq_juns_neg))
        uniq_juns<-uniq_juns[uniq_juns$reads>0]
        if(length(juns)>0){
            juns$unique_reads<-0
            mat<-match(uniq_juns,juns)
            juns$unique_reads[mat]<-uniq_juns$reads
        }
        rang_jun<-GTF_annotation$junctions
        rang_jun$reads<-0
        rang_jun$unique_reads<-0
        if(length(juns)>0){
            mat<-match(juns,rang_jun)
            juns<-juns[!is.na(mat)]
            mat<-mat[!is.na(mat)]
            rang_jun$reads[mat]<-juns$reads
            rang_jun$unique_reads[mat]<-juns$unique_reads
        }
        
        
        # P-sites calculation
        all_ps_comps<-GRanges()
        seqlevels(all_ps_comps)<-seqllll
        seqlengths(all_ps_comps)<-seqleee
        
        uniq_ps_comps<-GRanges()
        seqlevels(uniq_ps_comps)<-seqllll
        seqlengths(uniq_ps_comps)<-seqleee
        
        uniq_mm_ps_comps<-GRanges()
        seqlevels(uniq_mm_ps_comps)<-seqllll
        seqlengths(uniq_mm_ps_comps)<-seqleee
        
        if(!is.na(path_to_rl_cutoff_file)){
            list_pss<-list()
            for(comp in names(rl_cutoffs_comp)){
                all_rl_ps<-GRangesList()
                uniq_rl_ps<-GRangesList()
                uniq_rl_mm_ps<-GRangesList()
                
                seqlevels(all_rl_ps)<-seqllll
                seqlevels(uniq_rl_ps)<-seqllll
                seqlevels(uniq_rl_mm_ps)<-seqllll
                
                seqlengths(all_rl_ps)<-seqleee
                seqlengths(uniq_rl_ps)<-seqleee
                seqlengths(uniq_rl_mm_ps)<-seqleee
                
                
                chroms<-comp
                
                if(comp=="nucl"){chroms=seqlevels(x)[!seqlevels(x)%in%circs]}
                resul<-rl_cutoffs_comp[[comp]]
                
                for(i in seq_along(resul$read_length)){
                    
                    all_ps<-GRangesList()
                    uniq_ps<-GRangesList()
                    uniq_mm_ps<-GRangesList()
                    seqlevels(all_ps)<-seqllll
                    seqlevels(uniq_ps)<-seqllll
                    seqlevels(uniq_mm_ps)<-seqllll
                    
                    seqlengths(all_ps)<-seqleee
                    seqlengths(uniq_ps)<-seqleee
                    seqlengths(uniq_mm_ps)<-seqleee
                    
                    rl<-as.numeric(resul$read_length[i])
                    ct<-as.numeric(resul$cutoff[i])
                    ok_reads<-pos[mcols(pos)$len_adj%in%rl]
                    ok_reads<-ok_reads[as.vector(seqnames(ok_reads))%in%chroms]
                    
                    ps_plus<-GRanges()
                    seqlevels(ps_plus)<-seqllll
                    seqlengths(ps_plus)<-seqleee
                    ps_plus_uniq<-ps_plus
                    ps_plus_uniq_mm<-ps_plus
                    
                    if(length(ok_reads)>0){
                        unspl<-ok_reads[grep(pattern="N",x=cigar(ok_reads),invert=T)]
                        
                        ps_unspl<-shift(resize(GRanges(unspl),width=1,fix="start"),shift=ct)
                        
                        spl<-ok_reads[grep(pattern="N",x=cigar(ok_reads))]
                        firstb<-as.numeric(sapply(strsplit(cigar(spl),"M"),"[[",1))
                        lastb<-as.numeric(sapply(strsplit(cigar(spl),"M"),function(x){gsub(x[length(x)],pattern="^[^_]*N",replacement="")}))
                        firstok<-spl[firstb>ct]
                        firstok<-shift(resize(GRanges(firstok),width=1,fix="start"),shift=ct)
                        
                        lastok<-spl[lastb>=rl-ct]
                        lastok<-shift(resize(GRanges(lastok),width=1,fix="end"),shift=-(rl-ct-1))
                        
                        
                        multi<-spl[firstb<=ct & lastb<rl-ct]
                        
                        
                        ps_spl<-GRanges()
                        seqlevels(ps_spl)<-seqllll
                        seqlengths(ps_spl)<-seqleee
                        
                        if(length(multi)>0){
                            ps_spl<-get_ps_fromspliceplus(multi,cutoff=ct)
                            
                        }
                        mcols(ps_unspl)<-NULL
                        mcols(firstok)<-NULL
                        mcols(lastok)<-NULL
                        mcols(ps_spl)<-NULL
                        
                        seqlevels(firstok)<-seqllll
                        seqlevels(lastok)<-seqllll
                        seqlevels(ps_unspl)<-seqllll
                        seqlevels(ps_spl)<-seqllll
                        
                        seqlengths(firstok)<-seqleee
                        seqlengths(lastok)<-seqleee
                        seqlengths(ps_unspl)<-seqleee
                        seqlengths(ps_spl)<-seqleee
                        
                        ps_plus<-c(ps_unspl,firstok,lastok,ps_spl)
                        
                        ps_plus_uniq<-ps_plus[mcols(ok_reads)$mapq>50]
                        ps_plus_uniq_mm<-ps_plus[mcols(ok_reads)$mapq>50 & nchar(mcols(ok_reads)$MD)>3]
                        
                    }
                    ok_reads<-neg[mcols(neg)$len_adj%in%rl]
                    ok_reads<-ok_reads[as.vector(seqnames(ok_reads))%in%chroms]
                    
                    ps_neg<-GRanges()
                    seqlevels(ps_neg)<-seqllll
                    seqlengths(ps_neg)<-seqleee
                    ps_neg_uniq<-ps_neg
                    ps_neg_uniq_mm<-ps_neg
                    
                    if(length(ok_reads)>0){
                        unspl<-ok_reads[grep(pattern="N",x=cigar(ok_reads),invert=T)]
                        
                        ps_unspl<-shift(resize(GRanges(unspl),width=1,fix="start"),shift=-ct)
                        
                        spl<-ok_reads[grep(pattern="N",x=cigar(ok_reads))]
                        
                        firstb<-as.numeric(sapply(strsplit(cigar(spl),"M"),"[[",1))
                        lastb<-as.numeric(sapply(strsplit(cigar(spl),"M"),function(x){gsub(x[length(x)],pattern="^[^_]*N",replacement="")}))
                        lastok<-spl[lastb>ct]
                        lastok<-shift(resize(GRanges(lastok),width=1,fix="start"),shift=-ct)
                        
                        firstok<-spl[firstb>=rl-ct]
                        firstok<-shift(resize(GRanges(firstok),width=1,fix="end"),shift=(rl-ct-1))
                        
                        multi<-spl[firstb<rl-ct & lastb<=ct]
                        
                        
                        ps_spl<-GRanges()
                        seqlevels(ps_spl)<-seqllll
                        seqlengths(ps_spl)<-seqleee
                        
                        
                        if(length(multi)>0){
                            ps_spl<-get_ps_fromsplicemin(multi,cutoff=ct)
                        }
                        mcols(ps_unspl)<-NULL
                        mcols(firstok)<-NULL
                        mcols(lastok)<-NULL
                        mcols(ps_spl)<-NULL
                        
                        seqlevels(firstok)<-seqllll
                        seqlevels(lastok)<-seqllll
                        seqlevels(ps_unspl)<-seqllll
                        seqlevels(ps_spl)<-seqllll
                        
                        seqlengths(firstok)<-seqleee
                        seqlengths(lastok)<-seqleee
                        seqlengths(ps_unspl)<-seqleee
                        seqlengths(ps_spl)<-seqleee
                        
                        ps_neg<-c(ps_unspl,firstok,lastok,ps_spl)
                        ps_neg_uniq<-ps_neg[mcols(ok_reads)$mapq>50]
                        
                        ps_neg_uniq_mm<-ps_neg[mcols(ok_reads)$mapq>50 & nchar(mcols(ok_reads)$MD)>3]
                        
                    }
                    
                    all_ps<-sort(c(ps_plus,ps_neg))
                    uniq_ps<-sort(c(ps_plus_uniq,ps_neg_uniq))
                    uniq_mm_ps<-sort(c(ps_plus_uniq_mm,ps_neg_uniq_mm))
                    if(length(all_ps)>0){
                        ps_res<-unique(all_ps)
                        ps_res$score<-countOverlaps(ps_res,all_ps,type="equal")
                        all_ps<-ps_res
                    }
                    if(length(uniq_ps)>0){
                        ps_res<-unique(uniq_ps)
                        ps_res$score<-countOverlaps(ps_res,uniq_ps,type="equal")
                        uniq_ps<-ps_res
                        
                    }
                    if(length(uniq_mm_ps)>0){
                        ps_res<-unique(uniq_mm_ps)
                        ps_res$score<-countOverlaps(ps_res,uniq_mm_ps,type="equal")
                        uniq_mm_ps<-ps_res
                        
                    }
                    all_rl_ps[[as.character(rl)]]<-all_ps
                    uniq_rl_ps[[as.character(rl)]]<-uniq_ps
                    uniq_rl_mm_ps[[as.character(rl)]]<-uniq_mm_ps
                    
                    
                }
                #here comps
                list_rlct<-list(all_rl_ps,uniq_rl_ps,uniq_rl_mm_ps)
                names(list_rlct)<-c("P_sites_all","P_sites_uniq","P_sites_uniq_mm")
                list_pss[[comp]]<-list_rlct
            }
            #for rl, merge psites
            
            
            all_ps_comps<-GRangesList()
            seqlevels(all_ps_comps)<-seqllll
            seqlengths(all_ps_comps)<-seqleee
            rls_comps<-unique(unlist(lapply(list_pss,FUN=function(x) names(x[["P_sites_all"]]) )))
            for(rl in rls_comps){
                reads_rl_comp<-GRanges()
                seqlevels(reads_rl_comp)<-seqllll
                seqlengths(reads_rl_comp)<-seqleee
                for(comp in names(list_pss)){
                    if(sum(rl%in%names(list_pss[[comp]][["P_sites_all"]]))>0){
                        oth<-list_pss[[comp]][["P_sites_all"]][[rl]]
                        
                        if(!is.null(oth)){
                            seqlevels(oth)<-seqllll
                            seqlengths(oth)<-seqleee
                            reads_rl_comp<-c(reads_rl_comp,oth)
                        }
                    }          
                    all_ps_comps[[rl]]<-reads_rl_comp
                }
                
            }
            
            uniq_ps_comps<-GRangesList()
            seqlevels(uniq_ps_comps)<-seqllll
            seqlengths(uniq_ps_comps)<-seqleee
            rls_comps<-unique(unlist(lapply(list_pss,FUN=function(x) names(x[["P_sites_uniq"]]) )))
            for(rl in rls_comps){
                reads_rl_comp<-GRanges()
                seqlevels(reads_rl_comp)<-seqllll
                seqlengths(reads_rl_comp)<-seqleee
                for(comp in names(list_pss)){
                    if(sum(rl%in%names(list_pss[[comp]][["P_sites_uniq"]]))>0){
                        oth<-list_pss[[comp]][["P_sites_uniq"]][[rl]]
                        
                        if(!is.null(oth)){
                            seqlevels(oth)<-seqllll
                            seqlengths(oth)<-seqleee
                            reads_rl_comp<-c(reads_rl_comp,oth)
                        }
                    }          
                    uniq_ps_comps[[rl]]<-reads_rl_comp
                }
                
            }
            
            uniq_mm_ps_comps<-GRangesList()
            seqlevels(uniq_mm_ps_comps)<-seqllll
            seqlengths(uniq_mm_ps_comps)<-seqleee
            rls_comps<-unique(unlist(lapply(list_pss,FUN=function(x) names(x[["P_sites_uniq_mm"]]) )))
            for(rl in rls_comps){
                reads_rl_comp<-GRanges()
                seqlevels(reads_rl_comp)<-seqllll
                seqlengths(reads_rl_comp)<-seqleee
                for(comp in names(list_pss)){
                    if(sum(rl%in%names(list_pss[[comp]][["P_sites_uniq_mm"]]))>0){
                        oth<-list_pss[[comp]][["P_sites_uniq_mm"]][[rl]]
                        if(!is.null(oth)){
                            seqlevels(oth)<-seqllll
                            seqlengths(oth)<-seqleee
                            reads_rl_comp<-c(reads_rl_comp,oth)
                        }
                    }          
                    uniq_mm_ps_comps[[rl]]<-reads_rl_comp
                }
                
            }
            
        }
        
        list_res<-list(all_ps_comps,uniq_ps_comps,uniq_mm_ps_comps,rang_jun)
        names(list_res)<-c("P_sites_all","P_sites_uniq","P_sites_uniq_mm","junctions")
        
        return(list_res)
    }
    
    cat(paste("Calculating P-sites positions and junctions ...", date(),"\n"))
    
    for_SaTAnn<-reduceByYield(X=opts,YIELD=yiel,MAP=mapp,REDUCE=reduc)
    
    if(length(for_SaTAnn$P_sites_all)>0){
        merged_all_ps<-unlist(for_SaTAnn$P_sites_all)
        
        if(length(merged_all_ps)>0){
            covv_pl<-coverage(merged_all_ps[strand(merged_all_ps)=="+"],weight = merged_all_ps[strand(merged_all_ps)=="+"]$score)
            covv_pl<-GRanges(covv_pl)
            covv_pl<-covv_pl[covv_pl$score>0]
            covv_min<-coverage(merged_all_ps[strand(merged_all_ps)=="-"],weight = merged_all_ps[strand(merged_all_ps)=="-"]$score)
            covv_min<-GRanges(covv_min)
            covv_min<-covv_min[covv_min$score>0]
            strand(covv_pl)<-"+"
            strand(covv_min)<-"-"
            
            merged_all_ps<-sort(c(covv_pl,covv_min))
            
        }
        for_SaTAnn$P_sites_all<-merged_all_ps
    }
    
    
    if(length(for_SaTAnn$P_sites_uniq)>0){
        merged_uniq_ps<-unlist(for_SaTAnn$P_sites_uniq)
        if(length(merged_uniq_ps)>0){
            
            covv_pl<-coverage(merged_uniq_ps[strand(merged_uniq_ps)=="+"],weight = merged_uniq_ps[strand(merged_uniq_ps)=="+"]$score)
            covv_pl<-GRanges(covv_pl)
            covv_pl<-covv_pl[covv_pl$score>0]
            
            covv_min<-coverage(merged_uniq_ps[strand(merged_uniq_ps)=="-"],weight = merged_uniq_ps[strand(merged_uniq_ps)=="-"]$score)
            covv_min<-GRanges(covv_min)
            covv_min<-covv_min[covv_min$score>0]
            strand(covv_pl)<-"+"
            strand(covv_min)<-"-"
            merged_uniq_ps<-sort(c(covv_pl,covv_min))
            
        }
        for_SaTAnn$P_sites_uniq<-merged_uniq_ps
    }
    
    if(length(for_SaTAnn$P_sites_uniq_mm)>0){
        merged_uniq_mm_ps<-unlist(for_SaTAnn$P_sites_uniq_mm)
        if(length(merged_uniq_mm_ps)>0){
            
            covv_pl<-coverage(merged_uniq_mm_ps[strand(merged_uniq_mm_ps)=="+"],weight = merged_uniq_mm_ps[strand(merged_uniq_mm_ps)=="+"]$score)
            covv_pl<-GRanges(covv_pl)
            covv_pl<-covv_pl[covv_pl$score>0]
            
            covv_min<-coverage(merged_uniq_mm_ps[strand(merged_uniq_mm_ps)=="-"],weight = merged_uniq_mm_ps[strand(merged_uniq_mm_ps)=="-"]$score)
            covv_min<-GRanges(covv_min)
            covv_min<-covv_min[covv_min$score>0]
            strand(covv_pl)<-"+"
            strand(covv_min)<-"-"
            merged_uniq_mm_ps<-sort(c(covv_pl,covv_min))
        }
        for_SaTAnn$P_sites_uniq_mm<-merged_uniq_mm_ps
    }
    
    
    if(!is.na(path_to_P_sites_plus_bw) | !is.na(path_to_P_sites_minus_bw) ){
        for_SaTAnn$P_sites_all<-input_P_sites
    }
    
    if(!is.na(path_to_P_sites_uniq_plus_bw) | !is.na(path_to_P_sites_uniq_minus_bw) ){
        for_SaTAnn$P_sites_uniq<-input_P_sites_uniq
    }
    
    if(!is.na(path_to_P_sites_uniq_mm_plus_bw) | !is.na(path_to_P_sites_uniq_mm_minus_bw) ){
        for_SaTAnn$P_sites_uniq_mm<-input_P_sites_uniq_mm
    }
    
    cat(paste("Calculating P-sites positions and junctions --- Done!", date(),"\n"))
    
    save(for_SaTAnn,file = paste(dest_name,"for_SaTAnn",sep = "_"))
    
}